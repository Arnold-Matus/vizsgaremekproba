import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  LayoutDashboard,
  Music,
  Users,
  FileText,
  ListChecks,
  CheckCircle,
  XCircle,
  Play,
  Square,
  Trash2,
  Edit2,
  Save,
  X,
  Loader2,
  ExternalLink,
  Clock,
  AlertCircle,
  Plus,
  RefreshCw,
  Search,
  ChevronDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { adminAPI } from '../services/api';

const AdminPage = () => {
  const { user, isLoggedIn } = useUser();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);

  // Source type display names
  const sourceTypeNames = {
    youtube: 'YouTube',
    youtube_music: 'YT Music',
    spotify: 'Spotify',
    soundcloud: 'SoundCloud',
    apple_music: 'Apple Music',
    deezer: 'Deezer',
    tidal: 'Tidal',
    bandcamp: 'Bandcamp',
    upload: 'Feltöltés',
    other: 'Egyéb',
  };

  // Dashboard state
  const [dashboardData, setDashboardData] = useState(null);

  // Submissions state
  const [submissions, setSubmissions] = useState([]);
  const [submissionFilter, setSubmissionFilter] = useState('pending');

  // Requests state
  const [requests, setRequests] = useState([]);
  const [requestFilter, setRequestFilter] = useState('pending');

  // Songs state
  const [songs, setSongs] = useState([]);
  const [songSearch, setSongSearch] = useState('');
  const [editingSong, setEditingSong] = useState(null);
  const [showAddSong, setShowAddSong] = useState(false);
  const [newSong, setNewSong] = useState({
    title: '', artist: '', album: '', duration: '', genre: '',
    source_url: '', source_type: 'other', is_available: true
  });

  // Users state
  const [users, setUsers] = useState([]);
  const [userSearch, setUserSearch] = useState('');

  // Messages
  const [message, setMessage] = useState(null);

  // Check admin access
  useEffect(() => {
    if (!isLoggedIn || (user && user.role !== 'admin')) {
      navigate('/');
    }
  }, [isLoggedIn, user, navigate]);

  // Show temporary message
  const showMessage = (text, type = 'success') => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 4000);
  };

  // ========== DATA LOADING ==========
  const loadDashboard = useCallback(async () => {
    try {
      const data = await adminAPI.dashboard();
      if (data.success) setDashboardData(data.dashboard);
    } catch (err) {
      showMessage(err.message, 'error');
    }
  }, []);

  const loadSubmissions = useCallback(async () => {
    try {
      const data = await adminAPI.getSubmissions(submissionFilter);
      if (data.success) setSubmissions(data.submissions);
    } catch (err) {
      showMessage(err.message, 'error');
    }
  }, [submissionFilter]);

  const loadRequests = useCallback(async () => {
    try {
      const data = await adminAPI.getRequests(requestFilter);
      if (data.success) setRequests(data.requests);
    } catch (err) {
      showMessage(err.message, 'error');
    }
  }, [requestFilter]);

  const loadSongs = useCallback(async () => {
    try {
      const data = await adminAPI.getSongs();
      if (data.success) setSongs(data.songs);
    } catch (err) {
      showMessage(err.message, 'error');
    }
  }, []);

  const loadUsers = useCallback(async () => {
    try {
      const data = await adminAPI.getUsers();
      if (data.success) setUsers(data.users);
    } catch (err) {
      showMessage(err.message, 'error');
    }
  }, []);

  // Load data on tab change
  useEffect(() => {
    setLoading(true);
    const load = async () => {
      switch (activeTab) {
        case 'dashboard': await loadDashboard(); break;
        case 'submissions': await loadSubmissions(); break;
        case 'requests': await loadRequests(); break;
        case 'songs': await loadSongs(); break;
        case 'users': await loadUsers(); break;
      }
      setLoading(false);
    };
    load();

    // Auto-refresh for requests and dashboard tabs
    if (activeTab === 'requests' || activeTab === 'dashboard') {
      const refreshFn = activeTab === 'requests' ? loadRequests : loadDashboard;
      const interval = setInterval(refreshFn, 10000);
      return () => clearInterval(interval);
    }
  }, [activeTab, loadDashboard, loadSubmissions, loadRequests, loadSongs, loadUsers]);

  // ========== SUBMISSION ACTIONS ==========
  const handleApproveSubmission = async (id) => {
    try {
      const data = await adminAPI.approveSubmission(id, {});
      if (data.success) {
        showMessage('Beküldés jóváhagyva, zene hozzáadva a könyvtárhoz!');
        loadSubmissions();
        loadDashboard();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleRejectSubmission = async (id) => {
    const note = prompt('Elutasítás oka (opcionális):');
    try {
      const data = await adminAPI.rejectSubmission(id, { admin_note: note || '' });
      if (data.success) {
        showMessage('Beküldés elutasítva.');
        loadSubmissions();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  // ========== REQUEST ACTIONS ==========
  const handleApproveRequest = async (id) => {
    try {
      const data = await adminAPI.approveRequest(id, {});
      if (data.success) {
        showMessage('Kérés jóváhagyva!');
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleRejectRequest = async (id) => {
    const note = prompt('Elutasítás oka (opcionális):');
    try {
      const data = await adminAPI.rejectRequest(id, { admin_note: note || '' });
      if (data.success) {
        showMessage('Kérés elutasítva.');
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleSetPlaying = async (id) => {
    try {
      const data = await adminAPI.setPlaying(id);
      if (data.success) {
        showMessage('Zene lejátszás indítva!');
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleSetCompleted = async (id) => {
    try {
      const data = await adminAPI.setCompleted(id);
      if (data.success) {
        showMessage('Lejátszás befejezve.');
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleReorderRequest = async (id, direction) => {
    try {
      const data = await adminAPI.reorderRequest(id, direction);
      if (data.success) {
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleDeleteRequest = async (id) => {
    if (!confirm('Biztosan törlöd ezt a kérést?')) return;
    try {
      const data = await adminAPI.deleteRequest(id);
      if (data.success) {
        showMessage(data.message);
        loadRequests();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  // ========== SONG ACTIONS ==========
  const handleCreateSong = async (e) => {
    e.preventDefault();
    try {
      const songData = {
        ...newSong,
        duration: parseInt(newSong.duration) || 0,
      };
      const data = await adminAPI.createSong(songData);
      if (data.success) {
        showMessage('Zene sikeresen hozzáadva!');
        setShowAddSong(false);
        setNewSong({
          title: '', artist: '', album: '', duration: '', genre: '',
          source_url: '', source_type: 'other', is_available: true
        });
        loadSongs();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleUpdateSong = async (id) => {
    try {
      const data = await adminAPI.updateSong(id, editingSong);
      if (data.success) {
        showMessage('Zene frissítve!');
        setEditingSong(null);
        loadSongs();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  const handleDeleteSong = async (id, title) => {
    if (!confirm(`Biztosan törlöd: "${title}"?`)) return;
    try {
      const data = await adminAPI.deleteSong(id);
      if (data.success) {
        showMessage('Zene törölve!');
        loadSongs();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  // ========== USER ACTIONS ==========
  const handleUpdateUserRole = async (userId, newRole) => {
    try {
      const data = await adminAPI.updateUserRole(userId, newRole);
      if (data.success) {
        showMessage('Felhasználó szerepe frissítve!');
        loadUsers();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  // ========== CONVERSION ACTIONS ==========
  const handleRetryConversion = async (songId) => {
    try {
      const data = await adminAPI.retryConversion(songId);
      if (data.success) {
        showMessage('Konvertálás újraindítva!');
        loadSongs();
      }
    } catch (err) {
      showMessage(err.message, 'error');
    }
  };

  // ========== HELPERS ==========
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleString('hu-HU', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const statusLabels = {
    pending: 'Függőben',
    approved: 'Jóváhagyva',
    rejected: 'Elutasítva',
    playing: 'Lejátszás alatt',
    completed: 'Befejezve',
  };

  const statusColors = {
    pending: 'var(--color-warning)',
    approved: 'var(--color-success)',
    rejected: 'var(--color-error)',
    playing: 'var(--color-primary)',
    completed: 'var(--color-text-muted)',
  };

  const roleLabels = {
    admin: 'Admin',
    teacher: 'Tanár',
    student: 'Diák',
  };

  const tabs = [
    { id: 'dashboard', label: 'Áttekintés', icon: LayoutDashboard },
    { id: 'submissions', label: 'Beküldések', icon: FileText },
    { id: 'requests', label: 'Kérések', icon: ListChecks },
    { id: 'songs', label: 'Zenék', icon: Music },
    { id: 'users', label: 'Felhasználók', icon: Users },
  ];

  if (!isLoggedIn || !user || user.role !== 'admin') {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Shield size={64} />
          <h2>Hozzáférés megtagadva</h2>
          <p>Ez az oldal csak adminisztrátorok számára érhető el.</p>
        </div>
      </div>
    );
  }

  // ========== RENDER TABS ==========

  const renderDashboard = () => {
    if (!dashboardData) return null;
    const { stats, recentSubmissions, recentRequests } = dashboardData;

    return (
      <div className="admin-dashboard">
        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalSongs}</span>
              <span className="admin-stat-label">Összes zene</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <Users size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalUsers}</span>
              <span className="admin-stat-label">Felhasználók</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <FileText size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingSubmissions}</span>
              <span className="admin-stat-label">Függő beküldés</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <ListChecks size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingRequests}</span>
              <span className="admin-stat-label">Függő kérés</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <Clock size={24} />
            <div>
              <span className="admin-stat-value">{stats.todayRequests}</span>
              <span className="admin-stat-label">Mai kérések</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <Play size={24} />
            <div>
              <span className="admin-stat-value">{stats.nowPlaying ? 'Igen' : 'Nem'}</span>
              <span className="admin-stat-label">Zene szól</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <RefreshCw size={24} />
            <div>
              <span className="admin-stat-value">{stats.conversionPending || 0}</span>
              <span className="admin-stat-label">Konvertálásra vár</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <AlertCircle size={24} />
            <div>
              <span className="admin-stat-value">{stats.conversionFailed || 0}</span>
              <span className="admin-stat-label">Konvertálás hiba</span>
            </div>
          </div>
        </div>

        {/* Recent submissions */}
        <div className="admin-section">
          <h3><FileText size={20} /> Legutóbbi beküldések</h3>
          {recentSubmissions.length === 0 ? (
            <p className="admin-empty">Nincs beküldés.</p>
          ) : (
            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Beküldő</th>
                    <th>Cím</th>
                    <th>Link</th>
                    <th>Státusz</th>
                    <th>Dátum</th>
                  </tr>
                </thead>
                <tbody>
                  {recentSubmissions.map(sub => (
                    <tr key={sub.id}>
                      <td>{sub.user?.name || '-'}</td>
                      <td>{sub.title || '-'}</td>
                      <td>
                        <a href={sub.url} target="_blank" rel="noopener noreferrer" className="admin-link">
                          <ExternalLink size={14} /> Link
                        </a>
                      </td>
                      <td>
                        <span className="admin-badge" style={{ color: statusColors[sub.status] }}>
                          {statusLabels[sub.status]}
                        </span>
                      </td>
                      <td>{formatDate(sub.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Recent requests */}
        <div className="admin-section">
          <h3><ListChecks size={20} /> Legutóbbi kérések</h3>
          {recentRequests.length === 0 ? (
            <p className="admin-empty">Nincs kérés.</p>
          ) : (
            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Kérő</th>
                    <th>Zene</th>
                    <th>Státusz</th>
                    <th>Dátum</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRequests.map(req => (
                    <tr key={req.id}>
                      <td>{req.user?.name || '-'}</td>
                      <td>{req.song ? `${req.song.artist} - ${req.song.title}` : '-'}</td>
                      <td>
                        <span className="admin-badge" style={{ color: statusColors[req.status] }}>
                          {statusLabels[req.status]}
                        </span>
                      </td>
                      <td>{formatDate(req.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderSubmissions = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><FileText size={20} /> Link beküldések kezelése</h3>
        <div className="admin-filters">
          {['pending', 'approved', 'rejected'].map(status => (
            <button
              key={status}
              className={`admin-filter-btn ${submissionFilter === status ? 'active' : ''}`}
              onClick={() => setSubmissionFilter(status)}
            >
              {statusLabels[status]}
            </button>
          ))}
          <button className="admin-icon-btn" onClick={loadSubmissions} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {submissions.length === 0 ? (
        <p className="admin-empty">Nincs {statusLabels[submissionFilter].toLowerCase()} beküldés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Beküldő</th>
                <th>Cím / Előadó</th>
                <th>Link</th>
                <th>Típus</th>
                <th>Üzenet</th>
                <th>Dátum</th>
                {submissionFilter === 'pending' && <th>Műveletek</th>}
              </tr>
            </thead>
            <tbody>
              {submissions.map(sub => (
                <tr key={sub.id}>
                  <td>{sub.submittedBy || '-'}</td>
                  <td>
                    <strong>{sub.title || 'Nincs megadva'}</strong>
                    {sub.artist && <><br /><small>{sub.artist}</small></>}
                  </td>
                  <td>
                    <a href={sub.url} target="_blank" rel="noopener noreferrer" className="admin-link">
                      <ExternalLink size={14} /> Megnyitás
                    </a>
                  </td>
                  <td>
                    <span className="admin-badge-type">{sourceTypeNames[sub.sourceType] || sub.sourceType || '-'}</span>
                  </td>
                  <td>{sub.message || '-'}</td>
                  <td>{formatDate(sub.createdAt)}</td>
                  {submissionFilter === 'pending' && (
                    <td className="admin-actions">
                      <button
                        className="admin-action-btn approve"
                        onClick={() => handleApproveSubmission(sub.id)}
                        title="Jóváhagyás"
                      >
                        <CheckCircle size={16} />
                      </button>
                      <button
                        className="admin-action-btn reject"
                        onClick={() => handleRejectSubmission(sub.id)}
                        title="Elutasítás"
                      >
                        <XCircle size={16} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderRequests = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><ListChecks size={20} /> Zenekérések kezelése</h3>
        <div className="admin-filters">
          {['pending', 'approved', 'playing', 'completed', 'rejected'].map(status => (
            <button
              key={status}
              className={`admin-filter-btn ${requestFilter === status ? 'active' : ''}`}
              onClick={() => setRequestFilter(status)}
            >
              {statusLabels[status]}
            </button>
          ))}
          <button className="admin-icon-btn" onClick={loadRequests} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {requests.length === 0 ? (
        <p className="admin-empty">Nincs {statusLabels[requestFilter].toLowerCase()} kérés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Kérő</th>
                <th>Zene</th>
                <th>Időpont</th>
                <th>Üzenet</th>
                <th>Státusz</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((req, index) => (
                <tr key={req.id}>
                  <td>
                    {req.playOrder ?? '-'}
                    {req.status === 'approved' && (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginTop: 4 }}>
                        <button
                          className="admin-icon-btn"
                          onClick={() => handleReorderRequest(req.id, 'up')}
                          title="Fel"
                          disabled={index === 0}
                          style={{ padding: '2px 4px' }}
                        >
                          <ArrowUp size={12} />
                        </button>
                        <button
                          className="admin-icon-btn"
                          onClick={() => handleReorderRequest(req.id, 'down')}
                          title="Le"
                          disabled={index === requests.length - 1}
                          style={{ padding: '2px 4px' }}
                        >
                          <ArrowDown size={12} />
                        </button>
                      </div>
                    )}
                  </td>
                  <td>{req.user?.name || '-'}</td>
                  <td>
                    {req.song ? (
                      <>
                        <strong>{req.song.title}</strong>
                        <br /><small>{req.song.artist}</small>
                        {req.song.conversionStatus && (
                          <><br /><small className={`conversion-badge ${req.song.conversionStatus}`}>
                            {req.song.conversionStatus === 'completed' ? 'MP3 kész' : req.song.conversionStatus === 'processing' ? 'Feldolgozás...' : req.song.conversionStatus === 'failed' ? 'Hiba' : 'Várakozik'}
                          </small></>
                        )}
                      </>
                    ) : '-'}
                  </td>
                  <td>
                    {req.scheduledTime || '-'}
                    {req.scheduledDate && <><br /><small>{req.scheduledDate}</small></>}
                  </td>
                  <td>{req.message || '-'}</td>
                  <td>
                    <span className="admin-badge" style={{ color: statusColors[req.status] }}>
                      {statusLabels[req.status]}
                    </span>
                  </td>
                  <td className="admin-actions">
                    {req.status === 'pending' && (
                      <>
                        <button
                          className="admin-action-btn approve"
                          onClick={() => handleApproveRequest(req.id)}
                          title="Jóváhagyás"
                        >
                          <CheckCircle size={16} />
                        </button>
                        <button
                          className="admin-action-btn reject"
                          onClick={() => handleRejectRequest(req.id)}
                          title="Elutasítás"
                        >
                          <XCircle size={16} />
                        </button>
                      </>
                    )}
                    {req.status === 'approved' && (
                      <button
                        className="admin-action-btn play"
                        onClick={() => handleSetPlaying(req.id)}
                        title="Lejátszás indítása"
                      >
                        <Play size={16} />
                      </button>
                    )}
                    {req.status === 'playing' && (
                      <button
                        className="admin-action-btn complete"
                        onClick={() => handleSetCompleted(req.id)}
                        title="Befejezés"
                      >
                        <Square size={16} />
                      </button>
                    )}
                    <button
                      className="admin-action-btn reject"
                      onClick={() => handleDeleteRequest(req.id)}
                      title="Törlés"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSongs = () => {
    const filtered = songs.filter(s =>
      !songSearch ||
      s.title.toLowerCase().includes(songSearch.toLowerCase()) ||
      s.artist.toLowerCase().includes(songSearch.toLowerCase())
    );

    return (
      <div className="admin-section">
        <div className="admin-section-header">
          <h3><Music size={20} /> Zenék kezelése ({songs.length} zene)</h3>
          <div className="admin-filters">
            <div className="admin-search">
              <Search size={16} />
              <input
                type="text"
                placeholder="Keresés..."
                value={songSearch}
                onChange={(e) => setSongSearch(e.target.value)}
              />
            </div>
            <button
              className="admin-add-btn"
              onClick={() => setShowAddSong(!showAddSong)}
            >
              <Plus size={16} /> Új zene
            </button>
            <button className="admin-icon-btn" onClick={loadSongs} title="Frissítés">
              <RefreshCw size={16} />
            </button>
          </div>
        </div>

        {/* Add song form */}
        {showAddSong && (
          <form className="admin-form" onSubmit={handleCreateSong}>
            <h4>Új zene hozzáadása</h4>
            <div className="admin-form-grid">
              <div className="form-group">
                <label>Cím *</label>
                <input
                  type="text"
                  value={newSong.title}
                  onChange={(e) => setNewSong({ ...newSong, title: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Előadó *</label>
                <input
                  type="text"
                  value={newSong.artist}
                  onChange={(e) => setNewSong({ ...newSong, artist: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Album</label>
                <input
                  type="text"
                  value={newSong.album}
                  onChange={(e) => setNewSong({ ...newSong, album: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Időtartam (mp)</label>
                <input
                  type="number"
                  value={newSong.duration}
                  onChange={(e) => setNewSong({ ...newSong, duration: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Műfaj</label>
                <input
                  type="text"
                  value={newSong.genre}
                  onChange={(e) => setNewSong({ ...newSong, genre: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Forrás URL</label>
                <input
                  type="url"
                  value={newSong.source_url}
                  onChange={(e) => setNewSong({ ...newSong, source_url: e.target.value })}
                  placeholder="https://youtube.com/... vagy más platform link"
                />
              </div>
              <div className="form-group">
                <label>Típus</label>
                <select
                  value={newSong.source_type}
                  onChange={(e) => setNewSong({ ...newSong, source_type: e.target.value })}
                >
                  <option value="youtube">YouTube</option>
                  <option value="youtube_music">YouTube Music</option>
                  <option value="spotify">Spotify</option>
                  <option value="soundcloud">SoundCloud</option>
                  <option value="apple_music">Apple Music</option>
                  <option value="deezer">Deezer</option>
                  <option value="tidal">Tidal</option>
                  <option value="bandcamp">Bandcamp</option>
                  <option value="upload">Feltöltés</option>
                  <option value="other">Egyéb</option>
                </select>
              </div>
              <div className="form-group">
                <label className="admin-checkbox-label">
                  <input
                    type="checkbox"
                    checked={newSong.is_available}
                    onChange={(e) => setNewSong({ ...newSong, is_available: e.target.checked })}
                  />
                  Elérhető
                </label>
              </div>
            </div>
            <div className="admin-form-actions">
              <button type="submit" className="btn btn-primary">
                <Save size={16} /> Mentés
              </button>
              <button type="button" className="btn btn-secondary" onClick={() => setShowAddSong(false)}>
                <X size={16} /> Mégse
              </button>
            </div>
          </form>
        )}

        {/* Songs table */}
        {filtered.length === 0 ? (
          <p className="admin-empty">Nincs találat.</p>
        ) : (
          <div className="admin-table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Cím</th>
                  <th>Előadó</th>
                  <th>Album</th>
                  <th>Időtartam</th>
                  <th>Műfaj</th>
                  <th>Típus</th>
                  <th>Konvertálás</th>
                  <th>Kérések</th>
                  <th>Elérhető</th>
                  <th>Műveletek</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(song => (
                  <tr key={song.id}>
                    {editingSong?.id === song.id ? (
                      <>
                        <td>
                          <input
                            type="text"
                            value={editingSong.title}
                            onChange={(e) => setEditingSong({ ...editingSong, title: e.target.value })}
                            className="admin-inline-input"
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            value={editingSong.artist}
                            onChange={(e) => setEditingSong({ ...editingSong, artist: e.target.value })}
                            className="admin-inline-input"
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            value={editingSong.album || ''}
                            onChange={(e) => setEditingSong({ ...editingSong, album: e.target.value })}
                            className="admin-inline-input"
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            value={editingSong.duration}
                            onChange={(e) => setEditingSong({ ...editingSong, duration: parseInt(e.target.value) || 0 })}
                            className="admin-inline-input"
                            style={{ width: '70px' }}
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            value={editingSong.genre || ''}
                            onChange={(e) => setEditingSong({ ...editingSong, genre: e.target.value })}
                            className="admin-inline-input"
                          />
                        </td>
                        <td>{sourceTypeNames[song.sourceType] || song.sourceType || '-'}</td>
                        <td>
                          <span className={`conversion-badge ${song.conversionStatus || 'pending'}`}>
                            {song.conversionStatus === 'completed' ? '✅ Kész' 
                              : song.conversionStatus === 'processing' ? '🔄 Folyamatban'
                              : song.conversionStatus === 'failed' ? '❌ Hiba'
                              : '⏳ Várakozik'}
                          </span>
                        </td>
                        <td>{song.requestCount}</td>
                        <td>
                          <input
                            type="checkbox"
                            checked={editingSong.isAvailable}
                            onChange={(e) => setEditingSong({ ...editingSong, isAvailable: e.target.checked })}
                          />
                        </td>
                        <td className="admin-actions">
                          <button
                            className="admin-action-btn approve"
                            onClick={() => handleUpdateSong(song.id)}
                            title="Mentés"
                          >
                            <Save size={16} />
                          </button>
                          <button
                            className="admin-action-btn"
                            onClick={() => setEditingSong(null)}
                            title="Mégse"
                          >
                            <X size={16} />
                          </button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td><strong>{song.title}</strong></td>
                        <td>{song.artist}</td>
                        <td>{song.album || '-'}</td>
                        <td>{formatDuration(song.duration)}</td>
                        <td>{song.genre || '-'}</td>
                        <td>
                          <span className="admin-badge-type">{sourceTypeNames[song.sourceType] || song.sourceType || '-'}</span>
                        </td>
                        <td>
                          <span className={`conversion-badge ${song.conversionStatus || 'pending'}`}>
                            {song.conversionStatus === 'completed' ? '✅ Kész' 
                              : song.conversionStatus === 'processing' ? '🔄 Folyamatban'
                              : song.conversionStatus === 'failed' ? '❌ Hiba'
                              : '⏳ Várakozik'}
                          </span>
                        </td>
                        <td>{song.requestCount}</td>
                        <td>{song.isAvailable ? '✅' : '❌'}</td>
                        <td className="admin-actions">
                          <button
                            className="admin-action-btn"
                            onClick={() => setEditingSong({ ...song })}
                            title="Szerkesztés"
                          >
                            <Edit2 size={16} />
                          </button>
                          {song.conversionStatus === 'failed' && (
                            <button
                              className="admin-action-btn approve"
                              onClick={() => handleRetryConversion(song.id)}
                              title="Konvertálás újrapróbálása"
                            >
                              <RefreshCw size={16} />
                            </button>
                          )}
                          <button
                            className="admin-action-btn reject"
                            onClick={() => handleDeleteSong(song.id, song.title)}
                            title="Törlés"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  };

  const renderUsers = () => {
    const filtered = users.filter(u =>
      !userSearch ||
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase())
    );

    return (
      <div className="admin-section">
        <div className="admin-section-header">
          <h3><Users size={20} /> Felhasználók kezelése ({users.length} felhasználó)</h3>
          <div className="admin-filters">
            <div className="admin-search">
              <Search size={16} />
              <input
                type="text"
                placeholder="Keresés..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
              />
            </div>
            <button className="admin-icon-btn" onClick={loadUsers} title="Frissítés">
              <RefreshCw size={16} />
            </button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="admin-empty">Nincs találat.</p>
        ) : (
          <div className="admin-table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Név</th>
                  <th>Email</th>
                  <th>Oktatási azon.</th>
                  <th>Osztály</th>
                  <th>Szerep</th>
                  <th>Kérések</th>
                  <th>Regisztráció</th>
                  <th>Műveletek</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(u => (
                  <tr key={u.id}>
                    <td><strong>{u.name}</strong></td>
                    <td>{u.email}</td>
                    <td>{u.educationalId || '-'}</td>
                    <td>{u.class || '-'}</td>
                    <td>
                      <span className="admin-badge" style={{
                        color: u.role === 'admin' ? 'var(--color-error)' :
                               u.role === 'teacher' ? 'var(--color-warning)' :
                               'var(--color-primary)'
                      }}>
                        {roleLabels[u.role]}
                      </span>
                    </td>
                    <td>{u.requestCount ?? 0}</td>
                    <td>{formatDate(u.createdAt)}</td>
                    <td className="admin-actions">
                      <select
                        value={u.role}
                        onChange={(e) => handleUpdateUserRole(u.id, e.target.value)}
                        className="admin-role-select"
                        disabled={u.id === user.id}
                      >
                        <option value="student">Diák</option>
                        <option value="teacher">Tanár</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="admin-loading">
          <Loader2 size={32} className="spinner" />
          <p>Betöltés...</p>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard': return renderDashboard();
      case 'submissions': return renderSubmissions();
      case 'requests': return renderRequests();
      case 'songs': return renderSongs();
      case 'users': return renderUsers();
      default: return null;
    }
  };

  return (
    <div className="page admin-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Shield size={32} className="page-icon" />
          <div>
            <h1 className="page-title">Admin Panel</h1>
            <p className="page-subtitle">Kezelj mindent egy helyen</p>
          </div>
        </div>
      </section>

      {/* Message toast */}
      {message && (
        <div className={`admin-toast ${message.type}`}>
          {message.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)}><X size={16} /></button>
        </div>
      )}

      {/* Tabs */}
      <div className="admin-tabs">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={`admin-tab ${activeTab === id ? 'active' : ''}`}
            onClick={() => setActiveTab(id)}
          >
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="admin-content">
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminPage;

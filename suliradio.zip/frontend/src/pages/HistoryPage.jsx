import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { 
  History, 
  Music, 
  Clock, 
  Calendar,
  CheckCircle,
  XCircle,
  Loader2
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { useMusic } from '../contexts/MusicContext';
import { requestsAPI } from '../services/api';

const HistoryPage = () => {
  const { user, isLoggedIn } = useUser();
  const { formatDuration } = useMusic();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadHistory = useCallback(() => {
    if (isLoggedIn) {
      setLoading(true);
      requestsAPI.history()
        .then(data => {
          if (data.success) {
            setHistory(data.history.filter(item => item.song != null));
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [isLoggedIn]);

  // Load on mount and when login state changes
  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  if (!isLoggedIn || !user) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <History size={64} />
          <h2>Nincs bejelentkezve</h2>
          <p>Az előzmények megtekintéséhez jelentkezz be.</p>
          <Link to="/login" className="btn btn-primary">Bejelentkezés</Link>
        </div>
      </div>
    );
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'played':
        return <CheckCircle size={18} style={{ color: 'var(--color-success)' }} />;
      case 'rejected':
        return <XCircle size={18} style={{ color: 'var(--color-error)' }} />;
      case 'pending':
        return <Loader2 size={18} style={{ color: 'var(--color-warning)' }} className="spinning" />;
      default:
        return <Clock size={18} />;
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'played': return 'Lejátszva';
      case 'rejected': return 'Elutasítva';
      case 'pending': return 'Függőben';
      default: return 'Ismeretlen';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('hu-HU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <History size={32} className="page-icon" />
          <div>
            <h1 className="page-title">Előzmények</h1>
            <p className="page-subtitle">
              Korábbi zenekéréseid
            </p>
          </div>
        </div>
      </section>

      {loading ? (
        <div className="not-logged-in">
          <Loader2 size={48} className="spinning" />
          <p>Betöltés...</p>
        </div>
      ) : history.length === 0 ? (
        <div className="not-logged-in">
          <History size={64} />
          <h2>Még nincsenek kéréseid</h2>
          <p>Kérj zenéket és itt fognak megjelenni!</p>
          <Link to="/request" className="btn btn-primary">Zene kérése</Link>
        </div>
      ) : (
        <div className="song-list-container">
          <div style={{ overflowX: 'auto' }}>
            <table className="song-table">
              <thead>
                <tr>
                  <th style={{ width: '40%' }}>Zene</th>
                  <th>Dátum</th>
                  <th>Állapot</th>
                </tr>
              </thead>
              <tbody>
                {history.map(item => (
                  <tr key={item.id}>
                    <td>
                      <div className="song-info">
                        <div className="song-cover">
                          <Music size={20} />
                        </div>
                        <div className="song-details">
                          <span className="song-title">{item.song.title}</span>
                          <span className="song-artist">{item.song.artist}</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--color-text-secondary)' }}>
                        <Calendar size={16} />
                        {formatDate(item.requestedAt)}
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        {getStatusIcon(item.status)}
                        <span>{getStatusLabel(item.status)}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryPage;

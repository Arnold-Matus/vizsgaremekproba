const API_URL = 'http://localhost:8000/api';

// Helper to get stored token
const getToken = () => {
  return localStorage.getItem('suliradio-token');
};

// Helper to make authenticated requests
const apiRequest = async (endpoint, options = {}) => {
  const token = getToken();
  
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      // Handle validation errors
      if (response.status === 422 && data.errors) {
        const firstError = Object.values(data.errors)[0];
        throw new Error(Array.isArray(firstError) ? firstError[0] : firstError);
      }
      throw new Error(data.error || data.message || 'Hiba történt!');
    }

    return data;
  } catch (error) {
    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
      throw new Error('Nem sikerült csatlakozni a szerverhez. Ellenőrizd, hogy a backend fut-e!');
    }
    throw error;
  }
};

// ========== AUTH ==========
export const authAPI = {
  register: (data) => apiRequest('/register', {
    method: 'POST',
    body: JSON.stringify({
      name: data.name,
      email: data.email,
      password: data.password,
      educational_id: data.educationalId,
      class_group: data.classGroup,
    }),
  }),

  login: (identifier, password) => apiRequest('/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  }),

  logout: () => apiRequest('/logout', { method: 'POST' }),

  me: () => apiRequest('/me'),

  updateProfile: (data) => apiRequest('/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
};

// ========== SONGS ==========
export const songsAPI = {
  getAll: (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.set('search', params.search);
    if (params.genre) query.set('genre', params.genre);
    if (params.sortBy) query.set('sort_by', params.sortBy);
    if (params.sortOrder) query.set('sort_order', params.sortOrder);
    const qs = query.toString();
    return apiRequest(`/songs${qs ? `?${qs}` : ''}`);
  },

  getOne: (id) => apiRequest(`/songs/${id}`),

  getGenres: () => apiRequest('/songs/genres'),

  getStats: () => apiRequest('/stats'),
};

// ========== SCHEDULE ==========
export const scheduleAPI = {
  get: (date) => {
    const query = date ? `?date=${date}` : '';
    return apiRequest(`/schedule${query}`);
  },
};

// ========== SONG REQUESTS ==========
export const requestsAPI = {
  create: (songIds, message) => apiRequest('/requests', {
    method: 'POST',
    body: JSON.stringify({ song_ids: songIds, message }),
  }),

  history: () => apiRequest('/requests/history'),

  dailyStatus: () => apiRequest('/requests/daily-status'),
};

// ========== SUBMISSIONS ==========
export const submissionsAPI = {
  create: (data) => apiRequest('/submissions', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  mine: () => apiRequest('/submissions/mine'),
};

// ========== FAVORITES ==========
export const favoritesAPI = {
  getAll: () => apiRequest('/favorites'),

  add: (songId) => apiRequest('/favorites', {
    method: 'POST',
    body: JSON.stringify({ song_id: songId }),
  }),

  remove: (songId) => apiRequest(`/favorites/${songId}`, {
    method: 'DELETE',
  }),
};

// ========== ADMIN ==========
export const adminAPI = {
  dashboard: () => apiRequest('/admin/dashboard'),

  // Submissions
  getSubmissions: (status = 'pending') => apiRequest(`/admin/submissions?status=${status}`),
  approveSubmission: (id, data) => apiRequest(`/admin/submissions/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  rejectSubmission: (id, data) => apiRequest(`/admin/submissions/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  // Song Requests
  getRequests: (status = 'pending') => apiRequest(`/admin/requests?status=${status}`),
  approveRequest: (id, data) => apiRequest(`/admin/requests/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  rejectRequest: (id, data) => apiRequest(`/admin/requests/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  setPlaying: (id) => apiRequest(`/admin/requests/${id}/playing`, { method: 'POST' }),
  setCompleted: (id) => apiRequest(`/admin/requests/${id}/completed`, { method: 'POST' }),
  reorderRequest: (id, direction) => apiRequest(`/admin/requests/${id}/reorder`, {
    method: 'POST',
    body: JSON.stringify({ direction }),
  }),
  deleteRequest: (id) => apiRequest(`/admin/requests/${id}`, { method: 'DELETE' }),

  // Songs
  getSongs: () => apiRequest('/admin/songs'),
  createSong: (data) => apiRequest('/admin/songs', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  updateSong: (id, data) => apiRequest(`/admin/songs/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  deleteSong: (id) => apiRequest(`/admin/songs/${id}`, { method: 'DELETE' }),

  // Users
  getUsers: () => apiRequest('/admin/users'),
  updateUserRole: (id, role) => apiRequest(`/admin/users/${id}/role`, {
    method: 'PUT',
    body: JSON.stringify({ role }),
  }),

  // Conversion
  getConversionStatus: () => apiRequest('/admin/conversion/status'),
  retryConversion: (songId) => apiRequest(`/admin/conversion/${songId}/retry`, {
    method: 'POST',
  }),
};

export default apiRequest;

import { useState, useRef } from 'react';
import { Music, Radio, Disc, Volume2, VolumeX, Play, Pause, SkipForward } from 'lucide-react';
import { useMusic } from '../contexts/MusicContext';

const NowPlaying = () => {
  const { 
    currentlyPlaying, 
    formatDuration, 
    isPlaying, 
    audioElapsed, 
    audioDuration,
    volume,
    setVolume,
    togglePlayPause,
    seekTo,
    stopPlayback,
  } = useMusic();
  
  const [isDragging, setIsDragging] = useState(false);
  const progressRef = useRef(null);

  if (!currentlyPlaying) {
    return (
      <div className="now-playing empty">
        <div className="now-playing-content">
          <Radio size={32} className="now-playing-icon" aria-hidden="true" />
          <div className="now-playing-details">
            <span className="now-playing-label">Most játszuk</span>
            <h2 className="now-playing-title">Jelenleg nincs lejátszás</h2>
          </div>
        </div>
      </div>
    );
  }

  const duration = audioDuration || currentlyPlaying.duration || 0;
  const elapsed = audioElapsed || 0;
  const remaining = Math.max(0, duration - elapsed);
  const progress = duration > 0 ? Math.min((elapsed / duration) * 100, 100) : 0;
  const hasMp3 = !!currentlyPlaying.mp3Url;

  const handleProgressClick = (e) => {
    if (!hasMp3 || !progressRef.current) return;
    const rect = progressRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = x / rect.width;
    const newTime = Math.floor(pct * duration);
    seekTo(Math.max(0, Math.min(newTime, duration)));
  };

  return (
    <div className="now-playing" role="region" aria-label="Most játszott zene">
      <div className="now-playing-background">
        <div className="now-playing-gradient" />
      </div>
      
      <div className="now-playing-content">
        <div className="now-playing-visualizer">
          {isPlaying && (
            <>
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
            </>
          )}
        </div>

        <div className="now-playing-cover">
          {currentlyPlaying.coverUrl ? (
            <img src={currentlyPlaying.coverUrl} alt={`${currentlyPlaying.title} borító`} />
          ) : (
            <div className="now-playing-cover-placeholder">
              <Disc size={40} className={isPlaying ? 'spinning' : ''} />
            </div>
          )}
        </div>

        <div className="now-playing-details">
          <span className="now-playing-label">
            {isPlaying ? (
              <><Volume2 size={14} className="pulse" /> Most játszuk</>
            ) : hasMp3 ? (
              <><Radio size={14} /> Szüneteltetve</>
            ) : (
              <><Radio size={14} /> Most játszuk (konvertálás alatt)</>
            )}
          </span>
          <h2 className="now-playing-title">{currentlyPlaying.title}</h2>
          <p className="now-playing-artist">{currentlyPlaying.artist}</p>
          <div className="now-playing-meta">
            {currentlyPlaying.album && (
              <>
                <span className="now-playing-album">{currentlyPlaying.album}</span>
                <span className="now-playing-separator">•</span>
              </>
            )}
            <span className="now-playing-duration">{formatDuration(duration)}</span>
          </div>

          {/* Audio controls */}
          {hasMp3 && (
            <div className="now-playing-controls">
              <button 
                className="player-btn play-btn"
                onClick={togglePlayPause}
                aria-label={isPlaying ? 'Szünet' : 'Lejátszás'}
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>

              <div className="now-playing-progress">
                <span className="progress-elapsed">{formatDuration(elapsed)}</span>
                <div 
                  className="progress-bar clickable"
                  ref={progressRef}
                  onClick={handleProgressClick}
                  role="slider"
                  aria-label="Zene pozíció"
                  aria-valuemin={0}
                  aria-valuemax={duration}
                  aria-valuenow={elapsed}
                >
                  <div 
                    className="progress-fill" 
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="progress-remaining">-{formatDuration(remaining)}</span>
              </div>

              <div className="volume-control">
                <button 
                  className="player-btn volume-btn"
                  onClick={() => setVolume(volume > 0 ? 0 : 0.7)}
                  aria-label={volume > 0 ? 'Némítás' : 'Hang bekapcsolása'}
                >
                  {volume > 0 ? <Volume2 size={16} /> : <VolumeX size={16} />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="volume-slider"
                  aria-label="Hangerő"
                />
              </div>
            </div>
          )}

          {/* Progress for non-mp3 (server-side timing) */}
          {!hasMp3 && currentlyPlaying.startedAt && duration > 0 && (
            <div className="now-playing-progress">
              <div className="progress-times">
                <span className="progress-elapsed">{formatDuration(elapsed)}</span>
                <span className="progress-remaining">-{formatDuration(remaining)}</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {currentlyPlaying.scheduleItem && (
            <p className="now-playing-requested">
              Kérte: <strong>{currentlyPlaying.scheduleItem.requestedBy}</strong>
            </p>
          )}
        </div>

        <div className="now-playing-visualizer right">
          {isPlaying && (
            <>
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
              <div className="visualizer-bar" />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default NowPlaying;

const API_URL = 'http://localhost:8000/api';

// Helper to get stored token
const getToken = () => {
  return localStorage.getItem('suliradio-token');
};

// ========== DEMO / OFFLINE FALLBACK ==========
const DEMO_USER = {
  id: 0,
  name: 'Demo Felhasználó',
  firstName: 'Felhasználó',
  lastName: 'Demo',
  email: 'demo@bszc.hu',
  educationalId: '72345678901',
  role: 'demo',
  isAdmin: false,
  isBanned: false,
  emailVerified: true,
};

const DEMO_TOKEN = 'demo-local-token';

const isDemoSession = () => {
  return localStorage.getItem('suliradio-token') === DEMO_TOKEN;
};

// ========== LOCAL AUTH SYSTEM ==========
// A backend jelenleg nem rendelkezik login/register végponttal,
// ezért a felhasználókezelés localStorage-ban történik.
const LOCAL_USERS_KEY = 'suliradio-users';
const LOCAL_CURRENT_USER_KEY = 'suliradio-current-user';

const hashPassword = async (password) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'suliradio-salt-2026');
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
};

const getLocalUsers = () => {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_USERS_KEY) || '[]');
  } catch {
    return [];
  }
};

const saveLocalUsers = (users) => {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
};

const isLocalSession = () => {
  const token = localStorage.getItem('suliradio-token');
  return token && token.startsWith('local-');
};

const getLocalCurrentUser = () => {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_CURRENT_USER_KEY));
  } catch {
    return null;
  }
};

// ========== HUMAN-FRIENDLY ERROR HANDLING ==========

// HTTP status code → Hungarian message mapping
const HTTP_ERROR_MESSAGES = {
  400: 'Hibás kérés. Kérlek ellenőrizd a megadott adatokat!',
  401: 'A munkameneted lejárt, kérlek jelentkezz be újra!',
  403: 'Nincs jogosultságod ehhez a művelethez!',
  404: 'A keresett elem nem található.',
  405: 'Ez a művelet nem engedélyezett.',
  408: 'A kérés időtúllépés miatt megszakadt. Kérlek próbáld újra!',
  409: 'Ütközés történt – valaki más is módosította ezt az adatot. Kérlek frissítsd az oldalt!',
  413: 'A feltöltött fájl túl nagy!',
  422: 'Kérlek ellenőrizd a megadott adatokat!',
  429: 'Túl sok kérést küldtél! Kérlek várj egy kicsit, majd próbáld újra.',
  500: 'Szerverhiba történt. Kérlek próbáld újra később!',
  502: 'A szerver átmenetileg nem elérhető. Kérlek próbáld újra később!',
  503: 'A szerver jelenleg karbantartás alatt áll. Kérlek próbáld újra később!',
};

// Patterns that indicate technical/SQL errors that should never be shown to users
const TECHNICAL_ERROR_PATTERNS = [
  /SQLSTATE/i,
  /SQL.*error/i,
  /query.*exception/i,
  /column.*not.*found/i,
  /table.*doesn.*exist/i,
  /syntax.*error/i,
  /deadlock/i,
  /duplicate.*entry/i,
  /foreign.*key.*constraint/i,
  /integrity.*constraint/i,
  /undefined.*index/i,
  /undefined.*variable/i,
  /call.*to.*undefined/i,
  /class.*not.*found/i,
  /ErrorException/i,
  /BadMethodCallException/i,
  /LogicException/i,
  /RuntimeException/i,
  /TypeError/i,
  /ParseError/i,
  /stack\s*trace/i,
  /vendor\//i,
  /\.php:\d+/i,
  /PDOException/i,
  /Illuminate\\/i,
  /Symfony\\/i,
  /Base table/i,
  /route.*could not be found/i,
  /method.*not.*allowed/i,
  /target class.*does not exist/i,
];

/**
 * Sanitize error message - replace technical errors with user-friendly messages
 */
const sanitizeErrorMessage = (message, statusCode) => {
  if (!message || typeof message !== 'string') {
    return HTTP_ERROR_MESSAGES[statusCode] || 'Ismeretlen hiba történt. Kérlek próbáld újra!';
  }

  // Check if the message contains any technical patterns
  const isTechnical = TECHNICAL_ERROR_PATTERNS.some(pattern => pattern.test(message));
  if (isTechnical) {
    return HTTP_ERROR_MESSAGES[statusCode] || 'Váratlan hiba történt. Kérlek próbáld újra később!';
  }

  return message;
};

// Helper to make authenticated requests
const apiRequest = async (endpoint, options = {}) => {
  const token = getToken();
  
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    });

    // Handle non-JSON responses (e.g. HTML error pages from server crashes)
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      if (!response.ok) {
        throw new Error(
          HTTP_ERROR_MESSAGES[response.status] || 'A szerver váratlan választ küldött. Kérlek próbáld újra később!'
        );
      }
      // For OK non-JSON responses (like file downloads), return raw response
      return response;
    }

    const data = await response.json();

    if (!response.ok) {
      // Handle validation errors - extract the first human-readable validation message
      if (response.status === 422 && data.errors) {
        const firstError = Object.values(data.errors)[0];
        const errorMsg = Array.isArray(firstError) ? firstError[0] : firstError;
        throw new Error(sanitizeErrorMessage(errorMsg, 422));
      }

      // Handle 401 - auto-clear token if session expired
      if (response.status === 401) {
        // Don't clear token for login attempts
        if (!endpoint.includes('/login') && !endpoint.includes('/register')) {
          localStorage.removeItem('suliradio-token');
        }
      }

      // Use server's error message if it's human-friendly, otherwise use our mapping
      const serverMessage = data.error || data.message;
      throw new Error(sanitizeErrorMessage(serverMessage, response.status));
    }

    return data;
  } catch (error) {
    // Network errors (server unreachable, CORS, DNS, etc.)
    if (error.name === 'TypeError' && (error.message === 'Failed to fetch' || error.message.includes('NetworkError'))) {
      throw new Error('Nem sikerült csatlakozni a szerverhez. Ellenőrizd az internetkapcsolatod, vagy hogy a szerver fut-e!');
    }

    // AbortError (request was cancelled / timed out)
    if (error.name === 'AbortError') {
      throw new Error('A kérés megszakadt. Kérlek próbáld újra!');
    }

    // JSON parse errors (server returned invalid JSON)
    if (error instanceof SyntaxError && error.message.includes('JSON')) {
      throw new Error('A szerver váratlan választ küldött. Kérlek próbáld újra később!');
    }

    // Re-throw our own sanitized errors
    throw error;
  }
};

// ========== AUTH ==========
export const authAPI = {
  register: async (data) => {
    const users = getLocalUsers();

    // Email ellenőrzés
    if (users.some(u => u.email.toLowerCase() === data.email.toLowerCase())) {
      return { success: false, error: 'Ez az email cím már regisztrálva van!' };
    }

    // Oktatási azonosító ellenőrzés
    if (data.educationalId && users.some(u => u.educationalId === data.educationalId)) {
      return { success: false, error: 'Ez az oktatási azonosító már használatban van!' };
    }

    const passwordHash = await hashPassword(data.password);
    const newUser = {
      id: Date.now(),
      name: data.name,
      email: data.email,
      educationalId: data.educationalId || '',
      classGroup: data.classGroup || '',
      passwordHash,
      role: 'user',
      isAdmin: false,
      isBanned: false,
      emailVerified: true,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    saveLocalUsers(users);

    return { success: true, user: { ...newUser, passwordHash: undefined } };
  },

  login: async (identifier, password) => {
    const users = getLocalUsers();
    const passwordHash = await hashPassword(password);

    // Keresés email vagy oktatási azonosító alapján
    const user = users.find(u =>
      (u.email.toLowerCase() === identifier.toLowerCase() || u.educationalId === identifier) &&
      u.passwordHash === passwordHash
    );

    if (user) {
      const token = 'local-' + Date.now() + '-' + Math.random().toString(36).substring(2);
      const userData = {
        id: user.id,
        name: user.name,
        firstName: user.name.split(' ').slice(1).join(' ') || user.name,
        lastName: user.name.split(' ')[0] || '',
        email: user.email,
        educationalId: user.educationalId,
        classGroup: user.classGroup,
        role: user.role,
        isAdmin: user.isAdmin,
        isBanned: user.isBanned,
        emailVerified: user.emailVerified,
      };
      localStorage.setItem(LOCAL_CURRENT_USER_KEY, JSON.stringify(userData));
      return { success: true, token, user: userData };
    }

    // Hibás adatok – nem árulunk el, hogy a felhasználó létezik-e (biztonsági okokból)
    return { success: false, error: 'Hibás email cím/oktatási azonosító vagy jelszó!' };
  },

  logout: () => {
    localStorage.removeItem('suliradio-token');
    localStorage.removeItem(LOCAL_CURRENT_USER_KEY);
    return Promise.resolve({ success: true });
  },

  me: () => {
    if (isDemoSession()) {
      return Promise.resolve({ success: true, user: DEMO_USER });
    }
    if (isLocalSession()) {
      const user = getLocalCurrentUser();
      if (user) {
        return Promise.resolve({ success: true, user });
      }
    }
    return Promise.resolve({ success: false });
  },

  demoLogin: () => {
    return Promise.resolve({
      success: true,
      token: DEMO_TOKEN,
      user: DEMO_USER,
    });
  },

  updateProfile: (data) => {
    if (isDemoSession()) {
      return Promise.resolve({ success: true, user: { ...DEMO_USER, ...data } });
    }
    if (isLocalSession()) {
      const currentUser = getLocalCurrentUser();
      if (currentUser) {
        const updatedUser = { ...currentUser, ...data };
        localStorage.setItem(LOCAL_CURRENT_USER_KEY, JSON.stringify(updatedUser));

        // Frissítés a users listában is
        const users = getLocalUsers();
        const idx = users.findIndex(u => u.id === currentUser.id);
        if (idx !== -1) {
          users[idx] = { ...users[idx], ...data };
          saveLocalUsers(users);
        }
        return Promise.resolve({ success: true, user: updatedUser });
      }
    }
    return Promise.resolve({ success: false, error: 'A profil szerkesztése jelenleg nem elérhető.' });
  },

  // A backend meglévő végpontja: szerver idő lekérdezése
  getServerTime: () => apiRequest('/ido'),
};

// ========== SONGS ==========
// A backend jelenleg nem rendelkezik zenei végpontokkal.
// Üres adatot adunk vissza a konzol-spam elkerülése érdekében.
export const songsAPI = {
  getAll: (params = {}) => Promise.resolve({
    success: true,
    songs: [],
  }),

  getOne: (id) => Promise.resolve({
    success: false,
    error: 'A zene nem található.',
  }),

  getGenres: () => Promise.resolve({
    success: true,
    genres: [],
  }),

  getStats: () => Promise.resolve({
    success: true,
    stats: {
      totalSongs: 0,
      todayRequests: 0,
      activeUsers: 0,
      currentListeners: 0,
      currentlyPlaying: null,
    },
  }),
};

// ========== SCHEDULE ==========
export const scheduleAPI = {
  get: (date) => Promise.resolve({
    success: true,
    schedule: [],
    date: date || new Date().toISOString().split('T')[0],
  }),
};

// ========== SONG REQUESTS ==========
export const requestsAPI = {
  create: (songIds, message) => Promise.resolve({
    success: false,
    error: 'A zenekérés funkció jelenleg nem elérhető.',
  }),

  history: () => Promise.resolve({
    success: true,
    history: [],
  }),

  dailyStatus: () => Promise.resolve({
    success: true,
    maxDaily: 3,
    usedToday: 0,
    remaining: 3,
    requestedSongIds: [],
    lastRequestedSongId: null,
  }),
};

// ========== SUBMISSIONS ==========
export const submissionsAPI = {
  create: (data) => Promise.resolve({
    success: false,
    error: 'A zenefeltöltés jelenleg nem elérhető.',
  }),

  mine: () => Promise.resolve({
    success: true,
    submissions: [],
  }),
};

// ========== FAVORITES ==========
export const favoritesAPI = {
  getAll: () => Promise.resolve({
    success: true,
    favorites: [],
  }),

  add: (songId) => Promise.resolve({
    success: false,
    error: 'A kedvencek funkció jelenleg nem elérhető.',
  }),

  remove: (songId) => Promise.resolve({
    success: false,
    error: 'A kedvencek funkció jelenleg nem elérhető.',
  }),
};

// ========== ADMIN ==========
export const adminAPI = {
  dashboard: () => Promise.resolve({
    success: false,
    error: 'Az admin felület jelenleg nem elérhető.',
  }),

  getSubmissions: (status = 'pending') => Promise.resolve({ success: true, submissions: [] }),
  approveSubmission: (id, data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  rejectSubmission: (id, data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),

  getRequests: (status = 'pending') => Promise.resolve({ success: true, requests: [] }),
  approveRequest: (id, data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  rejectRequest: (id, data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  setPlaying: (id) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  setCompleted: (id) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  reorderRequest: (id, direction) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  deleteRequest: (id) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),

  getSongs: () => Promise.resolve({ success: true, songs: [] }),
  createSong: (data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  updateSong: (id, data) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
  deleteSong: (id) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),

  getUsers: () => Promise.resolve({ success: true, users: [] }),
  updateUserRole: (id, role) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),

  getConversionStatus: () => Promise.resolve({ success: true, conversions: [] }),
  retryConversion: (songId) => Promise.resolve({ success: false, error: 'Nem elérhető.' }),
};

export default apiRequest;

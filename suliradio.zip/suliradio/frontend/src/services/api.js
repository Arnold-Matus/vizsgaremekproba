const API_URL = 'http://localhost:8000/api';

// Helper to get stored token
const getToken = () => {
  return localStorage.getItem('suliradio-token');
};

// ========== HUMAN-FRIENDLY ERROR HANDLING ==========

// HTTP status code → Hungarian message mapping
const HTTP_ERROR_MESSAGES = {
  400: 'Hibás kérés. Kérlek ellenőrizd a megadott adatokat!',
  401: 'A munkameneted lejárt, kérlek jelentkezz be újra!',
  403: 'Nincs jogosultságod ehhez a művelethez!',
  404: 'A keresett elem nem található.',
  405: 'Ez a művelet nem engedélyezett.',
  408: 'A kérés időtúllépés miatt megszakadt. Kérlek próbáld újra!',
  409: 'Ütközés történt – valaki más is módosította ezt az adatot. Kérlek frissítsd az oldalt!',
  413: 'A feltöltött fájl túl nagy!',
  422: 'Kérlek ellenőrizd a megadott adatokat!',
  429: 'Túl sok kérést küldtél! Kérlek várj egy kicsit, majd próbáld újra.',
  500: 'Szerverhiba történt. Kérlek próbáld újra később!',
  502: 'A szerver átmenetileg nem elérhető. Kérlek próbáld újra később!',
  503: 'A szerver jelenleg karbantartás alatt áll. Kérlek próbáld újra később!',
};

// Patterns that indicate technical/SQL errors that should never be shown to users
const TECHNICAL_ERROR_PATTERNS = [
  /SQLSTATE/i,
  /SQL.*error/i,
  /query.*exception/i,
  /column.*not.*found/i,
  /table.*doesn.*exist/i,
  /syntax.*error/i,
  /deadlock/i,
  /duplicate.*entry/i,
  /foreign.*key.*constraint/i,
  /integrity.*constraint/i,
  /undefined.*index/i,
  /undefined.*variable/i,
  /call.*to.*undefined/i,
  /class.*not.*found/i,
  /ErrorException/i,
  /BadMethodCallException/i,
  /LogicException/i,
  /RuntimeException/i,
  /TypeError/i,
  /ParseError/i,
  /stack\s*trace/i,
  /vendor\//i,
  /\.php:\d+/i,
  /PDOException/i,
  /Illuminate\\/i,
  /Symfony\\/i,
  /Base table/i,
];

/**
 * Sanitize error message - replace technical errors with user-friendly messages
 */
const sanitizeErrorMessage = (message, statusCode) => {
  if (!message || typeof message !== 'string') {
    return HTTP_ERROR_MESSAGES[statusCode] || 'Ismeretlen hiba történt. Kérlek próbáld újra!';
  }

  // Check if the message contains any technical patterns
  const isTechnical = TECHNICAL_ERROR_PATTERNS.some(pattern => pattern.test(message));
  if (isTechnical) {
    return HTTP_ERROR_MESSAGES[statusCode] || 'Váratlan hiba történt. Kérlek próbáld újra később!';
  }

  return message;
};

// Helper to make authenticated requests
const apiRequest = async (endpoint, options = {}) => {
  const token = getToken();
  
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    });

    // Handle non-JSON responses (e.g. HTML error pages from server crashes)
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      if (!response.ok) {
        throw new Error(
          HTTP_ERROR_MESSAGES[response.status] || 'A szerver váratlan választ küldött. Kérlek próbáld újra később!'
        );
      }
      // For OK non-JSON responses (like file downloads), return raw response
      return response;
    }

    const data = await response.json();

    if (!response.ok) {
      // Handle validation errors - extract the first human-readable validation message
      if (response.status === 422 && data.errors) {
        const firstError = Object.values(data.errors)[0];
        const errorMsg = Array.isArray(firstError) ? firstError[0] : firstError;
        throw new Error(sanitizeErrorMessage(errorMsg, 422));
      }

      // Handle 401 - auto-clear token if session expired
      if (response.status === 401) {
        // Don't clear token for login attempts
        if (!endpoint.includes('/login') && !endpoint.includes('/register')) {
          localStorage.removeItem('suliradio-token');
        }
      }

      // Use server's error message if it's human-friendly, otherwise use our mapping
      const serverMessage = data.error || data.message;
      throw new Error(sanitizeErrorMessage(serverMessage, response.status));
    }

    return data;
  } catch (error) {
    // Network errors (server unreachable, CORS, DNS, etc.)
    if (error.name === 'TypeError' && (error.message === 'Failed to fetch' || error.message.includes('NetworkError'))) {
      throw new Error('Nem sikerült csatlakozni a szerverhez. Ellenőrizd az internetkapcsolatod, vagy hogy a szerver fut-e!');
    }

    // AbortError (request was cancelled / timed out)
    if (error.name === 'AbortError') {
      throw new Error('A kérés megszakadt. Kérlek próbáld újra!');
    }

    // JSON parse errors (server returned invalid JSON)
    if (error instanceof SyntaxError && error.message.includes('JSON')) {
      throw new Error('A szerver váratlan választ küldött. Kérlek próbáld újra később!');
    }

    // Re-throw our own sanitized errors
    throw error;
  }
};

// ========== AUTH ==========
export const authAPI = {
  register: (data) => apiRequest('/register', {
    method: 'POST',
    body: JSON.stringify({
      name: data.name,
      email: data.email,
      password: data.password,
      educational_id: data.educationalId,
      class_group: data.classGroup,
    }),
  }),

  login: (identifier, password) => apiRequest('/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  }),

  logout: () => apiRequest('/logout', { method: 'POST' }),

  me: () => apiRequest('/me'),

  updateProfile: (data) => apiRequest('/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
};

// ========== SONGS ==========
export const songsAPI = {
  getAll: (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.set('search', params.search);
    if (params.genre) query.set('genre', params.genre);
    if (params.sortBy) query.set('sort_by', params.sortBy);
    if (params.sortOrder) query.set('sort_order', params.sortOrder);
    const qs = query.toString();
    return apiRequest(`/songs${qs ? `?${qs}` : ''}`);
  },

  getOne: (id) => apiRequest(`/songs/${id}`),

  getGenres: () => apiRequest('/songs/genres'),

  getStats: () => apiRequest('/stats'),
};

// ========== SCHEDULE ==========
export const scheduleAPI = {
  get: (date) => {
    const query = date ? `?date=${date}` : '';
    return apiRequest(`/schedule${query}`);
  },
};

// ========== SONG REQUESTS ==========
export const requestsAPI = {
  create: (songIds, message) => apiRequest('/requests', {
    method: 'POST',
    body: JSON.stringify({ song_ids: songIds, message }),
  }),

  history: () => apiRequest('/requests/history'),

  dailyStatus: () => apiRequest('/requests/daily-status'),
};

// ========== SUBMISSIONS ==========
export const submissionsAPI = {
  create: (data) => apiRequest('/submissions', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  mine: () => apiRequest('/submissions/mine'),
};

// ========== FAVORITES ==========
export const favoritesAPI = {
  getAll: () => apiRequest('/favorites'),

  add: (songId) => apiRequest('/favorites', {
    method: 'POST',
    body: JSON.stringify({ song_id: songId }),
  }),

  remove: (songId) => apiRequest(`/favorites/${songId}`, {
    method: 'DELETE',
  }),
};

// ========== ADMIN ==========
export const adminAPI = {
  dashboard: () => apiRequest('/admin/dashboard'),

  // Submissions
  getSubmissions: (status = 'pending') => apiRequest(`/admin/submissions?status=${status}`),
  approveSubmission: (id, data) => apiRequest(`/admin/submissions/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  rejectSubmission: (id, data) => apiRequest(`/admin/submissions/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  // Song Requests
  getRequests: (status = 'pending') => apiRequest(`/admin/requests?status=${status}`),
  approveRequest: (id, data) => apiRequest(`/admin/requests/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  rejectRequest: (id, data) => apiRequest(`/admin/requests/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  setPlaying: (id) => apiRequest(`/admin/requests/${id}/playing`, { method: 'POST' }),
  setCompleted: (id) => apiRequest(`/admin/requests/${id}/completed`, { method: 'POST' }),
  reorderRequest: (id, direction) => apiRequest(`/admin/requests/${id}/reorder`, {
    method: 'POST',
    body: JSON.stringify({ direction }),
  }),
  deleteRequest: (id) => apiRequest(`/admin/requests/${id}`, { method: 'DELETE' }),

  // Songs
  getSongs: () => apiRequest('/admin/songs'),
  createSong: (data) => apiRequest('/admin/songs', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  updateSong: (id, data) => apiRequest(`/admin/songs/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  deleteSong: (id) => apiRequest(`/admin/songs/${id}`, { method: 'DELETE' }),

  // Users
  getUsers: () => apiRequest('/admin/users'),
  updateUserRole: (id, role) => apiRequest(`/admin/users/${id}/role`, {
    method: 'PUT',
    body: JSON.stringify({ role }),
  }),

  // Conversion
  getConversionStatus: () => apiRequest('/admin/conversion/status'),
  retryConversion: (songId) => apiRequest(`/admin/conversion/${songId}/retry`, {
    method: 'POST',
  }),
};

export default apiRequest;

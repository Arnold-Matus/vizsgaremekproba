﻿import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  PlusCircle, 
  Link as LinkIcon, 
  Music, 
  Send, 
  CheckCircle, 
  AlertCircle,
  Info,
  Loader2,
  User,
  ExternalLink
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { submissionsAPI } from '../services/api';

const SUPPORTED_PLATFORMS = [
  { name: 'YouTube', icon: '🎬', example: 'https://youtube.com/watch?v=...' },
  { name: 'YouTube Music', icon: '🎵', example: 'https://music.youtube.com/watch?v=...' },
  { name: 'Spotify', icon: '💚', example: 'https://open.spotify.com/track/...' },
  { name: 'SoundCloud', icon: '🟠', example: 'https://soundcloud.com/artist/track' },
  { name: 'Apple Music', icon: '🍎', example: 'https://music.apple.com/...' },
  { name: 'Deezer', icon: '🎧', example: 'https://deezer.com/track/...' },
  { name: 'Tidal', icon: '🌊', example: 'https://tidal.com/browse/track/...' },
  { name: 'Bandcamp', icon: '📀', example: 'https://artist.bandcamp.com/track/...' },
];

const AddMusicPage = () => {
  const { isLoggedIn } = useUser();

  const [linkData, setLinkData] = useState({
    url: '',
    title: '',
    artist: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);
  const [detectedPlatform, setDetectedPlatform] = useState(null);

  const handleLinkChange = (e) => {
    const { name, value } = e.target;
    setLinkData(prev => ({ ...prev, [name]: value }));
    
    // Automatikusan felismeri a platformot URL beírásakor
    if (name === 'url') {
      const url = value.toLowerCase();
      if (url.includes('music.youtube.com')) setDetectedPlatform('YouTube Music');
      else if (url.includes('youtube.com') || url.includes('youtu.be')) setDetectedPlatform('YouTube');
      else if (url.includes('spotify.com')) setDetectedPlatform('Spotify');
      else if (url.includes('soundcloud.com')) setDetectedPlatform('SoundCloud');
      else if (url.includes('music.apple.com')) setDetectedPlatform('Apple Music');
      else if (url.includes('deezer.com') || url.includes('deezer.page.link')) setDetectedPlatform('Deezer');
      else if (url.includes('tidal.com') || url.includes('listen.tidal.com')) setDetectedPlatform('Tidal');
      else if (url.includes('bandcamp.com')) setDetectedPlatform('Bandcamp');
      else setDetectedPlatform(null);
    }
  };

  const handleLinkSubmit = async (e) => {
    e.preventDefault();
    
    if (!isLoggedIn) {
      setSubmitResult({ type: 'error', message: 'Kérlek jelentkezz be a zene hozzáadásához!' });
      return;
    }
    
    if (!linkData.url.trim()) {
      setSubmitResult({ type: 'error', message: 'Add meg a zene linkjét!' });
      return;
    }

    setIsSubmitting(true);
    setSubmitResult(null);

    try {
      const data = await submissionsAPI.create({
        url: linkData.url,
        title: linkData.title,
        artist: linkData.artist,
        message: linkData.message,
      });

      setSubmitResult({ 
        type: 'success', 
        message: data.message || 'Zenekérésed sikeresen elküldve! A moderátorok hamarosan átnézik.' 
      });
      setLinkData({ url: '', title: '', artist: '', message: '' });
      setDetectedPlatform(null);
    } catch (error) {
      setSubmitResult({ type: 'error', message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="page request-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <PlusCircle size={32} className="page-icon" />
          <div>
            <h1 className="page-title">Zene hozzáadása</h1>
            <p className="page-subtitle">
              Küldj be egy linket a kedvenc zenédhez, és a moderátorok hozzáadják a könyvtárhoz!
            </p>
          </div>
        </div>
      </section>

      {/* Login warning */}
      {!isLoggedIn && (
        <div className="warning-banner" role="alert">
          <AlertCircle size={20} />
          <p>
            Zene hozzáadásához be kell jelentkezned. 
            <Link to="/bejelentkezes"> Jelentkezz be</Link> vagy 
            <Link to="/regisztracio"> regisztrálj</Link>!
          </p>
        </div>
      )}

      {/* Supported platforms */}
      <div className="result-banner" style={{ 
        background: 'var(--color-info-bg)', 
        border: '1px solid var(--color-info)',
        color: 'var(--color-info)'
      }}>
        <Info size={20} />
        <div style={{ color: 'var(--color-text)' }}>
          <p style={{ marginBottom: '0.5rem', fontWeight: 500 }}>
            Támogatott platformok:
          </p>
          <div style={{ 
            display: 'flex', 
            flexWrap: 'wrap', 
            gap: '0.5rem',
          }}>
            {SUPPORTED_PLATFORMS.map(p => (
              <span key={p.name} style={{
                background: 'var(--color-background)',
                padding: '0.25rem 0.75rem',
                borderRadius: 'var(--radius-full)',
                fontSize: '0.85rem',
                border: '1px solid var(--color-border)',
              }}>
                {p.icon} {p.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Submit result */}
      {submitResult && (
        <div className={`result-banner ${submitResult.type}`} role="alert">
          {submitResult.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
          <p>{submitResult.message}</p>
          <button onClick={() => setSubmitResult(null)} aria-label="Bezárás">×</button>
        </div>
      )}

      {/* Link submission form */}
      <div className="request-content">
        <div className="library-request">
          <form onSubmit={handleLinkSubmit} className="link-request-form">
            <div className="form-group">
              <label htmlFor="url">
                <LinkIcon size={16} />
                Zene linkje *
              </label>
              <input
                type="url"
                id="url"
                name="url"
                value={linkData.url}
                onChange={handleLinkChange}
                placeholder="https://youtube.com/watch?v=... vagy más platform link"
                className="form-input"
                disabled={isSubmitting}
                required
              />
              {detectedPlatform && (
                <small style={{ 
                  color: 'var(--color-success)', 
                  marginTop: '0.5rem', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '0.25rem' 
                }}>
                  <CheckCircle size={14} />
                  Felismert platform: <strong>{detectedPlatform}</strong>
                </small>
              )}
              {linkData.url && !detectedPlatform && linkData.url.length > 10 && (
                <small style={{ 
                  color: 'var(--color-error)', 
                  marginTop: '0.5rem', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '0.25rem' 
                }}>
                  <AlertCircle size={14} />
                  Nem felismert platform — csak a támogatott platformok linkjeit fogadjuk el
                </small>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="title">
                <Music size={16} />
                Zene címe <span className="optional">(opcionális)</span>
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={linkData.title}
                onChange={handleLinkChange}
                placeholder="Pl.: Bohemian Rhapsody"
                className="form-input"
                disabled={isSubmitting}
              />
            </div>

            <div className="form-group">
              <label htmlFor="artist">
                <User size={16} />
                Előadó <span className="optional">(opcionális)</span>
              </label>
              <input
                type="text"
                id="artist"
                name="artist"
                value={linkData.artist}
                onChange={handleLinkChange}
                placeholder="Pl.: Queen"
                className="form-input"
                disabled={isSubmitting}
              />
            </div>

            <div className="form-group">
              <label htmlFor="message">
                <Info size={16} />
                Üzenet a moderátoroknak <span className="optional">(opcionális)</span>
              </label>
              <textarea
                id="message"
                name="message"
                value={linkData.message}
                onChange={handleLinkChange}
                placeholder="Ha van valami amit tudnunk kell a zenéről..."
                className="form-input"
                rows={3}
                disabled={isSubmitting}
                style={{ resize: 'vertical' }}
              />
            </div>

            <button 
              type="submit" 
              className="submit-btn"
              disabled={isSubmitting || !isLoggedIn}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={18} className="spinning" />
                  Küldés...
                </>
              ) : (
                <>
                  <Send size={18} />
                  Link beküldése
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Platform examples */}
      <section style={{ marginTop: '2rem' }}>
        <h2 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <ExternalLink size={20} />
          Támogatott platformok és példa linkek
        </h2>
        <div style={{ 
          background: 'var(--color-surface)', 
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-lg)',
          padding: '1.5rem',
          display: 'grid',
          gap: '0.75rem',
        }}>
          {SUPPORTED_PLATFORMS.map(p => (
            <div key={p.name} style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              padding: '0.5rem',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-background)',
            }}>
              <span style={{ fontSize: '1.5rem', width: '2rem', textAlign: 'center' }}>{p.icon}</span>
              <div>
                <strong style={{ color: 'var(--color-text)' }}>{p.name}</strong>
                <div style={{ 
                  fontSize: '0.8rem', 
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'monospace',
                }}>
                  {p.example}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Guidelines */}
      <section style={{ marginTop: '2rem' }}>
        <h2 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Info size={20} />
          Irányelvek
        </h2>
        <div style={{ 
          background: 'var(--color-surface)', 
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-lg)',
          padding: '1.5rem'
        }}>
          <ul style={{ 
            listStyle: 'disc', 
            paddingLeft: '1.5rem',
            display: 'grid',
            gap: '0.5rem',
            color: 'var(--color-text-secondary)'
          }}>
            <li>Csak a fenti platformokról fogadunk el linkeket</li>
            <li>A cím és előadó megadása segíti a moderátorokat a gyorsabb feldolgozásban</li>
            <li>Kerüld a trágár vagy sértő tartalmú zenéket</li>
            <li>A zenék hossza maximum 10 perc lehet</li>
            <li>A moderátorok fenntartják a jogot a zenék elutasítására</li>
            <li>A feldolgozás általában 1-2 napot vesz igénybe</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default AddMusicPage;

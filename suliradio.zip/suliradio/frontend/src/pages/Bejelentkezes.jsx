﻿import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useUser } from '../contexts/FelhasznaloKontextus';

const REMEMBERED_IDENTIFIER_KEY = 'suliradio-remembered-identifier';

const getRememberedIdentifier = () => {
  if (typeof window === 'undefined') {
    return '';
  }

  return localStorage.getItem(REMEMBERED_IDENTIFIER_KEY) || '';
};

const persistRememberedIdentifier = (identifier) => {
  const trimmedIdentifier = identifier.trim();
  if (!trimmedIdentifier) return '';
  localStorage.setItem(REMEMBERED_IDENTIFIER_KEY, trimmedIdentifier);
  return trimmedIdentifier;
};

const clearRememberedIdentifier = () => {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.removeItem(REMEMBERED_IDENTIFIER_KEY);
};

const getStoredPasswordCredential = async (expectedIdentifier, { interactive = false } = {}) => {
  if (
    typeof window === 'undefined' ||
    !navigator.credentials?.get
  ) {
    return null;
  }

  const mediations = interactive ? ['required', 'optional'] : ['optional'];

  for (const mediation of mediations) {
    try {
      const credential = await navigator.credentials.get({
        password: true,
        mediation,
      });

      if (!credential || typeof credential.password !== 'string' || !credential.password) {
        continue;
      }

      const credentialIdentifier = String(credential.id || '').trim().toLowerCase();
      const normalizedExpected = String(expectedIdentifier || '').trim().toLowerCase();
      if (normalizedExpected && credentialIdentifier !== normalizedExpected) {
        continue;
      }

      return {
        id: String(credential.id || '').trim(),
        password: credential.password,
      };
    } catch {
      // Try the next supported mediation mode.
    }
  }

  return null;
};

const storeCredentialsInBrowser = async (form, identifier, password) => {
  if (
    typeof window === 'undefined' ||
    !('PasswordCredential' in window) ||
    !navigator.credentials?.store
  ) {
    return;
  }

  try {
    const credential = form instanceof HTMLFormElement
      ? new window.PasswordCredential(form)
      : new window.PasswordCredential({
          id: identifier.trim(),
          password,
          name: identifier.trim(),
        });

    await navigator.credentials.store(credential);
  } catch {
    // A browser password manager is optional, so failures are ignored.
  }
};

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, demoLogin, isLoggedIn } = useUser();
  const formRef = useRef(null);
  const passwordInputRef = useRef(null);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rememberedIdentifierValue, setRememberedIdentifierValue] = useState(() => getRememberedIdentifier());
  const [rememberIdentifier, setRememberIdentifier] = useState(() => Boolean(getRememberedIdentifier()));

  useEffect(() => {
    if (isLoggedIn) {
      navigate('/', { replace: true });
    }
  }, [isLoggedIn, navigate]);

  useEffect(() => {
    setSuccessMessage(location.state?.message || '');
  }, [location]);

  const finalizeRememberedIdentifier = (trimmedIdentifier) => {
    if (rememberIdentifier) {
      const rememberedValue = persistRememberedIdentifier(trimmedIdentifier);
      setRememberedIdentifierValue(rememberedValue);
      return;
    }

    clearRememberedIdentifier();
    setRememberedIdentifierValue('');
  };

  const submitLogin = async ({ nextIdentifier, nextPassword, formElement }) => {
    const trimmedIdentifier = nextIdentifier.trim();

    if (!trimmedIdentifier || !nextPassword) {
      setError('Kérlek töltsd ki az összes mezőt!');
      return false;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const result = await login(trimmedIdentifier, nextPassword);
      if (result.success) {
        finalizeRememberedIdentifier(trimmedIdentifier);
        if (rememberIdentifier) {
          await storeCredentialsInBrowser(formElement || formRef.current, trimmedIdentifier, nextPassword);
        }
        navigate('/');
        return true;
      }

      setError(result.error || 'Hibás bejelentkezési adatok!');
      return false;
    } catch {
      setError('Hiba történt a bejelentkezés során!');
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRememberIdentifierToggle = (checked) => {
    setRememberIdentifier(checked);

    if (!checked) {
      clearRememberedIdentifier();
      setRememberedIdentifierValue('');
    }
  };

  const handleUseRememberedIdentifier = async () => {
    const trimmedIdentifier = rememberedIdentifierValue.trim();
    if (!trimmedIdentifier) {
      return;
    }

    setIdentifier(trimmedIdentifier);
    setRememberIdentifier(true);
    setError('');

    const storedCredential = await getStoredPasswordCredential(trimmedIdentifier, { interactive: true });
    if (storedCredential?.password) {
      setPassword(storedCredential.password);
      const loggedIn = await submitLogin({
        nextIdentifier: trimmedIdentifier,
        nextPassword: storedCredential.password,
        formElement: formRef.current,
      });

      if (loggedIn) {
        return;
      }
    } else {
      setPassword('');
    }

    requestAnimationFrame(() => {
      passwordInputRef.current?.focus();
    });
  };

  const handleForgetRememberedIdentifier = () => {
    clearRememberedIdentifier();
    setRememberedIdentifierValue('');
    setRememberIdentifier(false);
    if (identifier.trim() === rememberedIdentifierValue.trim()) {
      setIdentifier('');
      setPassword('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await submitLogin({
      nextIdentifier: identifier,
      nextPassword: password,
      formElement: e.currentTarget,
    });
  };

  const handleDemoLogin = async () => {
    setIsSubmitting(true);
    setError('');
    try {
      const result = await demoLogin();
      if (result && result.success) {
        navigate('/');
      } else {
        setError(result?.error || 'Demo bejelentkezés sikertelen! Ellenőrizd, hogy a backend szerver fut-e.');
      }
    } catch {
      setError('Nem sikerült csatlakozni a szerverhez. Ellenőrizd, hogy a backend fut-e!');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="auth-logo-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <path d="M8 12a4 4 0 0 0 8 0"/>
              <path d="M12 8v.01"/>
            </svg>
          </div>
          <h1>SuliRadio</h1>
        </div>

        <h2 className="auth-title">Bejelentkezés</h2>
        <p className="auth-subtitle">Üdv újra! Kérlek jelentkezz be a fiókodba.</p>

        {successMessage && (
          <div className="auth-message success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
            <span>{successMessage}</span>
          </div>
        )}

        {error && (
          <div className="auth-message error">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{error}</span>
          </div>
        )}

        {rememberedIdentifierValue && (
          <div className="remembered-account-panel">
            <button
              type="button"
              className="remembered-account-card"
              onClick={handleUseRememberedIdentifier}
              disabled={isSubmitting}
            >
              <span className="remembered-account-avatar" aria-hidden="true">
                {rememberedIdentifierValue.slice(0, 1).toUpperCase()}
              </span>
              <span className="remembered-account-content">
                <strong>{rememberedIdentifierValue}</strong>
                <span>Folytatás ezzel a fiókkal</span>
              </span>
              <span className="remembered-account-chevron" aria-hidden="true">›</span>
            </button>

            <div className="remembered-account-actions">
              <button
                type="button"
                className="remembered-account-action"
                onClick={handleForgetRememberedIdentifier}
                disabled={isSubmitting}
              >
                Elfelejtés
              </button>
              <span className="remembered-account-hint">
                Ha a böngésző mentette a jelszót, egy kattintással beléphetsz.
              </span>
            </div>
          </div>
        )}

        <form ref={formRef} onSubmit={handleSubmit} className="auth-form" autoComplete="on">
          <div className="form-group">
            <label htmlFor="identifier">Email cím</label>
            <input
              type="email"
              id="identifier"
              name="email"
              value={identifier}
              onChange={(e) => {
                setIdentifier(e.target.value);
                setError('');
              }}
              placeholder="pelda@bszc.hu"
              disabled={isSubmitting}
              autoComplete="username"
              autoCapitalize="none"
              autoFocus
            />
            <small style={{ color: 'var(--color-text-secondary)' }}>
              A jelenlegi bejelentkezés email címmel működik.
            </small>
          </div>

          <div className="form-group">
            <div className="form-label-row">
              <label htmlFor="password">Jelszó</label>
              <Link to="/elfelejtett-jelszo" className="form-link">
                Elfelejtett jelszó?
              </Link>
            </div>
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                ref={passwordInputRef}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="••••••••"
                disabled={isSubmitting}
                autoComplete="current-password"
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? 'Jelszó elrejtése' : 'Jelszó mutatása'}
              >
                {showPassword ? (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                )}
              </button>
            </div>
          </div>

          <div className="form-checkboxes">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="remember"
                checked={rememberIdentifier}
                onChange={(e) => handleRememberIdentifierToggle(e.target.checked)}
                disabled={isSubmitting}
              />
              <span className="checkbox-custom" aria-hidden="true"></span>
              <span>Fiók megjegyzése ezen az eszközön</span>
            </label>
          </div>

          <button type="submit" className="auth-submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <span className="spinner"></span>
                Bejelentkezés...
              </>
            ) : (
              'Bejelentkezés'
            )}
          </button>
        </form>

        <div className="auth-divider">
          <span>vagy</span>
        </div>

        <button 
          type="button"
          className="auth-demo-btn"
          onClick={handleDemoLogin}
          disabled={isSubmitting}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          Demo fiók kipróbálása
        </button>

        <p className="auth-footer">
          Még nincs fiókod?{' '}
          <Link to="/regisztracio">Regisztrálj most!</Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;

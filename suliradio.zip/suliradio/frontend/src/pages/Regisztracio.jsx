﻿import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import LanguageToggle from '../components/NyelvValtoGomb';
import AppLogo from '../components/AppLogo';

const RegisterPage = () => {
  const navigate = useNavigate();
  const { register, isLoggedIn } = useUser();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const [formData, setFormData] = useState({
    vezeteknev: '',
    keresztnev: '',
    email: '',
    omazonosito: '',
    password: '',
    passwordConfirm: '',
    acceptTerms: false,
    acceptPrivacy: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordConfirm, setShowPasswordConfirm] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registerError, setRegisterError] = useState('');
  const [registerSuccess, setRegisterSuccess] = useState(false);

  useEffect(() => {
    if (isLoggedIn) {
      navigate('/', { replace: true });
    }
  }, [isLoggedIn, navigate]);

  const passwordRequirements = [
    { id: 'length', label: tr('Legalább 8 karakter', 'At least 8 characters'), test: (p) => p.length >= 8 },
    { id: 'upper', label: tr('Nagybetű (A-Z)', 'Uppercase letter (A-Z)'), test: (p) => /[A-Z]/.test(p) },
    { id: 'lower', label: tr('Kisbetű (a-z)', 'Lowercase letter (a-z)'), test: (p) => /[a-z]/.test(p) },
    { id: 'number', label: tr('Szám (0-9)', 'Number (0-9)'), test: (p) => /[0-9]/.test(p) },
  ];

  const passwordStrength = passwordRequirements.filter(req => req.test(formData.password)).length;

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name === 'omazonosito') {
      if (value.length > 11 || (value && !/^\d*$/.test(value))) return;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
    if (registerError) {
      setRegisterError('');
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.vezeteknev.trim() || formData.vezeteknev.trim().length < 2)
      newErrors.vezeteknev = tr('Add meg a vezetékneved! (minimum 2 karakter)', 'Enter your last name. Minimum 2 characters.');
    if (!formData.keresztnev.trim() || formData.keresztnev.trim().length < 2)
      newErrors.keresztnev = tr('Add meg a keresztneved! (minimum 2 karakter)', 'Enter your first name. Minimum 2 characters.');
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = tr('Add meg az email címed!', 'Enter your email address.');
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = tr('Érvénytelen email cím!', 'Invalid email address.');
    }
    
    if (!formData.omazonosito) {
      newErrors.omazonosito = tr('Add meg az oktatási azonosítód!', 'Enter your education ID.');
    } else if (formData.omazonosito.length !== 11) {
      newErrors.omazonosito = tr('Pontosan 11 számjegy!', 'It must contain exactly 11 digits.');
    }
    
    if (!formData.password) {
      newErrors.password = tr('Add meg a jelszavad!', 'Enter your password.');
    } else if (passwordStrength < 4) {
      newErrors.password = tr('A jelszó nem elég erős!', 'The password is not strong enough.');
    }
    
    if (!formData.passwordConfirm) {
      newErrors.passwordConfirm = tr('Erősítsd meg a jelszavad!', 'Confirm your password.');
    } else if (formData.password !== formData.passwordConfirm) {
      newErrors.passwordConfirm = tr('A jelszavak nem egyeznek!', 'The passwords do not match.');
    }
    
    if (!formData.acceptTerms) newErrors.acceptTerms = tr('Kötelező elfogadni!', 'You must accept this.');
    if (!formData.acceptPrivacy) newErrors.acceptPrivacy = tr('Kötelező elfogadni!', 'You must accept this.');
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setRegisterError('');
    
    try {
      const result = await register({
        vezeteknev: formData.vezeteknev,
        keresztnev: formData.keresztnev,
        email: formData.email,
        omazonosito: formData.omazonosito,
        password: formData.password
      });
      
      if (result.success) {
        setRegisterSuccess(true);
        setTimeout(() => {
          navigate('/bejelentkezes', { state: { message: tr('Sikeres regisztráció! Most már bejelentkezhetsz.', 'Registration successful. You can now sign in.') }});
        }, 1500);
      } else {
        setRegisterError(result.error || tr('Hiba történt a regisztráció során!', 'Registration failed.'));
      }
    } catch {
      setRegisterError(tr('Hiba történt. Próbáld újra később!', 'Something went wrong. Please try again later.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStrengthColor = () => {
    if (passwordStrength <= 1) return '#ef4444';
    if (passwordStrength === 2) return '#f97316';
    if (passwordStrength === 3) return '#eab308';
    return '#22c55e';
  };

  const getStrengthText = () => {
    if (passwordStrength <= 1) return tr('Gyenge', 'Weak');
    if (passwordStrength === 2) return tr('Közepes', 'Medium');
    if (passwordStrength === 3) return tr('Jó', 'Good');
    return tr('Erős', 'Strong');
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card auth-card-wide">
        <div className="auth-language-toggle-row">
          <LanguageToggle />
        </div>
        <div className="auth-logo">
          <div className="auth-logo-icon" aria-hidden="true">
            <AppLogo className="app-logo-image" decorative />
          </div>
          <h1>SuliRadio</h1>
        </div>

        <h2 className="auth-title">{tr('Regisztráció', 'Create account')}</h2>
        <p className="auth-subtitle">{tr('Hozd létre a fiókodat és csatlakozz hozzánk!', 'Create your account and join the SuliRadio community.')}</p>

        {registerError && (
          <div className="auth-message error">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{registerError}</span>
          </div>
        )}

        {registerSuccess && (
          <div className="auth-message success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
            <span>{tr('Sikeres regisztráció! Átirányítás...', 'Registration successful. Redirecting...')}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-row">
            <div className={`form-group ${errors.vezeteknev ? 'has-error' : ''}`}>
              <label htmlFor="vezeteknev">{tr('Vezetéknév', 'Last name')}</label>
              <input
                type="text"
                id="vezeteknev"
                name="vezeteknev"
                value={formData.vezeteknev}
                onChange={handleChange}
                placeholder={tr('Kovács', 'Smith')}
                disabled={isSubmitting}
                autoComplete="family-name"
              />
              {errors.vezeteknev && <span className="error-text">{errors.vezeteknev}</span>}
            </div>

            <div className={`form-group ${errors.keresztnev ? 'has-error' : ''}`}>
              <label htmlFor="keresztnev">{tr('Keresztnév', 'First name')}</label>
              <input
                type="text"
                id="keresztnev"
                name="keresztnev"
                value={formData.keresztnev}
                onChange={handleChange}
                placeholder={tr('Péter', 'Peter')}
                disabled={isSubmitting}
                autoComplete="given-name"
              />
              {errors.keresztnev && <span className="error-text">{errors.keresztnev}</span>}
            </div>
          </div>

          <div className={`form-group ${errors.email ? 'has-error' : ''}`}>
            <label htmlFor="email">{tr('Email cím', 'Email address')}</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder={tr('pelda@bszc.hu', 'example@bszc.hu')}
              disabled={isSubmitting}
              autoComplete="email"
            />
            {errors.email && <span className="error-text">{errors.email}</span>}
          </div>

          <div className="form-row">
            <div className={`form-group ${errors.omazonosito ? 'has-error' : ''}`}>
              <label htmlFor="omazonosito">{tr('Oktatási azonosító', 'Education ID')}</label>
              <input
                type="text"
                id="omazonosito"
                name="omazonosito"
                value={formData.omazonosito}
                onChange={handleChange}
                placeholder="72345678901"
                maxLength={11}
                disabled={isSubmitting}
              />
              {errors.omazonosito && <span className="error-text">{errors.omazonosito}</span>}
            </div>
          </div>

          <div className={`form-group ${errors.password ? 'has-error' : ''}`}>
            <label htmlFor="password">{tr('Jelszó', 'Password')}</label>
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="••••••••"
                disabled={isSubmitting}
                autoComplete="new-password"
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                )}
              </button>
            </div>

            {formData.password && (
              <div className="password-strength">
                <div className="strength-bar">
                  <div 
                    className="strength-fill"
                    style={{ 
                      width: `${(passwordStrength / 4) * 100}%`,
                      backgroundColor: getStrengthColor()
                    }}
                  />
                </div>
                <span style={{ color: getStrengthColor() }}>{getStrengthText()}</span>
              </div>
            )}

            <div className="password-requirements">
              {passwordRequirements.map((req) => (
                <div key={req.id} className={`requirement ${req.test(formData.password) ? 'met' : ''}`}>
                  {req.test(formData.password) ? (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="20,6 9,17 4,12"/>
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="18" y1="6" x2="6" y2="18"/>
                      <line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                  )}
                  <span>{req.label}</span>
                </div>
              ))}
            </div>
            {errors.password && <span className="error-text">{errors.password}</span>}
          </div>

          <div className={`form-group ${errors.passwordConfirm ? 'has-error' : ''}`}>
            <label htmlFor="passwordConfirm">{tr('Jelszó megerősítése', 'Confirm password')}</label>
            <div className="password-input">
              <input
                type={showPasswordConfirm ? 'text' : 'password'}
                id="passwordConfirm"
                name="passwordConfirm"
                value={formData.passwordConfirm}
                onChange={handleChange}
                placeholder="••••••••"
                disabled={isSubmitting}
                autoComplete="new-password"
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPasswordConfirm(!showPasswordConfirm)}
              >
                {showPasswordConfirm ? (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                )}
              </button>
            </div>
            {formData.passwordConfirm && formData.password === formData.passwordConfirm && (
              <span className="success-text">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="20,6 9,17 4,12"/>
                </svg>
                {tr('A jelszavak egyeznek', 'Passwords match')}
              </span>
            )}
            {errors.passwordConfirm && <span className="error-text">{errors.passwordConfirm}</span>}
          </div>

          <div className="form-checkboxes">
            <label className={`checkbox-label ${errors.acceptTerms ? 'has-error' : ''}`}>
              <input
                type="checkbox"
                name="acceptTerms"
                checked={formData.acceptTerms}
                onChange={handleChange}
                disabled={isSubmitting}
              />
              <span className="checkbox-custom"></span>
              <span>{tr('Elfogadom a ', 'I accept the ')}<Link to="/feltetelek" target="_blank">{tr('használati szabályokat', 'terms of use')}</Link></span>
            </label>

            <label className={`checkbox-label ${errors.acceptPrivacy ? 'has-error' : ''}`}>
              <input
                type="checkbox"
                name="acceptPrivacy"
                checked={formData.acceptPrivacy}
                onChange={handleChange}
                disabled={isSubmitting}
              />
              <span className="checkbox-custom"></span>
              <span>{tr('Elfogadom az ', 'I accept the ')}<Link to="/adatvedelem" target="_blank">{tr('privacy notice', 'privacy notice')}</Link></span>
            </label>
          </div>

          <button type="submit" className="auth-submit" disabled={isSubmitting || registerSuccess}>
            {isSubmitting ? (
              <>
                <span className="spinner"></span>
                {tr('Regisztráció...', 'Creating account...')}
              </>
            ) : registerSuccess ? (
              tr('Sikeres regisztráció!', 'Registration successful!')
            ) : (
              tr('Regisztráció', 'Create account')
            )}
          </button>
        </form>

        <p className="auth-footer">
          {tr('Már van fiókod?', 'Already have an account?')}{' '}
          <Link to="/bejelentkezes">{tr('Jelentkezz be!', 'Log in')}</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;

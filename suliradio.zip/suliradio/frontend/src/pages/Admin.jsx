import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle,
  Edit2,
  ListChecks,
  Loader2,
  LogIn,
  LogOut,
  Music,
  Plus,
  RefreshCw,
  Save,
  Search,
  Shield,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { adminAPI } from '../services/api';

const EMPTY_SONG = {
  title: '',
  artist: '',
  duration: '',
  genre: '',
  sourceUrl: '',
  mp3Url: '',
  isAvailable: true,
};

const EMPTY_SCHEDULE = {
  zeneid: '',
  mikortol: '',
  meddig: '',
};

const EMPTY_USER_FORM = {
  vezeteknev: '',
  keresztnev: '',
  email: '',
  omazonosito: '',
  password: '',
  role: 'user',
};

const EMPTY_BREAK = {
  sequence: '',
  start: '',
  end: '',
};

const ROLE_OPTIONS = [
  { value: 'user', label: 'Felhasználó', jog: 2 },
  { value: 'tanar', label: 'Tanár', jog: 3 },
  { value: 'admin', label: 'Admin', jog: 4 },
];

const toDateTimeLocalValue = (value) => {
  if (!value) return '';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';

  const adjusted = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return adjusted.toISOString().slice(0, 16);
};

const formatDateTime = (value) => {
  if (!value) return '-';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString('hu-HU', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const formatDuration = (seconds) => {
  const totalSeconds = Number(seconds) || 0;
  const minutes = Math.floor(totalSeconds / 60);
  const remainder = totalSeconds % 60;
  return `${minutes}:${remainder.toString().padStart(2, '0')}`;
};

const formatRole = (role) => {
  if (role === 'admin') return 'Admin';
  if (role === 'tanar') return 'Tanár';
  if (role === 'demo') return 'Demo';
  return 'Felhasználó';
};

const buildEditableUser = (user) => ({
  originalEmail: user.email,
  email: user.email,
  keresztnev: user.name?.split(' ').slice(1).join(' ') || '',
  vezeteknev: user.name?.split(' ')[0] || '',
  omazonosito: user.educationalId || '',
  jog: Number(user.jog) || 2,
  emailverifikalva: !!user.emailVerified,
  password: '',
});

const resolveRequestSong = (request, songsById, songs) => {
  if (request.songId && songsById.has(request.songId)) {
    return songsById.get(request.songId);
  }

  if (!request.songUrl) {
    return null;
  }

  return songs.find((song) => (
    song.sourceUrl === request.songUrl || song.mp3Url === request.songUrl
  )) || null;
};

const AdminPage = () => {
  const navigate = useNavigate();
  const { user, isLoggedIn, loading: userLoading, logout } = useUser();

  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState(null);

  const [dashboardData, setDashboardData] = useState(null);
  const [songs, setSongs] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [users, setUsers] = useState([]);
  const [requests, setRequests] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [breaks, setBreaks] = useState([]);

  const [songSearch, setSongSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [requestSearch, setRequestSearch] = useState('');
  const [submissionSearch, setSubmissionSearch] = useState('');

  const [showAddSong, setShowAddSong] = useState(false);
  const [newSong, setNewSong] = useState(EMPTY_SONG);
  const [editingSongId, setEditingSongId] = useState(null);
  const [editingSong, setEditingSong] = useState(null);

  const [newSchedule, setNewSchedule] = useState(EMPTY_SCHEDULE);
  const [userForm, setUserForm] = useState(EMPTY_USER_FORM);
  const [editableUser, setEditableUser] = useState(null);
  const [breakForm, setBreakForm] = useState(EMPTY_BREAK);
  const [editingBreakSequence, setEditingBreakSequence] = useState(null);

  const isAdmin = user?.role === 'admin';

  const showMessage = useCallback((text, type = 'success') => {
    setMessage({ text, type });
    window.setTimeout(() => setMessage(null), 4500);
  }, []);

  useEffect(() => {
    if (!userLoading && (!isLoggedIn || !isAdmin)) {
      navigate('/');
    }
  }, [isAdmin, isLoggedIn, navigate, userLoading]);

  const loadOverview = useCallback(async () => {
    const [overviewData, usersData, requestsData, scheduleData, submissionsData, breaksData, songsData] = await Promise.all([
      adminAPI.dashboard(),
      adminAPI.getUsers().catch(() => ({ success: false, users: [] })),
      adminAPI.getRequests().catch(() => ({ success: false, requests: [] })),
      adminAPI.getSchedule().catch(() => ({ success: false, schedule: [] })),
      adminAPI.getSubmissions().catch(() => ({ success: false, submissions: [] })),
      adminAPI.getBreaks().catch(() => ({ success: false, breaks: [] })),
      adminAPI.getSongs().catch(() => ({ success: false, songs: [] })),
    ]);

    if (!overviewData.success) {
      throw new Error(overviewData.error || 'Nem sikerült betölteni az admin áttekintést.');
    }

    setDashboardData(overviewData.dashboard);

    if (usersData.success) {
      setUsers(usersData.users || []);
    }

    if (requestsData.success) {
      setRequests(requestsData.requests || []);
    }

    if (scheduleData.success) {
      setSchedule(scheduleData.schedule || []);
    }

    if (submissionsData.success) {
      setSubmissions(submissionsData.submissions || []);
    }

    if (breaksData.success) {
      setBreaks(breaksData.breaks || []);
    }

    if (songsData.success) {
      setSongs(songsData.songs || []);
    }
  }, []);

  const loadSongs = useCallback(async () => {
    const data = await adminAPI.getSongs();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a zenéket.');
    }
    setSongs(data.songs || []);
  }, []);

  const loadSchedule = useCallback(async () => {
    const data = await adminAPI.getSchedule();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni az órarendet.');
    }
    setSchedule(data.schedule || []);
  }, []);

  const loadUsers = useCallback(async () => {
    const data = await adminAPI.getUsers();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a felhasználókat.');
    }

    setUsers(data.users || []);
    setEditableUser((current) => {
      if (!current) return current;

      const updatedUser = (data.users || []).find(
        (item) => item.email === current.originalEmail || item.email === current.email
      );

      return updatedUser ? buildEditableUser(updatedUser) : null;
    });
  }, []);

  const loadRequests = useCallback(async () => {
    const data = await adminAPI.getRequests();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a kéréslistát.');
    }
    setRequests(data.requests || []);
  }, []);

  const loadSubmissions = useCallback(async () => {
    const data = await adminAPI.getSubmissions();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a várólistát.');
    }
    setSubmissions(data.submissions || []);
  }, []);

  const loadBreaks = useCallback(async () => {
    const data = await adminAPI.getBreaks();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a szüneteket.');
    }
    setBreaks(data.breaks || []);
  }, []);

  useEffect(() => {
    if (!isAdmin) return;

    let active = true;

    const run = async () => {
      setLoading(true);

      try {
        if (activeTab === 'overview') {
          await loadOverview();
        }

        if (activeTab === 'songs') {
          await loadSongs();
        }

        if (activeTab === 'schedule') {
          await Promise.all([loadSongs(), loadSchedule()]);
        }

        if (activeTab === 'users') {
          await loadUsers();
        }

        if (activeTab === 'requests') {
          await Promise.all([loadRequests(), loadUsers(), loadSongs()]);
        }

        if (activeTab === 'submissions') {
          await loadSubmissions();
        }

        if (activeTab === 'breaks') {
          await loadBreaks();
        }
      } catch (error) {
        if (active) {
          showMessage(error.message || 'Betöltési hiba történt.', 'error');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    run();

    return () => {
      active = false;
    };
  }, [
    activeTab,
    isAdmin,
    loadBreaks,
    loadOverview,
    loadRequests,
    loadSchedule,
    loadSongs,
    loadSubmissions,
    loadUsers,
    showMessage,
  ]);

  const songsById = useMemo(() => new Map(songs.map((song) => [song.id, song])), [songs]);
  const usersById = useMemo(() => new Map(users.map((currentUser) => [currentUser.id, currentUser])), [users]);

  const filteredSongs = useMemo(() => {
    const query = songSearch.trim().toLowerCase();
    if (!query) return songs;

    return songs.filter((song) => (
      song.title.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query) ||
      (song.genre || '').toLowerCase().includes(query)
    ));
  }, [songSearch, songs]);

  const filteredUsers = useMemo(() => {
    const query = userSearch.trim().toLowerCase();
    if (!query) return users;

    return users.filter((currentUser) => (
      currentUser.name.toLowerCase().includes(query) ||
      currentUser.email.toLowerCase().includes(query) ||
      (currentUser.educationalId || '').toLowerCase().includes(query)
    ));
  }, [userSearch, users]);

  const filteredRequests = useMemo(() => {
    const query = requestSearch.trim().toLowerCase();

    return requests
      .map((request) => {
        const requestUser = usersById.get(request.userId);
        const requestSong = resolveRequestSong(request, songsById, songs);

        return {
          ...request,
          user: requestUser || null,
          song: requestSong || null,
        };
      })
      .filter((request) => {
        if (!query) return true;

        const haystack = [
          request.id,
          request.user?.name,
          request.user?.email,
          request.song?.title,
          request.song?.artist,
          request.songUrl,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();

        return haystack.includes(query);
      })
      .sort((left, right) => new Date(right.requestedAt || 0) - new Date(left.requestedAt || 0));
  }, [requestSearch, requests, songsById, usersById]);

  const filteredSubmissions = useMemo(() => {
    const query = submissionSearch.trim().toLowerCase();
    if (!query) return submissions;

    return submissions.filter((submission) => (
      [submission.title, submission.artist, submission.sourceUrl, submission.mp3Url]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(query)
    ));
  }, [submissionSearch, submissions]);

  const sortedSchedule = useMemo(() => (
    [...schedule].sort((left, right) => new Date(left.startTime) - new Date(right.startTime))
  ), [schedule]);

  const sortedBreaks = useMemo(() => (
    [...breaks].sort((left, right) => left.sequence - right.sequence)
  ), [breaks]);

  const overviewRecentUsers = useMemo(() => (
    [...users]
      .sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))
      .slice(0, 5)
  ), [users]);

  const overviewRecentLogins = useMemo(() => (
    users
      .filter((currentUser) => currentUser.active)
      .sort((left, right) => new Date(right.lastLoginAt || 0) - new Date(left.lastLoginAt || 0))
      .slice(0, 5)
  ), [users]);

  const overviewUpcomingSchedule = useMemo(() => (
    [...schedule]
      .sort((left, right) => new Date(left.startTime || 0) - new Date(right.startTime || 0))
      .slice(0, 5)
  ), [schedule]);

  const overviewPendingRequests = useMemo(() => (
    requests
      .filter((request) => !request.validated)
      .map((request) => ({
        ...request,
        user: usersById.get(request.userId) || null,
        song: resolveRequestSong(request, songsById, songs),
      }))
      .sort((left, right) => new Date(right.requestedAt || 0) - new Date(left.requestedAt || 0))
      .slice(0, 5)
  ), [requests, usersById, songsById, songs]);

  const overviewLatestSubmissions = useMemo(() => (
    [...submissions]
      .sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))
      .slice(0, 5)
  ), [submissions]);

  const overviewUpcomingBreaks = useMemo(() => (
    [...breaks]
      .filter((currentBreak) => new Date(currentBreak.start || 0) >= new Date())
      .sort((left, right) => new Date(left.start || 0) - new Date(right.start || 0))
      .slice(0, 5)
  ), [breaks]);

  const handleCreateSong = async (event) => {
    event.preventDefault();

    const data = await adminAPI.createSong({
      ...newSong,
      duration: Number(newSong.duration) || 0,
    });

    if (!data.success) {
      showMessage(data.error || 'A zene hozzáadása nem sikerült.', 'error');
      return;
    }

    setNewSong(EMPTY_SONG);
    setShowAddSong(false);
    showMessage(data.message || 'A zene sikeresen hozzáadva.');
    await loadSongs();
  };

  const beginSongEdit = (song) => {
    setEditingSongId(song.id);
    setEditingSong({
      ...song,
      duration: Number(song.duration) || 0,
      sourceUrl: song.sourceUrl || '',
      mp3Url: song.mp3Url || '',
    });
  };

  const handleUpdateSong = async () => {
    if (!editingSongId || !editingSong) return;

    const data = await adminAPI.updateSong(editingSongId, editingSong);
    if (!data.success) {
      showMessage(data.error || 'A zene frissítése nem sikerült.', 'error');
      return;
    }

    setEditingSongId(null);
    setEditingSong(null);
    showMessage('A zene frissítve lett.');
    await loadSongs();
  };

  const handleDeleteSong = async (song) => {
    if (!window.confirm(`Biztosan törlöd ezt a zenét: ${song.artist} - ${song.title}?`)) return;

    const data = await adminAPI.deleteSong(song.id);
    if (!data.success) {
      showMessage(data.error || 'A zene törlése nem sikerült.', 'error');
      return;
    }

    showMessage('A zene törölve lett.');
    await loadSongs();
  };

  const handleCreateSchedule = async (event) => {
    event.preventDefault();

    const data = await adminAPI.addScheduleItem(
      Number(newSchedule.zeneid),
      newSchedule.mikortol,
      newSchedule.meddig,
    );

    if (!data.success) {
      showMessage(data.error || 'Az órarend bejegyzés hozzáadása nem sikerült.', 'error');
      return;
    }

    setNewSchedule(EMPTY_SCHEDULE);
    showMessage('Az órarend bejegyzés létrejött.');
    await loadSchedule();
  };

  const handleDeleteSchedule = async (item) => {
    if (!window.confirm('Biztosan törlöd ezt az órarend bejegyzést?')) return;

    const data = await adminAPI.deleteScheduleItem(item.id);
    if (!data.success) {
      showMessage(data.error || 'Az órarend bejegyzés törlése nem sikerült.', 'error');
      return;
    }

    showMessage('Az órarend bejegyzés törölve lett.');
    await loadSchedule();
  };

  const handleRegisterUser = async (event) => {
    event.preventDefault();

    const data = await adminAPI.registerUser(userForm);
    if (!data.success) {
      showMessage(data.error || 'A felhasználó létrehozása nem sikerült.', 'error');
      return;
    }

    setUserForm(EMPTY_USER_FORM);
    showMessage(data.message || 'A felhasználó létrehozva.');
    await loadUsers();
  };

  const handleDeleteUser = async (email) => {
    if (email === user?.email) {
      showMessage('A saját admin fiókodat innen nem törölheted.', 'error');
      return;
    }

    if (!window.confirm(`Biztosan törlöd ezt a felhasználót: ${email}?`)) return;

    const data = await adminAPI.deleteUserByEmail(email);
    if (!data.success) {
      showMessage(data.error || 'A felhasználó törlése nem sikerült.', 'error');
      return;
    }

    if (editableUser?.originalEmail === email) {
      setEditableUser(null);
    }

    showMessage(data.message || 'A felhasználó törölve lett.');
    await loadUsers();
  };

  const handleLogoutUser = async (email) => {
    if (email === user?.email) {
      await logout();
      return;
    }

    const data = await adminAPI.logoutUserByEmail(email);
    if (!data.success) {
      showMessage(data.error || 'A felhasználó kiléptetése nem sikerült.', 'error');
      return;
    }

    showMessage(data.message || 'A felhasználó kiléptetve lett.');
    await loadUsers();
  };

  const handleSaveUser = async (event) => {
    event.preventDefault();
    if (!editableUser) return;

    const data = await adminAPI.updateUser(editableUser.originalEmail, editableUser);
    if (!data.success) {
      showMessage(data.error || 'A felhasználó frissítése nem sikerült.', 'error');
      return;
    }

    showMessage(data.message || 'A felhasználó adatai frissültek.');
    await loadUsers();
  };

  const handleApproveRequest = async (id) => {
    const data = await adminAPI.approveRequest(id);
    if (!data.success) {
      showMessage(data.error || 'A kérés jóváhagyása nem sikerült.', 'error');
      return;
    }

    showMessage(data.message || 'A kérés jóváhagyva lett.');
    await loadRequests();
  };

  const beginBreakEdit = (currentBreak) => {
    setEditingBreakSequence(currentBreak.sequence);
    setBreakForm({
      sequence: String(currentBreak.sequence),
      start: toDateTimeLocalValue(currentBreak.start),
      end: toDateTimeLocalValue(currentBreak.end),
    });
  };

  const resetBreakEditor = () => {
    setEditingBreakSequence(null);
    setBreakForm(EMPTY_BREAK);
  };

  const handleSaveBreak = async (event) => {
    event.preventDefault();

    const payload = {
      sequence: Number(breakForm.sequence),
      start: breakForm.start,
      end: breakForm.end,
    };

    const data = editingBreakSequence === null
      ? await adminAPI.createBreak(payload)
      : await adminAPI.updateBreak(editingBreakSequence, payload);

    if (!data.success) {
      showMessage(data.error || 'A szünet mentése nem sikerült.', 'error');
      return;
    }

    resetBreakEditor();
    showMessage(data.message || 'A szünet mentve lett.');
    await loadBreaks();
  };

  const handleDeleteBreak = async (sequence) => {
    if (!window.confirm(`Biztosan törlöd a(z) ${sequence}. szünetet?`)) return;

    const data = await adminAPI.deleteBreak(sequence);
    if (!data.success) {
      showMessage(data.error || 'A szünet törlése nem sikerült.', 'error');
      return;
    }

    if (editingBreakSequence === sequence) {
      resetBreakEditor();
    }

    showMessage(data.message || 'A szünet törölve lett.');
    await loadBreaks();
  };

  const tabs = [
    { id: 'overview', label: 'Áttekintés', icon: Shield },
    { id: 'songs', label: 'Zenék', icon: Music },
    { id: 'schedule', label: 'Órarend', icon: CalendarClock },
    { id: 'users', label: 'Felhasználók', icon: Users },
    { id: 'requests', label: 'Kérések', icon: ListChecks },
    { id: 'submissions', label: 'Beküldések', icon: Music },
    { id: 'breaks', label: 'Szünetek', icon: CalendarClock },
  ];

  const renderLoading = () => (
    <div className="admin-loading">
      <Loader2 size={32} className="spinner" />
      <p>Betöltés...</p>
    </div>
  );

  const renderOverview = () => {
    const stats = dashboardData?.stats || {};

    return (
      <div className="admin-dashboard">
        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalSongs ?? 0}</span>
              <span className="admin-stat-label">Összes zene</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <Users size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalUsers ?? 0}</span>
              <span className="admin-stat-label">Felhasználók</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <CheckCircle size={24} />
            <div>
              <span className="admin-stat-value">{stats.activeUsers ?? 0}</span>
              <span className="admin-stat-label">Aktív bejelentkezések</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <CalendarClock size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalScheduleItems ?? 0}</span>
              <span className="admin-stat-label">Órarend elemek</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <ListChecks size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingRequests ?? 0}</span>
              <span className="admin-stat-label">Függő kérések</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <AlertCircle size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalBreaks ?? 0}</span>
              <span className="admin-stat-label">Szünetek</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingSubmissions ?? 0}</span>
              <span className="admin-stat-label">Várólistás beküldések</span>
            </div>
          </div>
        </div>

        <div className="admin-overview-grid">
          <div className="admin-section admin-panel-card">
            <h3><Users size={20} /> Legutóbb létrehozott felhasználók</h3>
            <div className="admin-overview-list">
              {overviewRecentUsers.length === 0 ? (
                <p>Nincs megjeleníthető felhasználó.</p>
              ) : overviewRecentUsers.map((currentUser) => (
                <div key={currentUser.email} className="admin-overview-item">
                  <div>
                    <strong>{currentUser.name}</strong>
                    <span>{currentUser.email}</span>
                  </div>
                  <span className="admin-tag">{formatRole(currentUser.role)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><LogIn size={20} /> Legutóbbi bejelentkezett felhasználók</h3>
            <div className="admin-overview-list">
              {overviewRecentLogins.length === 0 ? (
                <p>Nincs aktív bejelentkezett felhasználó.</p>
              ) : overviewRecentLogins.map((currentUser) => (
                <div key={`${currentUser.email}-login`} className="admin-overview-item">
                  <div>
                    <strong>{currentUser.name}</strong>
                    <span>{currentUser.email}</span>
                  </div>
                  <span>{formatDateTime(currentUser.lastLoginAt)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><ListChecks size={20} /> Függő kérések</h3>
            <div className="admin-overview-list">
              {overviewPendingRequests.length === 0 ? (
                <p>Nincs függő kérés.</p>
              ) : overviewPendingRequests.map((request) => (
                <div key={request.id} className="admin-overview-item">
                  <div>
                    <strong>
                      {request.song
                        ? `${request.song.artist} - ${request.song.title}`
                        : request.songUrl || `Kérés #${request.id}`}
                    </strong>
                    <span>
                      {request.user ? `${request.user.name} • ${formatDateTime(request.requestedAt)}` : formatDateTime(request.requestedAt)}
                    </span>
                  </div>
                  <button className="admin-action-btn approve" onClick={() => handleApproveRequest(request.id)} title="Jóváhagyás">
                    <CheckCircle size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><CalendarClock size={20} /> Következő órarend elemek</h3>
            <div className="admin-overview-list">
              {overviewUpcomingSchedule.length === 0 ? (
                <p>Nincs közelgő órarend elem.</p>
              ) : overviewUpcomingSchedule.map((item) => (
                <div key={item.id || `${item.songId}-${item.startTime}`} className="admin-overview-item">
                  <div>
                    <strong>{item.song ? `${item.song.artist} - ${item.song.title}` : `Zene #${item.songId}`}</strong>
                    <span>{formatDateTime(item.startTime)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><Music size={20} /> Friss beküldések</h3>
            <div className="admin-overview-list">
              {overviewLatestSubmissions.length === 0 ? (
                <p>Nincs friss várólistás beküldés.</p>
              ) : overviewLatestSubmissions.map((submission) => (
                <div key={submission.id} className="admin-overview-item">
                  <div>
                    <strong>{submission.title || submission.sourceUrl || 'Névtelen beküldés'}</strong>
                    <span>{submission.artist || formatDateTime(submission.createdAt)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><CalendarClock size={20} /> Közelgő szünetek</h3>
            <div className="admin-overview-list">
              {overviewUpcomingBreaks.length === 0 ? (
                <p>Nincs közelgő szünet.</p>
              ) : overviewUpcomingBreaks.map((currentBreak) => (
                <div key={`break-${currentBreak.sequence}`} className="admin-overview-item">
                  <div>
                    <strong>{currentBreak.sequence}. szünet</strong>
                    <span>{formatDateTime(currentBreak.start)}</span>
                  </div>
                  <span>{formatDateTime(currentBreak.end)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSongs = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Music size={20} /> Zenék kezelése ({songs.length} zene)</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder="Keresés címre vagy előadóra..."
              value={songSearch}
              onChange={(event) => setSongSearch(event.target.value)}
            />
          </div>

          <button className="admin-add-btn" onClick={() => setShowAddSong((value) => !value)}>
            <Plus size={16} /> Új zene
          </button>

          <button className="admin-icon-btn" onClick={loadSongs} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {showAddSong && (
        <form className="admin-form" onSubmit={handleCreateSong}>
          <h4>Új zene hozzáadása</h4>
          <div className="admin-form-grid">
            <div className="form-group">
              <label>Cím</label>
              <input value={newSong.title} onChange={(event) => setNewSong((prev) => ({ ...prev, title: event.target.value }))} required />
            </div>

            <div className="form-group">
              <label>Előadó</label>
              <input value={newSong.artist} onChange={(event) => setNewSong((prev) => ({ ...prev, artist: event.target.value }))} required />
            </div>

            <div className="form-group">
              <label>Hossz (mp)</label>
              <input type="number" min="1" value={newSong.duration} onChange={(event) => setNewSong((prev) => ({ ...prev, duration: event.target.value }))} />
            </div>

            <div className="form-group">
              <label>Műfaj</label>
              <input value={newSong.genre} onChange={(event) => setNewSong((prev) => ({ ...prev, genre: event.target.value }))} />
            </div>

            <div className="form-group">
              <label>Keresési / forrás URL</label>
              <input value={newSong.sourceUrl} onChange={(event) => setNewSong((prev) => ({ ...prev, sourceUrl: event.target.value }))} placeholder="https://..." />
            </div>

            <div className="form-group">
              <label>MP3 útvonal</label>
              <input value={newSong.mp3Url} onChange={(event) => setNewSong((prev) => ({ ...prev, mp3Url: event.target.value }))} placeholder="C:\\...\\zene.mp3" required />
            </div>

            <div className="form-group">
              <label className="admin-checkbox-label">
                <input
                  type="checkbox"
                  checked={newSong.isAvailable}
                  onChange={(event) => setNewSong((prev) => ({ ...prev, isAvailable: event.target.checked }))}
                />
                Lejátszható
              </label>
            </div>
          </div>

          <div className="admin-form-actions">
            <button type="submit" className="btn btn-primary"><Save size={16} /> Mentés</button>
            <button type="button" className="btn btn-secondary" onClick={() => { setShowAddSong(false); setNewSong(EMPTY_SONG); }}><X size={16} /> Mégse</button>
          </div>
        </form>
      )}

      {filteredSongs.length === 0 ? (
        <p className="admin-empty">Nincs találat.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Cím</th>
                <th>Előadó</th>
                <th>Hossz</th>
                <th>Műfaj</th>
                <th>MP3 útvonal</th>
                <th>Kérések</th>
                <th>Elérhető</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {filteredSongs.map((song) => (
                <tr key={song.id}>
                  {editingSongId === song.id ? (
                    <>
                      <td><input className="admin-inline-input" value={editingSong.title} onChange={(event) => setEditingSong((prev) => ({ ...prev, title: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.artist} onChange={(event) => setEditingSong((prev) => ({ ...prev, artist: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" type="number" value={editingSong.duration} onChange={(event) => setEditingSong((prev) => ({ ...prev, duration: Number(event.target.value) || 0 }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.genre || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, genre: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.mp3Url || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, mp3Url: event.target.value }))} /></td>
                      <td>{song.requestCount ?? 0}</td>
                      <td><input type="checkbox" checked={editingSong.isAvailable} onChange={(event) => setEditingSong((prev) => ({ ...prev, isAvailable: event.target.checked }))} /></td>
                      <td className="admin-actions">
                        <button className="admin-action-btn approve" onClick={handleUpdateSong} title="Mentés"><Save size={16} /></button>
                        <button className="admin-action-btn" onClick={() => { setEditingSongId(null); setEditingSong(null); }} title="Mégse"><X size={16} /></button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td><strong>{song.title}</strong></td>
                      <td>{song.artist}</td>
                      <td>{formatDuration(song.duration)}</td>
                      <td>{song.genre || '-'}</td>
                      <td>{song.mp3Url || '-'}</td>
                      <td>{song.requestCount ?? 0}</td>
                      <td>{song.isAvailable ? 'Igen' : 'Nem'}</td>
                      <td className="admin-actions">
                        <button className="admin-action-btn" onClick={() => beginSongEdit(song)} title="Szerkesztés"><Edit2 size={16} /></button>
                        <button className="admin-action-btn reject" onClick={() => handleDeleteSong(song)} title="Törlés"><Trash2 size={16} /></button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSchedule = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><CalendarClock size={20} /> Órarend kezelése</h3>
        <button className="admin-icon-btn" onClick={loadSchedule} title="Frissítés"><RefreshCw size={16} /></button>
      </div>

      <form className="admin-form" onSubmit={handleCreateSchedule}>
        <h4>Új órarend bejegyzés</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Zene</label>
            <select value={newSchedule.zeneid} onChange={(event) => setNewSchedule((prev) => ({ ...prev, zeneid: event.target.value }))} required>
              <option value="">Válassz zenét...</option>
              {songs.map((song) => (
                <option key={song.id} value={song.id}>{song.artist} - {song.title}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Kezdés</label>
            <input type="datetime-local" value={newSchedule.mikortol} onChange={(event) => setNewSchedule((prev) => ({ ...prev, mikortol: event.target.value }))} required />
          </div>

          <div className="form-group">
            <label>Vége</label>
            <input type="datetime-local" value={newSchedule.meddig} onChange={(event) => setNewSchedule((prev) => ({ ...prev, meddig: event.target.value }))} required />
          </div>
        </div>

        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Plus size={16} /> Hozzáadás</button>
        </div>
      </form>

      {sortedSchedule.length === 0 ? (
        <p className="admin-empty">Nincs elérhető órarend bejegyzés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Zene</th>
                <th>Kezdés</th>
                <th>Vége</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {sortedSchedule.map((item) => (
                <tr key={item.id || `${item.songId}-${item.startTime}`}>
                  <td>{item.song ? `${item.song.artist} - ${item.song.title}` : `Zene #${item.songId}`}</td>
                  <td>{formatDateTime(item.startTime)}</td>
                  <td>{formatDateTime(item.endTime)}</td>
                  <td className="admin-actions">
                    <button className="admin-action-btn reject" onClick={() => handleDeleteSchedule(item)} title="Törlés"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderUsers = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Users size={20} /> Felhasználók ({users.length})</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder="Keresés névre, emailre, OM-re..."
              value={userSearch}
              onChange={(event) => setUserSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadUsers} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-split-layout">
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Név</th>
                <th>Email</th>
                <th>OM</th>
                <th>Szerepkör</th>
                <th>Email</th>
                <th>Állapot</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((currentUser) => (
                <tr key={currentUser.email} className={editableUser?.originalEmail === currentUser.email ? 'admin-row-selected' : ''}>
                  <td>{currentUser.name}</td>
                  <td>{currentUser.email}</td>
                  <td>{currentUser.educationalId || '-'}</td>
                  <td><span className="admin-tag">{formatRole(currentUser.role)}</span></td>
                  <td>{currentUser.emailVerified ? 'Verifikált' : 'Nincs verifikálva'}</td>
                  <td>{currentUser.active ? 'Aktív' : 'Kilépve'}</td>
                  <td className="admin-actions">
                    <button className="admin-action-btn" onClick={() => setEditableUser(buildEditableUser(currentUser))} title="Szerkesztés"><Edit2 size={16} /></button>
                    <button className="admin-action-btn" onClick={() => handleLogoutUser(currentUser.email)} title={currentUser.email === user?.email ? 'Saját kijelentkezés' : 'Kiléptetés'}><LogOut size={16} /></button>
                    <button className="admin-action-btn reject" onClick={() => handleDeleteUser(currentUser.email)} title={currentUser.email === user?.email ? 'A saját fiók innen nem törölhető' : 'Törlés'} disabled={currentUser.email === user?.email}><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="admin-stack-panel">
          {editableUser ? (
            <form className="admin-form" onSubmit={handleSaveUser}>
              <h4><Edit2 size={18} /> Meglévő felhasználó szerkesztése</h4>
              <div className="admin-form-grid">
                <div className="form-group">
                  <label>Vezetéknév</label>
                  <input value={editableUser.vezeteknev} onChange={(event) => setEditableUser((prev) => ({ ...prev, vezeteknev: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>Keresztnév</label>
                  <input value={editableUser.keresztnev} onChange={(event) => setEditableUser((prev) => ({ ...prev, keresztnev: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>Email</label>
                  <input type="email" value={editableUser.email} onChange={(event) => setEditableUser((prev) => ({ ...prev, email: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>OM azonosító</label>
                  <input value={editableUser.omazonosito} onChange={(event) => setEditableUser((prev) => ({ ...prev, omazonosito: event.target.value }))} />
                </div>

                <div className="form-group">
                  <label>Szerepkör</label>
                  <select value={editableUser.jog} onChange={(event) => setEditableUser((prev) => ({ ...prev, jog: Number(event.target.value) }))}>
                    {ROLE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.jog}>{option.label}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Új jelszó</label>
                  <input type="password" value={editableUser.password} onChange={(event) => setEditableUser((prev) => ({ ...prev, password: event.target.value }))} placeholder="Csak ha cserélni szeretnéd" />
                </div>

                <div className="form-group">
                  <label className="admin-checkbox-label">
                    <input
                      type="checkbox"
                      checked={editableUser.emailverifikalva}
                      onChange={(event) => setEditableUser((prev) => ({ ...prev, emailverifikalva: event.target.checked }))}
                    />
                    Email verifikálva
                  </label>
                </div>
              </div>

              <div className="admin-form-actions">
                <button type="submit" className="btn btn-primary"><Save size={16} /> Mentés</button>
                <button type="button" className="btn btn-secondary" onClick={() => setEditableUser(null)}><X size={16} /> Bezárás</button>
              </div>
            </form>
          ) : (
            <div className="admin-empty">
              <p>Válassz ki egy felhasználót a táblából a szerkesztéshez.</p>
            </div>
          )}

          <form className="admin-form" onSubmit={handleRegisterUser}>
            <h4><UserPlus size={18} /> Új felhasználó létrehozása</h4>
            <div className="admin-form-grid">
              <div className="form-group">
                <label>Vezetéknév</label>
                <input value={userForm.vezeteknev} onChange={(event) => setUserForm((prev) => ({ ...prev, vezeteknev: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>Keresztnév</label>
                <input value={userForm.keresztnev} onChange={(event) => setUserForm((prev) => ({ ...prev, keresztnev: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>Email</label>
                <input type="email" value={userForm.email} onChange={(event) => setUserForm((prev) => ({ ...prev, email: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>OM azonosító</label>
                <input value={userForm.omazonosito} onChange={(event) => setUserForm((prev) => ({ ...prev, omazonosito: event.target.value }))} />
              </div>

              <div className="form-group">
                <label>Jelszó</label>
                <input type="password" value={userForm.password} onChange={(event) => setUserForm((prev) => ({ ...prev, password: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>Szerepkör</label>
                <select value={userForm.role} onChange={(event) => setUserForm((prev) => ({ ...prev, role: event.target.value }))}>
                  {ROLE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="admin-form-actions">
              <button type="submit" className="btn btn-primary"><Save size={16} /> Létrehozás</button>
            </div>
          </form>

          <div className="admin-form">
            <h4><LogOut size={18} /> Saját munkamenet</h4>
            <div className="admin-form-actions">
              <button type="button" className="btn btn-secondary" onClick={logout}><LogOut size={16} /> Saját kijelentkezés</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRequests = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><ListChecks size={20} /> Kérések kezelése ({requests.length})</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder="Keresés kérésre, felhasználóra, zenére..."
              value={requestSearch}
              onChange={(event) => setRequestSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadRequests} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-empty admin-empty-left">
        <p>A kéréslista közvetlenül mutatja a kért zenét és innen soronként jóváhagyható. Elutasítás, sorrendezés és törlés továbbra sincs külön végponthoz kötve.</p>
      </div>

      {filteredRequests.length === 0 ? (
        <p className="admin-empty">Nincs elérhető kérés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Felhasználó</th>
                <th>Zene</th>
                <th>Kérve</th>
                <th>Állapot</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {filteredRequests.map((request) => (
                <tr key={request.id}>
                  <td>#{request.id}</td>
                  <td>
                    {request.user
                      ? `${request.user.name} (${request.user.email})`
                      : request.userId
                        ? `Felhasználó #${request.userId}`
                        : '-'}
                  </td>
                  <td>
                    {request.song
                      ? `${request.song.artist} - ${request.song.title}`
                      : request.songUrl || (request.songId ? `Zene #${request.songId}` : '-')}
                  </td>
                  <td>{formatDateTime(request.requestedAt)}</td>
                  <td>
                    <span className={`admin-tag ${request.validated ? 'is-success' : 'is-warning'}`}>
                      {request.validated ? 'Jóváhagyva' : 'Függőben'}
                    </span>
                  </td>
                  <td className="admin-actions">
                    {!request.validated && (
                      <button className="admin-action-btn approve" onClick={() => handleApproveRequest(request.id)} title="Jóváhagyás">
                        <CheckCircle size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSubmissions = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Music size={20} /> Beküldéslista ({submissions.length})</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder="Keresés címre, előadóra, URL-re..."
              value={submissionSearch}
              onChange={(event) => setSubmissionSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadSubmissions} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-empty admin-empty-left">
        <p>A lista a backend várólistáját mutatja. Ehhez jelenleg nincs külön sor-szintű jóváhagyó vagy elutasító végpont, ezért ez a nézet ellenőrzésre szolgál.</p>
      </div>

      {filteredSubmissions.length === 0 ? (
        <p className="admin-empty">Nincs várólistás beküldés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Cím</th>
                <th>Előadó</th>
                <th>Forrás</th>
                <th>MP3 útvonal</th>
                <th>Kérések</th>
                <th>Rögzítve</th>
              </tr>
            </thead>
            <tbody>
              {filteredSubmissions.map((submission) => (
                <tr key={submission.id}>
                  <td>{submission.title || '-'}</td>
                  <td>{submission.artist || '-'}</td>
                  <td className="admin-cell-wrap">{submission.sourceUrl || '-'}</td>
                  <td className="admin-cell-wrap">{submission.mp3Url || '-'}</td>
                  <td>{submission.requestCount || 0}</td>
                  <td>{formatDateTime(submission.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderBreaks = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><CalendarClock size={20} /> Szünetek kezelése ({breaks.length})</h3>
        <button className="admin-icon-btn" onClick={loadBreaks} title="Frissítés"><RefreshCw size={16} /></button>
      </div>

      <form className="admin-form" onSubmit={handleSaveBreak}>
        <h4>{editingBreakSequence === null ? 'Új szünet létrehozása' : `${editingBreakSequence}. szünet szerkesztése`}</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Sorszám</label>
            <input
              type="number"
              min="1"
              value={breakForm.sequence}
              onChange={(event) => setBreakForm((prev) => ({ ...prev, sequence: event.target.value }))}
              required
              disabled={editingBreakSequence !== null}
            />
          </div>

          <div className="form-group">
            <label>Kezdés</label>
            <input type="datetime-local" value={breakForm.start} onChange={(event) => setBreakForm((prev) => ({ ...prev, start: event.target.value }))} required />
          </div>

          <div className="form-group">
            <label>Vége</label>
            <input type="datetime-local" value={breakForm.end} onChange={(event) => setBreakForm((prev) => ({ ...prev, end: event.target.value }))} required />
          </div>
        </div>

        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Save size={16} /> {editingBreakSequence === null ? 'Létrehozás' : 'Mentés'}</button>
          {editingBreakSequence !== null && (
            <button type="button" className="btn btn-secondary" onClick={resetBreakEditor}><X size={16} /> Mégse</button>
          )}
        </div>
      </form>

      {sortedBreaks.length === 0 ? (
        <p className="admin-empty">Nincs rögzített szünet.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Sorszám</th>
                <th>Kezdés</th>
                <th>Vége</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {sortedBreaks.map((currentBreak) => (
                <tr key={currentBreak.id} className={editingBreakSequence === currentBreak.sequence ? 'admin-row-selected' : ''}>
                  <td>{currentBreak.sequence}</td>
                  <td>{formatDateTime(currentBreak.start)}</td>
                  <td>{formatDateTime(currentBreak.end)}</td>
                  <td className="admin-actions">
                    <button className="admin-action-btn" onClick={() => beginBreakEdit(currentBreak)} title="Szerkesztés"><Edit2 size={16} /></button>
                    <button className="admin-action-btn reject" onClick={() => handleDeleteBreak(currentBreak.sequence)} title="Törlés"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    if (loading) {
      return renderLoading();
    }

    if (activeTab === 'overview') return renderOverview();
    if (activeTab === 'songs') return renderSongs();
    if (activeTab === 'schedule') return renderSchedule();
    if (activeTab === 'users') return renderUsers();
    if (activeTab === 'requests') return renderRequests();
    if (activeTab === 'submissions') return renderSubmissions();
    if (activeTab === 'breaks') return renderBreaks();
    return null;
  };

  if (userLoading) {
    return renderLoading();
  }

  if (!isLoggedIn || !isAdmin) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Shield size={64} />
          <h2>Hozzáférés megtagadva</h2>
          <p>Az admin panel csak admin felhasználóknak érhető el.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page admin-page">
      <section className="page-header">
        <div className="page-header-content">
          <Shield size={32} className="page-icon" />
          <div>
            <h1 className="page-title">Admin Panel</h1>
            <p className="page-subtitle">A jelenlegi backendhez és az asztali kliens közös adatmodelljéhez igazított admin műveletek</p>
          </div>
        </div>
      </section>

      {message && (
        <div className={`admin-toast ${message.type}`}>
          {message.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)}><X size={16} /></button>
        </div>
      )}

      <div className="admin-tabs">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`admin-tab ${activeTab === id ? 'active' : ''}`} onClick={() => setActiveTab(id)}>
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      <div className="admin-content">
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminPage;
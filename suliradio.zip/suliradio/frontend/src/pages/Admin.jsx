﻿import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle,
  Edit2,
  LayoutDashboard,
  ListChecks,
  Loader2,
  LogOut,
  Music,
  Plus,
  RefreshCw,
  Save,
  Search,
  Shield,
  Trash2,
  UserPlus,
  UserX,
  Users,
  X,
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { adminAPI } from '../services/api';

const EMPTY_SONG = {
  title: '',
  artist: '',
  duration: '',
  genre: '',
  sourceUrl: '',
  mp3Url: '',
  isAvailable: true,
};

const EMPTY_SCHEDULE = {
  zeneid: '',
  mikortol: '',
  meddig: '',
};

const EMPTY_USER_FORM = {
  vezeteknev: '',
  keresztnev: '',
  email: '',
  omazonosito: '',
  password: '',
  role: 'user',
};

const AdminPage = () => {
  const navigate = useNavigate();
  const { user, isLoggedIn, loading: userLoading, logout } = useUser();
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState(null);

  const [dashboardData, setDashboardData] = useState(null);
  const [songs, setSongs] = useState([]);
  const [schedule, setSchedule] = useState([]);

  const [songSearch, setSongSearch] = useState('');
  const [showAddSong, setShowAddSong] = useState(false);
  const [newSong, setNewSong] = useState(EMPTY_SONG);
  const [editingSongId, setEditingSongId] = useState(null);
  const [editingSong, setEditingSong] = useState(null);

  const [newSchedule, setNewSchedule] = useState(EMPTY_SCHEDULE);
  const [userForm, setUserForm] = useState(EMPTY_USER_FORM);
  const [deleteEmail, setDeleteEmail] = useState('');
  const [logoutEmail, setLogoutEmail] = useState('');
  const [requestId, setRequestId] = useState('');

  const isAdmin = user?.role === 'admin';

  const showMessage = useCallback((text, type = 'success') => {
    setMessage({ text, type });
    window.setTimeout(() => setMessage(null), 4500);
  }, []);

  useEffect(() => {
    if (!userLoading && (!isLoggedIn || !isAdmin)) {
      navigate('/');
    }
  }, [isAdmin, isLoggedIn, navigate, userLoading]);

  const loadOverview = useCallback(async () => {
    const data = await adminAPI.dashboard();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni az admin áttekintést.');
    }
    setDashboardData(data.dashboard);
  }, []);

  const loadSongs = useCallback(async () => {
    const data = await adminAPI.getSongs();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni a zenéket.');
    }
    setSongs(data.songs || []);
  }, []);

  const loadSchedule = useCallback(async () => {
    const data = await adminAPI.getSchedule();
    if (!data.success) {
      throw new Error(data.error || 'Nem sikerült betölteni az órarendet.');
    }
    setSchedule(data.schedule || []);
  }, []);

  useEffect(() => {
    if (!isAdmin) return;

    let active = true;

    const run = async () => {
      setLoading(true);
      try {
        if (activeTab === 'overview') {
          await loadOverview();
        } else if (activeTab === 'songs') {
          await loadSongs();
        } else if (activeTab === 'schedule') {
          await Promise.all([loadSongs(), loadSchedule()]);
        }
      } catch (error) {
        if (active) {
          showMessage(error.message || 'Betöltési hiba történt.', 'error');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    run();

    return () => {
      active = false;
    };
  }, [activeTab, isAdmin, loadOverview, loadSchedule, loadSongs, showMessage]);

  const filteredSongs = useMemo(() => {
    const query = songSearch.trim().toLowerCase();
    if (!query) return songs;

    return songs.filter((song) => (
      song.title.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query) ||
      (song.genre || '').toLowerCase().includes(query)
    ));
  }, [songSearch, songs]);

  const sortedSchedule = useMemo(() => (
    [...schedule].sort((left, right) => new Date(left.startTime) - new Date(right.startTime))
  ), [schedule]);

  const formatDateTime = (value) => {
    if (!value) return '-';
    return new Date(value).toLocaleString('hu-HU', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDuration = (seconds) => {
    const totalSeconds = Number(seconds) || 0;
    const minutes = Math.floor(totalSeconds / 60);
    const remainder = totalSeconds % 60;
    return `${minutes}:${remainder.toString().padStart(2, '0')}`;
  };

  const handleCreateSong = async (event) => {
    event.preventDefault();

    const data = await adminAPI.createSong({
      ...newSong,
      duration: Number(newSong.duration) || 0,
    });

    if (!data.success) {
      showMessage(data.error || 'A zene hozzáadása nem sikerült.', 'error');
      return;
    }

    setNewSong(EMPTY_SONG);
    setShowAddSong(false);
    showMessage(data.message || 'A zene sikeresen hozzáadva.');
    await loadSongs();
  };

  const beginSongEdit = (song) => {
    setEditingSongId(song.id);
    setEditingSong({
      ...song,
      duration: Number(song.duration) || 0,
      sourceUrl: song.sourceUrl || '',
      mp3Url: song.mp3Url || '',
    });
  };

  const handleUpdateSong = async () => {
    if (!editingSongId || !editingSong) return;

    const data = await adminAPI.updateSong(editingSongId, editingSong);
    if (!data.success) {
      showMessage(data.error || 'A zene frissítése nem sikerült.', 'error');
      return;
    }

    setEditingSongId(null);
    setEditingSong(null);
    showMessage('A zene frissítve lett.');
    await loadSongs();
  };

  const handleDeleteSong = async (song) => {
    if (!confirm(`Biztosan törlöd ezt a zenét: ${song.artist} - ${song.title}?`)) return;

    const data = await adminAPI.deleteSong(song.id);
    if (!data.success) {
      showMessage(data.error || 'A zene törlése nem sikerült.', 'error');
      return;
    }

    showMessage('A zene törölve lett.');
    await loadSongs();
  };

  const handleCreateSchedule = async (event) => {
    event.preventDefault();

    const data = await adminAPI.addScheduleItem(
      Number(newSchedule.zeneid),
      newSchedule.mikortol,
      newSchedule.meddig,
    );

    if (!data.success) {
      showMessage(data.error || 'Az órarend bejegyzés hozzáadása nem sikerült.', 'error');
      return;
    }

    setNewSchedule(EMPTY_SCHEDULE);
    showMessage('Az órarend bejegyzés létrejött.');
    await loadSchedule();
  };

  const handleDeleteSchedule = async (item) => {
    if (!confirm('Biztosan törlöd ezt az órarend bejegyzést?')) return;

    const data = await adminAPI.deleteScheduleItem(item.id);
    if (!data.success) {
      showMessage(data.error || 'Az órarend bejegyzés törlése nem sikerült.', 'error');
      return;
    }

    showMessage('Az órarend bejegyzés törölve lett.');
    await loadSchedule();
  };

  const handleRegisterUser = async (event) => {
    event.preventDefault();

    const data = await adminAPI.registerUser(userForm);
    if (!data.success) {
      showMessage(data.error || 'A felhasználó létrehozása nem sikerült.', 'error');
      return;
    }

    setUserForm(EMPTY_USER_FORM);
    showMessage(data.message || 'A felhasználó létrehozva.');
  };

  const handleDeleteUser = async (event) => {
    event.preventDefault();

    const data = await adminAPI.deleteUserByEmail(deleteEmail.trim());
    if (!data.success) {
      showMessage(data.error || 'A felhasználó törlése nem sikerült.', 'error');
      return;
    }

    setDeleteEmail('');
    showMessage(data.message || 'A felhasználó törölve lett.');
  };

  const handleLogoutUser = async (event) => {
    event.preventDefault();

    const data = await adminAPI.logoutUserByEmail(logoutEmail.trim());
    if (!data.success) {
      showMessage(data.error || 'A felhasználó kiléptetése nem sikerült.', 'error');
      return;
    }

    setLogoutEmail('');
    showMessage(data.message || 'A felhasználó kiléptetve lett.');
  };

  const handleValidateRequest = async (event) => {
    event.preventDefault();

    const data = await adminAPI.validateRequestById(Number(requestId));
    if (!data.success) {
      showMessage(data.error || 'A kérés jóváhagyása nem sikerült.', 'error');
      return;
    }

    setRequestId('');
    showMessage(data.message || 'A kérés jóváhagyva lett.');
  };

  const tabs = [
    { id: 'overview', label: 'Áttekintés', icon: LayoutDashboard },
    { id: 'songs', label: 'Zenék', icon: Music },
    { id: 'schedule', label: 'Órarend', icon: CalendarClock },
    { id: 'users', label: 'Felhasználók', icon: Users },
    { id: 'requests', label: 'Kérések', icon: ListChecks },
  ];

  const renderLoading = () => (
    <div className="admin-loading">
      <Loader2 size={32} className="spinner" />
      <p>Betöltés...</p>
    </div>
  );

  const renderOverview = () => {
    const stats = dashboardData?.stats || {};
    const capabilities = dashboardData?.capabilities || {};

    return (
      <div className="admin-dashboard">
        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalSongs ?? 0}</span>
              <span className="admin-stat-label">Összes zene</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <Users size={24} />
            <div>
              <span className="admin-stat-value">{stats.activeUsers ?? 0}</span>
              <span className="admin-stat-label">Aktív felhasználók</span>
            </div>
          </div>
          <div className="admin-stat-card">
            <CalendarClock size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalScheduleItems ?? 0}</span>
              <span className="admin-stat-label">Órarend elemek</span>
            </div>
          </div>
        </div>

        <div className="admin-section">
          <h3><AlertCircle size={20} /> Backend korlátok</h3>
          <div className="admin-empty" style={{ textAlign: 'left' }}>
            <p>A mostani admin panel csak a backendből ténylegesen elérhető műveleteket hagyja aktívan.</p>
            <ul style={{ marginTop: '0.75rem', paddingLeft: '1rem' }}>
              <li>Felhasználólista: {capabilities.canListUsers ? 'elérhető' : 'nem elérhető a backendből'}</li>
              <li>Meglévő felhasználó szerkesztés: {capabilities.canEditExistingUsers ? 'elérhető' : 'nem elérhető a backendből'}</li>
              <li>Kéréslista: {capabilities.canListRequests ? 'elérhető' : 'nem elérhető a backendből'}</li>
              <li>Beküldéslista: {capabilities.canListSubmissions ? 'elérhető' : 'nem elérhető a backendből'}</li>
              <li>Szünetek kezelése: {capabilities.canManageBreaks ? 'elérhető' : 'nem elérhető a backendből'}</li>
            </ul>
          </div>
        </div>
      </div>
    );
  };

  const renderSongs = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Music size={20} /> Zenék kezelése ({songs.length} zene)</h3>
        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder="Keresés címre vagy előadóra..."
              value={songSearch}
              onChange={(event) => setSongSearch(event.target.value)}
            />
          </div>
          <button className="admin-add-btn" onClick={() => setShowAddSong((value) => !value)}>
            <Plus size={16} /> Új zene
          </button>
          <button className="admin-icon-btn" onClick={loadSongs} title="Frissítés">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {showAddSong && (
        <form className="admin-form" onSubmit={handleCreateSong}>
          <h4>Új zene hozzáadása</h4>
          <div className="admin-form-grid">
            <div className="form-group">
              <label>Cím</label>
              <input value={newSong.title} onChange={(event) => setNewSong((prev) => ({ ...prev, title: event.target.value }))} required />
            </div>
            <div className="form-group">
              <label>Előadó</label>
              <input value={newSong.artist} onChange={(event) => setNewSong((prev) => ({ ...prev, artist: event.target.value }))} required />
            </div>
            <div className="form-group">
              <label>Hossz (mp)</label>
              <input type="number" min="1" value={newSong.duration} onChange={(event) => setNewSong((prev) => ({ ...prev, duration: event.target.value }))} />
            </div>
            <div className="form-group">
              <label>Műfaj</label>
              <input value={newSong.genre} onChange={(event) => setNewSong((prev) => ({ ...prev, genre: event.target.value }))} />
            </div>
            <div className="form-group">
              <label>Keresési / forrás URL</label>
              <input value={newSong.sourceUrl} onChange={(event) => setNewSong((prev) => ({ ...prev, sourceUrl: event.target.value }))} placeholder="https://..." />
            </div>
            <div className="form-group">
              <label>MP3 útvonal</label>
              <input value={newSong.mp3Url} onChange={(event) => setNewSong((prev) => ({ ...prev, mp3Url: event.target.value }))} placeholder="C:\\...\\zene.mp3" required />
            </div>
            <div className="form-group">
              <label className="admin-checkbox-label">
                <input
                  type="checkbox"
                  checked={newSong.isAvailable}
                  onChange={(event) => setNewSong((prev) => ({ ...prev, isAvailable: event.target.checked }))}
                />
                Lejátszható
              </label>
            </div>
          </div>
          <div className="admin-form-actions">
            <button type="submit" className="btn btn-primary"><Save size={16} /> Mentés</button>
            <button type="button" className="btn btn-secondary" onClick={() => { setShowAddSong(false); setNewSong(EMPTY_SONG); }}><X size={16} /> Mégse</button>
          </div>
        </form>
      )}

      {filteredSongs.length === 0 ? (
        <p className="admin-empty">Nincs találat.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Cím</th>
                <th>Előadó</th>
                <th>Hossz</th>
                <th>Műfaj</th>
                <th>MP3 útvonal</th>
                <th>Kérések</th>
                <th>Elérhető</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {filteredSongs.map((song) => (
                <tr key={song.id}>
                  {editingSongId === song.id ? (
                    <>
                      <td><input className="admin-inline-input" value={editingSong.title} onChange={(event) => setEditingSong((prev) => ({ ...prev, title: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.artist} onChange={(event) => setEditingSong((prev) => ({ ...prev, artist: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" type="number" value={editingSong.duration} onChange={(event) => setEditingSong((prev) => ({ ...prev, duration: Number(event.target.value) || 0 }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.genre || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, genre: event.target.value }))} /></td>
                      <td><input className="admin-inline-input" value={editingSong.mp3Url || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, mp3Url: event.target.value }))} /></td>
                      <td>{song.requestCount ?? 0}</td>
                      <td><input type="checkbox" checked={editingSong.isAvailable} onChange={(event) => setEditingSong((prev) => ({ ...prev, isAvailable: event.target.checked }))} /></td>
                      <td className="admin-actions">
                        <button className="admin-action-btn approve" onClick={handleUpdateSong} title="Mentés"><Save size={16} /></button>
                        <button className="admin-action-btn" onClick={() => { setEditingSongId(null); setEditingSong(null); }} title="Mégse"><X size={16} /></button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td><strong>{song.title}</strong></td>
                      <td>{song.artist}</td>
                      <td>{formatDuration(song.duration)}</td>
                      <td>{song.genre || '-'}</td>
                      <td>{song.mp3Url || '-'}</td>
                      <td>{song.requestCount ?? 0}</td>
                      <td>{song.isAvailable ? 'Igen' : 'Nem'}</td>
                      <td className="admin-actions">
                        <button className="admin-action-btn" onClick={() => beginSongEdit(song)} title="Szerkesztés"><Edit2 size={16} /></button>
                        <button className="admin-action-btn reject" onClick={() => handleDeleteSong(song)} title="Törlés"><Trash2 size={16} /></button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSchedule = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><CalendarClock size={20} /> Órarend kezelése</h3>
        <button className="admin-icon-btn" onClick={loadSchedule} title="Frissítés"><RefreshCw size={16} /></button>
      </div>

      <form className="admin-form" onSubmit={handleCreateSchedule}>
        <h4>Új órarend bejegyzés</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Zene</label>
            <select value={newSchedule.zeneid} onChange={(event) => setNewSchedule((prev) => ({ ...prev, zeneid: event.target.value }))} required>
              <option value="">Válassz zenét...</option>
              {songs.map((song) => (
                <option key={song.id} value={song.id}>{song.artist} - {song.title}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Kezdés</label>
            <input type="datetime-local" value={newSchedule.mikortol} onChange={(event) => setNewSchedule((prev) => ({ ...prev, mikortol: event.target.value }))} required />
          </div>
          <div className="form-group">
            <label>Vége</label>
            <input type="datetime-local" value={newSchedule.meddig} onChange={(event) => setNewSchedule((prev) => ({ ...prev, meddig: event.target.value }))} required />
          </div>
        </div>
        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Plus size={16} /> Hozzáadás</button>
        </div>
      </form>

      {sortedSchedule.length === 0 ? (
        <p className="admin-empty">Nincs elérhető órarend bejegyzés.</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Zene</th>
                <th>Kezdés</th>
                <th>Vége</th>
                <th>Műveletek</th>
              </tr>
            </thead>
            <tbody>
              {sortedSchedule.map((item) => (
                <tr key={item.id || `${item.songId}-${item.startTime}`}>
                  <td>{item.song ? `${item.song.artist} - ${item.song.title}` : `Zene #${item.songId}`}</td>
                  <td>{formatDateTime(item.startTime)}</td>
                  <td>{formatDateTime(item.endTime)}</td>
                  <td className="admin-actions">
                    <button className="admin-action-btn reject" onClick={() => handleDeleteSchedule(item)} title="Törlés"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderUsers = () => (
    <div className="admin-section">
      <h3><Users size={20} /> Felhasználó admin műveletek</h3>

      <div className="admin-empty" style={{ textAlign: 'left', marginBottom: '1rem' }}>
        <p>A jelenlegi backenddel meglévő felhasználók teljes listája és közvetlen szerepkör-szerkesztése nem érhető el, ezért itt a működő admin műveletek szerepelnek.</p>
      </div>

      <form className="admin-form" onSubmit={handleRegisterUser}>
        <h4><UserPlus size={18} /> Bármilyen jogú felhasználó regisztrálása</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Vezetéknév</label>
            <input value={userForm.vezeteknev} onChange={(event) => setUserForm((prev) => ({ ...prev, vezeteknev: event.target.value }))} required />
          </div>
          <div className="form-group">
            <label>Keresztnév</label>
            <input value={userForm.keresztnev} onChange={(event) => setUserForm((prev) => ({ ...prev, keresztnev: event.target.value }))} required />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={userForm.email} onChange={(event) => setUserForm((prev) => ({ ...prev, email: event.target.value }))} required />
          </div>
          <div className="form-group">
            <label>OM azonosító</label>
            <input value={userForm.omazonosito} onChange={(event) => setUserForm((prev) => ({ ...prev, omazonosito: event.target.value }))} />
          </div>
          <div className="form-group">
            <label>Jelszó</label>
            <input type="password" value={userForm.password} onChange={(event) => setUserForm((prev) => ({ ...prev, password: event.target.value }))} required />
          </div>
          <div className="form-group">
            <label>Szerepkör</label>
            <select value={userForm.role} onChange={(event) => setUserForm((prev) => ({ ...prev, role: event.target.value }))}>
              <option value="user">Felhasználó</option>
              <option value="tanar">Tanár</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        </div>
        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Save size={16} /> Létrehozás</button>
        </div>
      </form>

      <form className="admin-form" onSubmit={handleDeleteUser}>
        <h4><UserX size={18} /> Felhasználó törlése email alapján</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={deleteEmail} onChange={(event) => setDeleteEmail(event.target.value)} required />
          </div>
        </div>
        <div className="admin-form-actions">
          <button type="submit" className="btn btn-secondary"><Trash2 size={16} /> Törlés</button>
        </div>
      </form>

      <form className="admin-form" onSubmit={handleLogoutUser}>
        <h4><LogOut size={18} /> Felhasználó kiléptetése email alapján</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={logoutEmail} onChange={(event) => setLogoutEmail(event.target.value)} required />
          </div>
        </div>
        <div className="admin-form-actions">
          <button type="submit" className="btn btn-secondary"><LogOut size={16} /> Kiléptetés</button>
          <button type="button" className="btn btn-secondary" onClick={logout}>Saját kijelentkezés</button>
        </div>
      </form>
    </div>
  );

  const renderRequests = () => (
    <div className="admin-section">
      <h3><ListChecks size={20} /> Kérések kezelése</h3>

      <div className="admin-empty" style={{ textAlign: 'left', marginBottom: '1rem' }}>
        <p>A backend jelenlegi verziója nem ad teljes kéréslistát, ezért a jóváhagyás kérésazonosító alapján érhető el.</p>
      </div>

      <form className="admin-form" onSubmit={handleValidateRequest}>
        <h4>Kérés jóváhagyása</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>Kérés azonosító</label>
            <input type="number" min="1" value={requestId} onChange={(event) => setRequestId(event.target.value)} required />
          </div>
        </div>
        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><CheckCircle size={16} /> Jóváhagyás</button>
        </div>
      </form>

      <div className="admin-empty" style={{ textAlign: 'left' }}>
        <p>Kérés törlés, sorrendezés és teljes kéréslista frontend-only módban nem támogatott, mert nincs hozzá backend végpont.</p>
      </div>
    </div>
  );

  const renderContent = () => {
    if (loading) {
      return renderLoading();
    }

    if (activeTab === 'overview') return renderOverview();
    if (activeTab === 'songs') return renderSongs();
    if (activeTab === 'schedule') return renderSchedule();
    if (activeTab === 'users') return renderUsers();
    if (activeTab === 'requests') return renderRequests();
    return null;
  };

  if (userLoading) {
    return renderLoading();
  }

  if (!isLoggedIn || !isAdmin) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Shield size={64} />
          <h2>Hozzáférés megtagadva</h2>
          <p>Az admin panel csak admin felhasználóknak érhető el.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page admin-page">
      <section className="page-header">
        <div className="page-header-content">
          <Shield size={32} className="page-icon" />
          <div>
            <h1 className="page-title">Admin Panel</h1>
            <p className="page-subtitle">Adminisztrátori műveletek a jelenlegi backendhez igazítva</p>
          </div>
        </div>
      </section>

      {message && (
        <div className={`admin-toast ${message.type}`}>
          {message.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)}><X size={16} /></button>
        </div>
      )}

      <div className="admin-tabs">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`admin-tab ${activeTab === id ? 'active' : ''}`} onClick={() => setActiveTab(id)}>
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      <div className="admin-content">
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminPage;

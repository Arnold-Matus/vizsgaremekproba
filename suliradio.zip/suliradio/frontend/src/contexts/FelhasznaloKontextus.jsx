import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI, favoritesAPI, preferencesAPI } from '../services/api';

const UserContext = createContext();

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleUserStateUpdate = (event) => {
      if (!event.detail) return;
      setUser(event.detail);
    };

    window.addEventListener('suliradio:user-state-updated', handleUserStateUpdate);
    return () => {
      window.removeEventListener('suliradio:user-state-updated', handleUserStateUpdate);
    };
  }, []);

  // Check for existing token on mount
  useEffect(() => {
    const token = localStorage.getItem('suliradio-token');
    if (token) {
      authAPI.me()
        .then(data => {
          if (data.success) {
            setUser(data.user);
            setIsLoggedIn(true);
          } else {
            localStorage.removeItem('suliradio-token');
          }
        })
        .catch(() => {
          localStorage.removeItem('suliradio-token');
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  // Regisztráció – a backend /regisztracio végpontján keresztül
  // Elvárja: vezeteknev, keresztnev, email, omazonosito, password
  const register = async (userData) => {
    try {
      const data = await authAPI.register(userData);
      if (data.success) {
        return { success: true };
      }
      return { success: false, error: data.error || 'Hiba történt a regisztráció során!' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  // Login
  const login = async (identifier, password) => {
    try {
      const data = await authAPI.login(identifier, password);
      if (data.success) {
        localStorage.setItem('suliradio-token', data.token);
        setUser(data.user);
        setIsLoggedIn(true);
        return { success: true, user: data.user };
      }
      return { success: false, error: data.error };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  // Logout
  const logout = useCallback(async () => {
    try {
      await authAPI.logout();
    } catch {
      // ignore
    }
    localStorage.removeItem('suliradio-token');
    setUser(null);
    setIsLoggedIn(false);
  }, []);

  // Demo login
  const demoLogin = useCallback(async () => {
    try {
      const data = await authAPI.demoLogin();
      if (data.success) {
        localStorage.setItem('suliradio-token', data.token);
        setUser(data.user);
        setIsLoggedIn(true);
        return { success: true, user: data.user };
      }
      return { success: false, error: data.error || 'Demo bejelentkezés sikertelen!' };
    } catch (error) {
      return { success: false, error: error.message || 'Nem sikerült csatlakozni a szerverhez.' };
    }
  }, []);

  // Update user data
  const updateUser = useCallback(async (updates) => {
    try {
      const data = await authAPI.updateProfile(updates);
      if (data.success) {
        setUser(data.user);
        return { success: true, user: data.user };
      }
      return { success: false, error: data.error || 'Nem sikerült frissíteni a profilt.' };
    } catch {
      return { success: false, error: 'Nem sikerült frissíteni a profilt.' };
    }
  }, []);

  const updatePreferences = useCallback(async (preferences) => {
    try {
      const data = await preferencesAPI.update(preferences);
      if (data.success && data.user) {
        setUser(data.user);
      }
      return data;
    } catch {
      return { success: false, error: 'Nem sikerült menteni a beállításokat.' };
    }
  }, []);

  // Favorites management
  const addToFavorites = useCallback(async (songId) => {
    try {
      const data = await favoritesAPI.add(songId);
      if (data.success) {
        setUser(prev => prev ? { ...prev, favorites: data.favorites } : prev);
      }
    } catch {
      // ignore
    }
  }, []);

  const removeFromFavorites = useCallback(async (songId) => {
    try {
      const data = await favoritesAPI.remove(songId);
      if (data.success) {
        setUser(prev => prev ? { ...prev, favorites: data.favorites } : prev);
      }
    } catch {
      // ignore
    }
  }, []);

  // History management (now from API - handled by MusicContext)
  const addToHistory = useCallback(() => {
    // This is now handled by the API
  }, []);

  return (
    <UserContext.Provider value={{
      user,
      isLoggedIn,
      loading,
      register,
      login,
      logout,
      demoLogin,
      updateUser,
      updatePreferences,
      addToFavorites,
      removeFromFavorites,
      addToHistory,
    }}>
      {children}
    </UserContext.Provider>
  );
};

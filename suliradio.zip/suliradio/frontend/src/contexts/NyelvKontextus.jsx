import { createContext, useContext, useEffect, useMemo } from 'react';
import { useUser } from './FelhasznaloKontextus';
import { SCHOOL_NAME } from '../constants/appInfo';

const LanguageContext = createContext(null);

const translations = {
  hu: {
    app: {
      skipToContent: 'Ugrás a tartalomhoz',
      closeToast: 'Értesítés bezárása',
    },
    nav: {
      mainNavigation: 'Fő navigáció',
      mobileNavigation: 'Mobil navigáció',
      homeAria: 'SuliRadio főoldal',
      home: 'Főoldal',
      schedule: 'Műsorrend',
      requestMusic: 'Zene kérése',
      about: 'Rólunk',
      languageSwitch: 'Nyelv váltása',
      switchToLight: 'Világos mód bekapcsolása',
      switchToDark: 'Sötét mód bekapcsolása',
      lightMode: 'Világos mód',
      darkMode: 'Sötét mód',
      switchToEnglish: 'Váltás angol nyelvre',
      languageShort: 'EN',
      userMenu: 'Felhasználói menü',
      profile: 'Profil',
      favorites: 'Kedvencek',
      history: 'Előzmények',
      notifications: 'Értesítések',
      settings: 'Beállítások',
      accessibility: 'Akadálymentesség',
      help: 'Súgó',
      privacy: 'Adatvédelem',
      adminPanel: 'Admin panel',
      logout: 'Kijelentkezés',
      login: 'Bejelentkezés',
      demoLogin: 'Demo belépés',
      loggingIn: 'Belépés...',
      closeMenu: 'Menü bezárása',
      openMenu: 'Menü megnyitása',
    },
    footer: {
      description: `${SCHOOL_NAME} sulirádiója. Te döntöd el, mi szóljon! Kérj zenét és légy részese a közösségnek.`,
      navigationAria: 'Lábléc navigáció',
      quickLinks: 'Gyors linkek',
      info: 'Információk',
      contact: 'Kapcsolat',
      schedule: 'Műsorrend',
      requestMusic: 'Zene kérése',
      about: 'Rólunk',
      help: 'Súgó',
      privacy: 'Adatvédelem',
      accessibility: 'Akadálymentesség',
      cookieSettings: 'Cookie beállítások',
      copyrightSuffix: SCHOOL_NAME,
      country: 'Békéscsaba, Magyarország',
      session: 'Munkamenet:',
      userId: 'Felhasználóazonosító:',
    },
    settings: {
      title: 'Beállítások',
      subtitle: 'Személyre szabhatod az alkalmazás működését',
      autoSave: 'A módosítások automatikusan mentődnek.',
      saved: 'Módosítás automatikusan mentve.',
      appearance: 'Megjelenés',
      darkModeLabel: 'Sötét mód',
      darkModeDescription: 'Sötét háttér a szemkímélő használatért',
      highContrastLabel: 'Magas kontraszt',
      highContrastDescription: 'Nagyobb kontraszt a jobb olvashatóságért',
      fontSizeLabel: 'Betűméret',
      fontSizeValue: 'Jelenleg: {value}px',
      decreaseFontSize: 'Betűméret csökkentése',
      increaseFontSize: 'Betűméret növelése',
      notifications: 'Értesítések',
      pushNotificationsLabel: 'Push értesítések',
      pushNotificationsDescription: 'Értesítések a zenekérésekről',
      emailNotificationsLabel: 'Email értesítések',
      emailNotificationsDescription: 'Heti összefoglaló emailben',
      audio: 'Hang',
      autoplayLabel: 'Automatikus lejátszás',
      autoplayDescription: 'Előnézet automatikus lejátszása',
      volumeLabel: 'Alapértelmezett hangerő',
      volumeDescription: '{value}%',
      languageSection: 'Nyelv és régió',
      languageLabel: 'Nyelv',
      languageDescription: 'Az alkalmazás nyelve',
      privacy: 'Adatvédelem',
      cookieSettingsLabel: 'Cookie beállítások',
      cookieSettingsDescription: 'Sütik kezelésének módosítása',
      modify: 'Módosítás',
      downloadMyDataLabel: 'Adataim letöltése',
      downloadMyDataDescription: 'Összes személyes adat és helyi aktivitás exportálása',
      download: 'Letöltés',
      preparingDownload: 'Export készítése...',
      dangerZone: 'Veszélyes zóna',
      resetSettingsLabel: 'Beállítások visszaállítása',
      resetSettingsDescription: 'Minden beállítás alapértelmezettre állítása',
      reset: 'Visszaállítás',
      deleteAccountLabel: 'Fiók törlése',
      deleteAccountDescription: 'Fiókod és minden adatod végleges törlése',
      deleteAccountButton: 'Fiók törlése',
      resetConfirm: 'Biztosan visszaállítod az összes beállítást az alapértelmezettre?',
      deleteConfirm: 'Biztosan törölni szeretnéd a fiókodat? Ez a művelet nem visszavonható!',
      exportStatusReady: 'Az export fájl JSON formátumban tartalmazza a profilodat, beállításaidat, kedvenceidet, értesítéseidet és kéréstörténetedet.',
      exportInProgress: 'Az export összeállítása folyamatban van.',
      exportSuccess: 'Az adatexport sikeresen elkészült.',
      exportError: 'Az adatexport jelenleg nem érhető el.',
    },
  },
  en: {
    app: {
      skipToContent: 'Skip to content',
      closeToast: 'Close notification',
    },
    nav: {
      mainNavigation: 'Main navigation',
      mobileNavigation: 'Mobile navigation',
      homeAria: 'SuliRadio homepage',
      home: 'Home',
      schedule: 'Schedule',
      requestMusic: 'Request music',
      about: 'About',
      languageSwitch: 'Language switch',
      switchToLight: 'Turn on light mode',
      switchToDark: 'Turn on dark mode',
      lightMode: 'Light mode',
      darkMode: 'Dark mode',
      switchToEnglish: 'Switch to Hungarian',
      languageShort: 'HU',
      userMenu: 'User menu',
      profile: 'Profile',
      favorites: 'Favorites',
      history: 'History',
      notifications: 'Notifications',
      settings: 'Settings',
      accessibility: 'Accessibility',
      help: 'Help',
      privacy: 'Privacy',
      adminPanel: 'Admin Panel',
      logout: 'Log out',
      login: 'Log in',
      demoLogin: 'Demo login',
      loggingIn: 'Signing in...',
      closeMenu: 'Close menu',
      openMenu: 'Open menu',
    },
    footer: {
      description: `The school radio of ${SCHOOL_NAME}. You decide what plays next. Request music and be part of the community.`,
      navigationAria: 'Footer navigation',
      quickLinks: 'Quick links',
      info: 'Information',
      contact: 'Contact',
      schedule: 'Schedule',
      requestMusic: 'Request music',
      about: 'About',
      help: 'Help',
      privacy: 'Privacy',
      accessibility: 'Accessibility',
      cookieSettings: 'Cookie settings',
      copyrightSuffix: SCHOOL_NAME,
      country: 'Békéscsaba, Hungary',
      session: 'Session:',
      userId: 'User ID:',
    },
    settings: {
      title: 'Settings',
      subtitle: 'Adjust how the application looks and behaves',
      autoSave: 'Changes are saved automatically.',
      saved: 'Change saved automatically.',
      appearance: 'Appearance',
      darkModeLabel: 'Dark mode',
      darkModeDescription: 'A darker background for comfortable browsing',
      highContrastLabel: 'High contrast',
      highContrastDescription: 'Stronger contrast for better readability',
      fontSizeLabel: 'Font size',
      fontSizeValue: 'Current: {value}px',
      decreaseFontSize: 'Decrease font size',
      increaseFontSize: 'Increase font size',
      notifications: 'Notifications',
      pushNotificationsLabel: 'Push notifications',
      pushNotificationsDescription: 'Notifications about music requests',
      emailNotificationsLabel: 'Email notifications',
      emailNotificationsDescription: 'Receive a weekly summary by email',
      audio: 'Audio',
      autoplayLabel: 'Autoplay previews',
      autoplayDescription: 'Automatically play previews when available',
      volumeLabel: 'Default volume',
      volumeDescription: '{value}%',
      languageSection: 'Language and region',
      languageLabel: 'Language',
      languageDescription: 'Application language',
      privacy: 'Privacy',
      cookieSettingsLabel: 'Cookie settings',
      cookieSettingsDescription: 'Manage how cookies are used',
      modify: 'Modify',
      downloadMyDataLabel: 'Download my data',
      downloadMyDataDescription: 'Export your personal data and local activity',
      download: 'Download',
      preparingDownload: 'Preparing export...',
      dangerZone: 'Danger zone',
      resetSettingsLabel: 'Reset settings',
      resetSettingsDescription: 'Restore every setting to its default value',
      reset: 'Reset',
      deleteAccountLabel: 'Delete account',
      deleteAccountDescription: 'Permanently remove your account and data',
      deleteAccountButton: 'Delete account',
      resetConfirm: 'Are you sure you want to reset every setting to its default value?',
      deleteConfirm: 'Are you sure you want to delete your account? This action cannot be undone!',
      exportStatusReady: 'The JSON export includes your profile, settings, favorites, notifications, and request history.',
      exportInProgress: 'Preparing your export package.',
      exportSuccess: 'Your data export is ready.',
      exportError: 'Data export is currently unavailable.',
    },
  },
};

const resolveTranslation = (language, key) => {
  const segments = key.split('.');
  let current = translations[language] || translations.hu;

  for (const segment of segments) {
    if (current && typeof current === 'object' && segment in current) {
      current = current[segment];
    } else {
      current = null;
      break;
    }
  }

  if (typeof current === 'string') {
    return current;
  }

  let fallback = translations.hu;
  for (const segment of segments) {
    if (fallback && typeof fallback === 'object' && segment in fallback) {
      fallback = fallback[segment];
    } else {
      return key;
    }
  }

  return typeof fallback === 'string' ? fallback : key;
};

export const formatMessage = (template, values = {}) => template.replace(/\{(.*?)\}/g, (_, key) => values[key] ?? '');

const fallbackLanguageContext = {
  language: 'hu',
  setLanguage: () => {},
  t: (key, values) => formatMessage(resolveTranslation('hu', key), values),
};

export const useI18n = () => useContext(LanguageContext) || fallbackLanguageContext;

export const LanguageProvider = ({ children }) => {
  const { preferences, updatePreferences } = useUser();
  const language = preferences?.language === 'en' ? 'en' : 'hu';

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const value = useMemo(() => ({
    language,
    setLanguage: (nextLanguage) => updatePreferences({ language: nextLanguage === 'en' ? 'en' : 'hu' }),
    t: (key, values) => formatMessage(resolveTranslation(language, key), values),
  }), [language, updatePreferences]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};
import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { songsAPI, scheduleAPI, requestsAPI } from '../services/api';

const MusicContext = createContext();

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusic must be used within a MusicProvider');
  }
  return context;
};

export const MusicProvider = ({ children }) => {
  const [songs, setSongs] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [queue] = useState([]);
  const [currentlyPlaying, setCurrentlyPlaying] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('title');
  const [sortOrder, setSortOrder] = useState('asc');
  const [filterGenre, setFilterGenre] = useState('all');
  const [selectedSongs, setSelectedSongs] = useState([]);
  const [genres, setGenres] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalSongs: 0,
    todayRequests: 0,
    activeUsers: 0,
    currentListeners: 0,
  });
  const [loading, setLoading] = useState(true);

  // Daily request status
  const [dailyStatus, setDailyStatus] = useState({
    maxDaily: 3,
    usedToday: 0,
    remaining: 3,
    requestedSongIds: [],
    lastRequestedSongId: null,
  });

  // Data freshness tracking — increment to force refetch
  const [dataVersion, setDataVersion] = useState(0);
  const invalidateData = useCallback(() => setDataVersion(v => v + 1), []);

  // Audio player state
  const audioRef = useRef(new Audio());
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioElapsed, setAudioElapsed] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [volume, setVolume] = useState(() => {
    const saved = localStorage.getItem('suliradio-volume');
    return saved ? parseFloat(saved) : 0.7;
  });

  // Initialize audio element
  useEffect(() => {
    const audio = audioRef.current;
    audio.volume = volume;

    const onTimeUpdate = () => setAudioElapsed(Math.floor(audio.currentTime));
    const onLoadedMetadata = () => setAudioDuration(Math.floor(audio.duration));
    const onEnded = () => {
      setIsPlaying(false);
      setAudioElapsed(0);
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.pause();
    };
  }, []);

  // Volume change
  useEffect(() => {
    audioRef.current.volume = volume;
    localStorage.setItem('suliradio-volume', volume.toString());
  }, [volume]);

  // Play a song by its mp3Url
  const playSong = useCallback((song) => {
    if (!song?.mp3Url) return;
    const audio = audioRef.current;
    audio.src = song.mp3Url;
    audio.play().catch(err => console.error('Playback error:', err));
    setCurrentlyPlaying(song);
    setIsPlaying(true);
  }, []);

  const togglePlayPause = useCallback(() => {
    const audio = audioRef.current;
    if (audio.paused) {
      audio.play().catch(err => console.error('Play error:', err));
    } else {
      audio.pause();
    }
  }, []);

  const seekTo = useCallback((seconds) => {
    audioRef.current.currentTime = seconds;
  }, []);

  const stopPlayback = useCallback(() => {
    const audio = audioRef.current;
    audio.pause();
    audio.currentTime = 0;
    audio.src = '';
    setIsPlaying(false);
    setAudioElapsed(0);
    setAudioDuration(0);
  }, []);

  // Load songs from API
  const loadSongs = useCallback(async () => {
    try {
      const data = await songsAPI.getAll();
      if (data.success) {
        setSongs(data.songs);
      }
    } catch (error) {
      console.error('Failed to load songs:', error);
    }
  }, []);

  // Load genres
  const loadGenres = useCallback(async () => {
    try {
      const data = await songsAPI.getGenres();
      if (data.success) {
        setGenres(data.genres);
      }
    } catch (error) {
      console.error('Failed to load genres:', error);
    }
  }, []);

  // Load stats
  const loadStats = useCallback(async () => {
    try {
      const data = await songsAPI.getStats();
      if (data.success) {
        setStats(data.stats);
        // Ha a szerver jelez, hogy most valami szól (admin beállította "playing"-re)
        // és van MP3, automatikusan lejátsszuk
        if (data.stats.currentlyPlaying) {
          const serverSong = data.stats.currentlyPlaying.song;
          const currentId = currentlyPlaying?.id;
          
          // Ha más zene szól a szerveren mint nálunk, váltsunk
          if (serverSong.id !== currentId && serverSong.mp3Url) {
            const songWithMeta = {
              ...serverSong,
              scheduleItem: {
                requestedBy: data.stats.currentlyPlaying.requestedBy,
                time: data.stats.currentlyPlaying.time,
              },
              startedAt: data.stats.currentlyPlaying.startedAt,
            };
            
            // Auto-play a rádióból ha van MP3
            const audio = audioRef.current;
            audio.src = serverSong.mp3Url;
            
            // Szinkronizálás: ugrik oda ahol a zene éppen tart
            const startTime = new Date(data.stats.currentlyPlaying.startedAt).getTime();
            const elapsedSecs = Math.floor((Date.now() - startTime) / 1000);
            if (elapsedSecs > 0 && elapsedSecs < serverSong.duration) {
              audio.currentTime = elapsedSecs;
            }
            
            audio.play().catch(() => {}); // Autoplay may be blocked
            setCurrentlyPlaying(songWithMeta);
          } else if (serverSong.id !== currentId) {
            // Nincs MP3, de megmutatjuk mit játszik a rádió
            setCurrentlyPlaying({
              ...serverSong,
              scheduleItem: {
                requestedBy: data.stats.currentlyPlaying.requestedBy,
                time: data.stats.currentlyPlaying.time,
              },
              startedAt: data.stats.currentlyPlaying.startedAt,
            });
          }
        } else if (currentlyPlaying?.scheduleItem) {
          // Ha a szerver már nem játszik semmit, és mi rádió módban voltunk, állítsuk le
          stopPlayback();
          setCurrentlyPlaying(null);
        }
      }
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  }, [currentlyPlaying?.id]);

  // Load daily request status
  const loadDailyStatus = useCallback(async () => {
    try {
      const data = await requestsAPI.dailyStatus();
      if (data.success) {
        setDailyStatus({
          maxDaily: data.maxDaily,
          usedToday: data.usedToday,
          remaining: data.remaining,
          requestedSongIds: data.requestedSongIds || [],
          lastRequestedSongId: data.lastRequestedSongId,
        });
      }
    } catch {
      // Not logged in or error — ignore
    }
  }, []);

  // Initial load
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      await Promise.all([loadSongs(), loadGenres(), loadStats(), loadDailyStatus()]);
      setLoading(false);
    };
    init();

    // Stats polling kikapcsolva – a backend jelenleg nem rendelkezik stats végponttal.
    // Ha majd lesz /api/stats végpont, ezt vissza kell kapcsolni:
    // const interval = setInterval(loadStats, 10000);
    // return () => clearInterval(interval);
  }, [loadSongs, loadGenres, loadStats, loadDailyStatus]);

  useEffect(() => {
    const handleUserStateChanged = () => {
      loadStats();
      loadDailyStatus();
    };

    window.addEventListener('suliradio:user-state-updated', handleUserStateChanged);
    return () => {
      window.removeEventListener('suliradio:user-state-updated', handleUserStateChanged);
    };
  }, [loadDailyStatus, loadStats]);

  // Refetch songs and daily status when data is invalidated
  useEffect(() => {
    if (dataVersion > 0) {
      loadSongs();
      loadDailyStatus();
      loadStats();
    }
  }, [dataVersion, loadSongs, loadDailyStatus, loadStats]);

  // Filter and sort songs
  const filteredSongs = useCallback(() => {
    let result = [...songs];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(song =>
        song.title.toLowerCase().includes(query) ||
        song.artist.toLowerCase().includes(query) ||
        (song.album || '').toLowerCase().includes(query) ||
        (song.genre || '').toLowerCase().includes(query)
      );
    }

    if (filterGenre !== 'all') {
      result = result.filter(song => song.genre === filterGenre);
    }

    result.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'title':
          comparison = a.title.localeCompare(b.title, 'hu');
          break;
        case 'artist':
          comparison = a.artist.localeCompare(b.artist, 'hu');
          break;
        case 'duration':
          comparison = a.duration - b.duration;
          break;
        case 'uploadDate':
          comparison = new Date(a.uploadDate) - new Date(b.uploadDate);
          break;
        case 'requestCount':
          comparison = a.requestCount - b.requestCount;
          break;
        default:
          comparison = 0;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [songs, searchQuery, sortBy, sortOrder, filterGenre]);

  // Toggle song selection
  const toggleSongSelection = (songId) => {
    setSelectedSongs(prev =>
      prev.includes(songId)
        ? prev.filter(id => id !== songId)
        : [...prev, songId]
    );
  };

  const selectAllSongs = () => {
    const allIds = filteredSongs().map(song => song.id);
    setSelectedSongs(allIds);
  };

  const clearSelection = () => {
    setSelectedSongs([]);
  };

  // Request songs via API
  const requestSongs = async (songIds, userId, message) => {
    try {
      const data = await requestsAPI.create(songIds, message);
      if (!data.success) {
        throw new Error(data.error || 'A zenekérés nem sikerült.');
      }

      clearSelection();
      invalidateData(); // Refresh all data (stats, daily status, songs)
      return data;
    } catch (error) {
      console.error('Failed to request songs:', error);
      throw error;
    }
  };

  // Add song (admin only - now through API)
  const addSong = (songData) => {
    // This is handled through admin API now
    const newSong = {
      id: Date.now(),
      ...songData,
      uploadDate: new Date().toISOString(),
      requestCount: 0,
      isAvailable: true,
    };
    setSongs(prev => [...prev, newSong]);
    return newSong;
  };

  const removeSong = (songId) => {
    setSongs(prev => prev.filter(s => s.id !== songId));
  };

  const updateSong = (songId, updates) => {
    setSongs(prev => prev.map(s =>
      s.id === songId ? { ...s, ...updates } : s
    ));
  };

  const getSongById = (id) => {
    return songs.find(s => s.id === id);
  };

  // Load schedule from API
  const loadSchedule = useCallback(async (date) => {
    try {
      const dateStr = date ? date.toISOString().split('T')[0] : undefined;
      const data = await scheduleAPI.get(dateStr);
      if (data.success) {
        setSchedule(data.schedule);
        return data.schedule;
      }
    } catch (error) {
      console.error('Failed to load schedule:', error);
    }
    return [];
  }, []);

  const getScheduleWithSongs = useCallback(() => {
    return schedule.map(item => ({
      ...item,
      song: item.song || getSongById(item.songId),
    }));
  }, [schedule, songs]);

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <MusicContext.Provider value={{
      songs,
      schedule,
      queue,
      currentlyPlaying,
      searchQuery,
      setSearchQuery,
      sortBy,
      setSortBy,
      sortOrder,
      setSortOrder,
      filterGenre,
      setFilterGenre,
      genres,
      filteredSongs,
      selectedSongs,
      toggleSongSelection,
      selectAllSongs,
      clearSelection,
      requestSongs,
      addSong,
      removeSong,
      updateSong,
      getSongById,
      getScheduleWithSongs,
      loadSchedule,
      loadSongs,
      loadStats,
      stats,
      loading,
      formatDuration,
      // Daily request status
      dailyStatus,
      loadDailyStatus,
      invalidateData,
      // Audio player
      isPlaying,
      audioElapsed,
      audioDuration,
      volume,
      setVolume,
      playSong,
      togglePlayPause,
      seekTo,
      stopPlayback,
    }}>
      {children}
    </MusicContext.Provider>
  );
};

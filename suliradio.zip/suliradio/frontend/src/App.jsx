import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeProvider } from './contexts/TemaKontextus';
import { UserProvider } from './contexts/FelhasznaloKontextus';
import { MusicProvider } from './contexts/ZeneKontextus';
import { CookieProvider } from './contexts/SutiKontextus';

import Navigacio from './components/Navigacio';
import Lablec from './components/Lablec';
import SutiSav from './components/SutiSav';

import Fooldal from './pages/Fooldal';
import Musorrend from './pages/Musorrend';
import ZeneKeres from './pages/ZeneKeres';
import Rolunk from './pages/Rolunk';
import Profil from './pages/Profil';
import Beallitasok from './pages/Beallitasok';
import Akadalymentesseg from './pages/Akadalymentesseg';
import Adatvedelem from './pages/Adatvedelem';
import Segitseg from './pages/Segitseg';
import NemTalalt from './pages/NemTalalt';
import Bejelentkezes from './pages/Bejelentkezes';
import Regisztracio from './pages/Regisztracio';
import ElfelejtettemJelszot from './pages/ElfelejtettemJelszot';
import ZeneHozzaadas from './pages/ZeneHozzaadas';
import Kedvencek from './pages/Kedvencek';
import Elozmenyek from './pages/Elozmenyek';
import Ertesitesek from './pages/Ertesitesek';
import Feltetelek from './pages/Feltetelek';
import Admin from './pages/Admin';

import './styles/main.css';

// Oldalszerkezet – Navigáció és lábléc csak nem-bejelentkezési oldalakon jelenik meg
const AlkalmazasElrendezese = () => {
  const location = useLocation();
  const bejelentkezesiOldal = ['/bejelentkezes', '/regisztracio', '/elfelejtett-jelszo'].includes(location.pathname);

  return (
    <div className="app">
      <a href="#fo-tartalom" className="skip-link">
        Ugrás a tartalomhoz
      </a>
      {!bejelentkezesiOldal && <Navigacio />}
      <main id="fo-tartalom" className={`main-content${bejelentkezesiOldal ? ' auth-page' : ''}`} style={bejelentkezesiOldal ? { paddingTop: 0, padding: 0 } : {}}>
        <Routes>
          <Route path="/" element={<Fooldal />} />
          <Route path="/musorrend" element={<Musorrend />} />
          <Route path="/zene-keres" element={<ZeneKeres />} />
          <Route path="/rolunk" element={<Rolunk />} />
          <Route path="/profil" element={<Profil />} />
          <Route path="/beallitasok" element={<Beallitasok />} />
          <Route path="/akadalymentes" element={<Akadalymentesseg />} />
          <Route path="/adatvedelem" element={<Adatvedelem />} />
          <Route path="/sutik" element={<Adatvedelem />} />
          <Route path="/feltetelek" element={<Feltetelek />} />
          <Route path="/segitseg" element={<Segitseg />} />
          <Route path="/kedvencek" element={<Kedvencek />} />
          <Route path="/elozmenyek" element={<Elozmenyek />} />
          <Route path="/ertesitesek" element={<Ertesitesek />} />
          <Route path="/bejelentkezes" element={<Bejelentkezes />} />
          <Route path="/regisztracio" element={<Regisztracio />} />
          <Route path="/elfelejtett-jelszo" element={<ElfelejtettemJelszot />} />
          <Route path="/zene-hozzaadas" element={<ZeneHozzaadas />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<NemTalalt />} />
        </Routes>
      </main>
      {!bejelentkezesiOldal && <Lablec />}
      <SutiSav />
    </div>
  );
};

function App() {
  return (
    <ThemeProvider>
      <UserProvider>
        <MusicProvider>
          <CookieProvider>
            <Router>
              <AlkalmazasElrendezese />
            </Router>
          </CookieProvider>
        </MusicProvider>
      </UserProvider>
    </ThemeProvider>
  );
}

export default App;

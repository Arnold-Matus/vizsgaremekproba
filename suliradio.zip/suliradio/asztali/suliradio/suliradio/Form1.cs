using System.Diagnostics.Eventing.Reader;
using System.Reflection.Metadata.Ecma335;
using System.Timers;
using System.Xml.Linq;
using static suliradio.Zenek;

namespace suliradio
{
    public partial class Form1 : Form
    {
        private Lejatszo Lejatszo;

        public Form1()
        {
            Instance = this;
            InitializeComponent();
            Lejatszo = new Lejatszo();
        }
        public static Form1 Instance { get; private set; }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Instance = this;
        }

        public List<Zenek> Zenelista { get; set; } = new List<Zenek>();
        public List<Zenek> Varolista { get; set; } = new List<Zenek>();
        public List<CsengetesiRend> CsengetesiRend { get; set; } = new List<CsengetesiRend>();//Sz�val, a CsengetesiRend oszt�ly val�ban nem csenget�si rendeknek a tulajdons�gait tartalmazza, hanem egy-egy sz�net adatait :/ Csak fur�n neveztem el
        public bool CsengetesiRendAktiv { get; set; } = false;
        private System.Timers.Timer Timer;
        private bool CsengetesiMotorRunning = false;
        private bool LejatszasIdoRunning = false;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void zenemappaHely�nekMegad�saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Mappa kiv�laszt�sa
            ///regi nem biztonsagos modszer inkabb commonopenfiledialog
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "V�laszd ki a zenemapp�t";
                dialog.UseDescriptionForTitle = true;

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedPath = dialog.SelectedPath;
                    //beolvas�s a megadott mapp�b�l a list�ban l�v� megl�v� elemek megtart�s�val
                    //a megegyez� el�ad�j� �s c�m� zen�k ne ker�ljenek be k�tszer a list�ba
                    //r�gi rossz: Zenelista = Zenek.Fajlbeolvas(selectedPath);
                    List<Zenek> ujZenek = Zenek.Fajlbeolvas(selectedPath);
                    foreach (var zene in ujZenek)
                    {
                        if (!Zenelista.Any(z => z.Eloado == zene.Eloado && z.Cim == zene.Cim))
                        {
                            Zenelista.Add(zene);
                        }
                    }
                    MessageBox.Show($"Kiv�lasztott mappa:\n{selectedPath}");
                    ZenelistaFrissit(Zenelista);

                }
            }
        }

        public void BeallitasMento()
        {
            //beallitasok mentese egy f�jlba, hogy legk�zelebb is meglegyenek
            //pl csengetesi rend=>csengetes.csv, zenelista=>zenelista.csv
            StreamWriter writer = new StreamWriter("csengetes.csv");
            foreach (var szunet in CsengetesiRend)
            {
                writer.WriteLine($"{szunet.SzunetSorszam};{szunet.SzunetKezdet};{szunet.SzunetVege}");
            }
            writer.Close();
            StreamWriter writer2 = new StreamWriter("zenelista.csv");
            foreach (var zene in Zenelista)
            {
                writer2.WriteLine($"{zene.ZeneID};{zene.EleresiUt};{zene.Eloado};{zene.Cim};{zene.FajlNev};{zene.Hossz};{zene.ZeneForrasa}");
            }
            writer2.Close();
            StreamWriter writer3 = new StreamWriter("varolista.csv");
            foreach (var zene in Varolista)
            {
                writer3.WriteLine($"{zene.ZeneID};{zene.EleresiUt};{zene.Eloado};{zene.Cim};{zene.FajlNev};{zene.Hossz};{zene.ZeneForrasa}");
            }
            writer3.Close();
        }

        public void BeallitasBetolto()
        {
            try
            {
                CsengetesiRend.Clear();
                Zenelista.Clear();
                Varolista.Clear();
                using (StreamReader reader = new StreamReader("csengetes.csv"))
                {
                    string? line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(';');
                        if (parts.Length >= 3 &&
                            int.TryParse(parts[0], out int sorszam) &&
                            TimeSpan.TryParse(parts[1], out TimeSpan kezdet) &&
                            TimeSpan.TryParse(parts[2], out TimeSpan vege))
                        {
                            CsengetesiRend.Add(new CsengetesiRend(sorszam, kezdet, vege));
                        }
                    }
                }

                using (StreamReader reader2 = new StreamReader("zenelista.csv"))
                {
                    string? line2;
                    while ((line2 = reader2.ReadLine()) != null)
                    {
                        string[] parts = line2.Split(';');
                        if (parts.Length >= 7 &&
                            int.TryParse(parts[0], out int zeneID) &&
                            TimeSpan.TryParse(parts[5], out TimeSpan hossz) &&
                            Enum.TryParse<Zenek.Forras>(parts[6], out Zenek.Forras zeneForrasa))
                        {
                            string eleresiUt = parts[1];
                            string eloado = parts[2];
                            string cim = parts[3];
                            string fajlNev = parts[4];
                            Zenelista.Add(new Zenek(zeneID, eleresiUt, eloado, cim, fajlNev, hossz, zeneForrasa));
                        }
                    }
                }
                using (StreamReader reader3 = new StreamReader("varolista.csv"))
                {
                    string? line3;
                    while ((line3 = reader3.ReadLine()) != null)
                    {
                        string[] parts = line3.Split(';');
                        if (parts.Length >= 7 &&
                            int.TryParse(parts[0], out int zeneID) &&
                            TimeSpan.TryParse(parts[5], out TimeSpan hossz) &&
                            Enum.TryParse<Zenek.Forras>(parts[6], out Zenek.Forras zeneForrasa))
                        {
                            string eleresiUt = parts[1];
                            string eloado = parts[2];
                            string cim = parts[3];
                            string fajlNev = parts[4];
                            Varolista.Add(new Zenek(zeneID, eleresiUt, eloado, cim, fajlNev, hossz, zeneForrasa));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a be�ll�t�sok bet�lt�sekor: {ex.Message}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public async Task CsengetesiMotor(List<CsengetesiRend> CsegnetesiRend)
        {
            while (true)
            {
                if (CsengetesiRendAktiv == true)
                {
                    TimeSpan aktualisIdo = DateTime.Now.TimeOfDay;
                    foreach (var szunet in CsengetesiRend)
                    {
                        if (aktualisIdo >= szunet.SzunetKezdet && aktualisIdo <= szunet.SzunetVege)
                        {
                            if (!Lejatszo.IsPlaying)
                            {
                                var lastZene = Varolista[0];
                                var eerer = Zenelista.Find(x => x.Cim == lastZene.Cim);
                                if (eerer != null)
                                {
                                    string eleresiut = eerer.EleresiUt;
                                    Lejatszo.Play(eleresiut);
                                    AktualisZeneFrissit(eerer);
                                    Varolista.RemoveAt(0);
                                    VaroListaFrissit(Varolista);
                                }
                            }
                        }
                        else
                        {
                            Lejatszo.FadeOutAndStop();
                            AktualisZeneFrissit();
                        }
                    }
                }
                await Task.Delay(1000);
            }
        }
        public void ZenelistaFrissit(List<Zenek> Zenelista)
        {
            lv_zenelista.Items.Clear();
            lv_zenelista.Columns.Clear();
            lv_zenelista.View = View.Details;
            lv_zenelista.Columns.Add("El�ad�", 150);
            lv_zenelista.Columns.Add("C�m", 150);
            lv_zenelista.Columns.Add("Hossz", 100);
            lv_zenelista.FullRowSelect = true;

            foreach (var zene in Zenelista)
            {
                ListViewItem item = new ListViewItem(zene.Eloado);
                item.SubItems.Add(zene.Cim);
                item.SubItems.Add(zene.Hossz.ToString(@"mm\:ss"));
                lv_zenelista.Items.Add(item);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv_zenelista.SelectedItems.Count != 0)
            {
                tb_kijeloltcim.Text = lv_zenelista.SelectedItems[0].SubItems[1].Text;
                tb_kijelolteloado.Text = lv_zenelista.SelectedItems[0].SubItems[0].Text;
            }
        }

        private void zenemappaBez�r�saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Biztosan t�rl�d a zenelist�t? A f�jlok megmaradnak, de az �sszes bet�lt�tt zene utvonal�t �s a v�r�list�t elfelejti a szoftver.", "Zenemappa bez�r�sa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                lv_zenelista.Items.Clear();
                lv_varolista.Items.Clear();
                Zenelista.Clear();
                Varolista.Clear();
                ZenelistaFrissit(Zenelista);
                VaroListaFrissit(Varolista);
                MessageBox.Show("Zenemappa bez�rva, zenelista t�r�lve");
            }
        }

        private void bt_hozzaad_Click(object sender, EventArgs e)
        {
            if (lv_zenelista.SelectedItems.Count == 0)
            {
                MessageBox.Show("Nincs kijel�lt zene!"); return;
            }
            else
            {
                var eerer = Zenelista.Find(x => x.Cim == lv_zenelista.SelectedItems[0].SubItems[1].Text);
                if (eerer is null) { MessageBox.Show("Valami hiba t�rt�nt, nem tal�lom a zen�t a list�ban"); return; }
                else { Varolista.Add(eerer); VaroListaFrissit(Varolista); } //v�r�lista: legyen hozz�ad�s id�pontja is, hogy k�s�bb lehessen rendezni
                                                                            //legyen a listbox lecser�lve 
            }


        }
        public void VaroListaFrissit(List<Zenek> Varolista)
        {
            lv_varolista.Items.Clear();
            lv_varolista.Columns.Clear();
            lv_varolista.View = View.Details;
            lv_varolista.Columns.Add("El�ad�", 150);
            lv_varolista.Columns.Add("C�m", 150);
            lv_varolista.Columns.Add("Hossz", 100);
            lv_varolista.FullRowSelect = true;
            foreach (var zene in Varolista)
            {
                ListViewItem item = new ListViewItem(zene.Eloado);
                item.SubItems.Add(zene.Cim);
                item.SubItems.Add(zene.Hossz.ToString(@"mm\:ss"));
                lv_varolista.Items.Add(item);
            }
        }

        public void AktualisZeneFrissit(Zenek aktualisZene)
        {
            tb_cim.Text = aktualisZene.Cim;
            tb_eloado.Text = aktualisZene.Eloado;
        }
        public void AktualisZeneFrissit()
        {
            tb_cim.Text = "C�m";
            tb_eloado.Text = "El�ad�";
        }

        public void LetoltottZeneHozzaad(string substr)
        {
            List<Zenek> ujZenek = Zenek.Fajlbeolvas("zenek");
            var tagFile = TagLib.File.Create(substr);
            string eloado = tagFile.Tag.FirstPerformer ?? tagFile.Tag.JoinedPerformers ?? "Ismeretlen el�ad�";
            string cim = tagFile.Tag.Title ?? Path.GetFileNameWithoutExtension(substr);
            TimeSpan hossz = tagFile.Properties.Duration;
            Zenek zene = new Zenek(substr, eloado, cim, Path.GetFileName(substr), hossz, Forras.Mappa);
            Zenelista.Add(zene);
            if (!Zenelista.Any(z => z.Eloado == zene.Eloado && z.Cim == zene.Cim))
            {
                Zenelista.Add(zene);
            }
            if (!Varolista.Any(z => z.Eloado == zene.Eloado && z.Cim == zene.Cim))
            {
                Varolista.Add(zene);
            }
            ZenelistaFrissit(Zenelista);
            VaroListaFrissit(Varolista);
        }

        private void bt_eltavolit_Click(object sender, EventArgs e)
        {
            if (lv_varolista.SelectedItems.Count == 0) { MessageBox.Show("Nincs kijel�lt zene!"); return; }
            else
            {
                //index alapj�n elt�vol�tjuk a v�r�list�b�l az lv_varolisa-n kijel�lt elemet
                Varolista.RemoveAt(lv_varolista.SelectedIndices[0]);
                VaroListaFrissit(Varolista);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Lejatszo.IsPlaying == false && lv_varolista.SelectedItems.Count > 0)
            {
                var eerer = Zenelista.Find(x => x.Cim == lv_varolista.SelectedItems[0].SubItems[1].Text); //Hibakezel�s sz�ks�ges
                string eleresiut = eerer.EleresiUt;
                Lejatszo.Play(eleresiut);
                AktualisZeneFrissit(eerer);
            }
            else
            {
                Lejatszo.FadeOutAndStop();
                AktualisZeneFrissit();
            }
            if (LejatszasIdoRunning == false) {
                LejatszasIdoRunning = true;
                _ = LejatszasIdo();
            }
        }

        private void csenget�siRendToolStripMenuItem_Click(object sender, EventArgs e)
        {
            beallitasok1 beallitasok = new beallitasok1(this);
            beallitasok.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (CsengetesiRendAktiv == true)
            {
                CsengetesiRendAktiv = false;
                button3.Text = "Automatikus lej�tsz�s: KI";
                button3.BackColor = Color.DarkGray;
                CsengetesiMotorRunning = false;
                _ = Lejatszo.FadeOutAndStop();
            }
            else
            {
                if (!CsengetesiMotorRunning)
                {
                    CsengetesiRendAktiv = true;
                    button3.Text = "Automatikus lej�tsz�s: BE";
                    button3.BackColor = Color.DarkGreen;
                    CsengetesiMotorRunning = true;
                    _ = CsengetesiMotor(CsengetesiRend);
                }
            }
            if (LejatszasIdoRunning == false)
            {
                LejatszasIdoRunning = true;
                _ = LejatszasIdo();
            }
        }

        private void let�lt�ttZen�kMegnyit�saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<Zenek> ujZenek = Zenek.Fajlbeolvas("zenek");
            foreach (var zene in ujZenek)
            {
                if (!Zenelista.Any(z => z.Eloado == zene.Eloado && z.Cim == zene.Cim))
                {
                    Zenelista.Add(zene);
                }
            }
            MessageBox.Show($"Kiv�lasztott mappa: Let�lt�tt zen�k mapp�ja");
            ZenelistaFrissit(Zenelista);
        }

        private void zenelet�lt�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //letolto form megnyit�sa:
            Letolto letolto = new Letolto();
            letolto.ShowDialog();
        }

        private void be�ll�t�sokBet�lt�seToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Meger�s�t�s messagebox:
            DialogResult result = MessageBox.Show("Biztosan bet�lt�d a be�ll�t�sokat? Ezzel fel�l�rod a jelenlegi be�ll�t�sokat!", "Be�ll�t�sok bet�lt�se", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            BeallitasBetolto();
            ZenelistaFrissit(Zenelista);
            VaroListaFrissit(Varolista);
        }

        private void be�ll�t�sokMent�seToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BeallitasMento();
        }

        private void kil�p�sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void f�jlToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void zenelistaFriss�t�seToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZenelistaFrissit(Zenelista);
            VaroListaFrissit(Varolista);
        }

        private void lb_idosav_Click(object sender, EventArgs e)
        {
            lb_idosav.Text = Lejatszo.CurrentTime().ToString();
        }
        public async Task LejatszasIdo() {
            while (LejatszasIdoRunning == true) {
                if (Lejatszo.IsPlaying == true)
                {
                    lb_idosav.Text = Lejatszo.CurrentTime().ToString();
                }
                await Task.Delay(200);
            }

        }
    }
}

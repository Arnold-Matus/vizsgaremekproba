<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Database\QueryException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => \App\Http\Middleware\AdminMiddleware::class,
        ]);

        $middleware->api(prepend: [
            \Illuminate\Http\Middleware\HandleCors::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {

        // --- API-specific exception rendering ---
        $exceptions->render(function (QueryException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                // Log the real SQL error for debugging
                \Illuminate\Support\Facades\Log::error('Database error: ' . $e->getMessage());

                // Detect specific constraint violations
                $errorCode = $e->errorInfo[1] ?? null;
                $message = match (true) {
                    // UNIQUE constraint violation (SQLite: 19, MySQL: 1062)
                    in_array($errorCode, [19, 1062]) => 'Ez az adat már létezik a rendszerben. Kérlek ellenőrizd, hogy nem duplikálsz-e valamit!',
                    // Foreign key constraint (MySQL: 1452)
                    $errorCode === 1452 => 'A hivatkozott adat nem található. Lehet, hogy időközben törölték.',
                    // Cannot delete, foreign key restricts (MySQL: 1451)
                    $errorCode === 1451 => 'Ezt az elemet nem lehet törölni, mert más adatok hivatkoznak rá.',
                    default => 'Adatbázis hiba történt. Kérlek próbáld újra később, vagy jelezd az adminisztrátornak!',
                };

                return response()->json([
                    'success' => false,
                    'error' => $message,
                ], 500);
            }
        });

        $exceptions->render(function (ModelNotFoundException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                // Map model names to Hungarian
                $modelMap = [
                    'Song' => 'zene',
                    'User' => 'felhasználó',
                    'SongRequest' => 'zenekérés',
                    'SongSubmission' => 'beküldés',
                    'Favorite' => 'kedvenc',
                ];
                $modelClass = class_basename($e->getModel());
                $modelName = $modelMap[$modelClass] ?? 'elem';

                return response()->json([
                    'success' => false,
                    'error' => "A keresett {$modelName} nem található. Lehet, hogy már törölték vagy nem létezik.",
                ], 404);
            }
        });

        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'A keresett oldal vagy erőforrás nem található.',
                ], 404);
            }
        });

        $exceptions->render(function (AuthenticationException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'A munkameneted lejárt, kérlek jelentkezz be újra!',
                ], 401);
            }
        });

        $exceptions->render(function (AccessDeniedHttpException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Nincs jogosultságod ehhez a művelethez!',
                ], 403);
            }
        });

        $exceptions->render(function (ValidationException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Kérlek ellenőrizd a megadott adatokat!',
                    'errors' => $e->errors(),
                ], 422);
            }
        });

        $exceptions->render(function (MethodNotAllowedHttpException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Ez a művelet nem engedélyezett ezen az elérési úton.',
                ], 405);
            }
        });

        $exceptions->render(function (TooManyRequestsHttpException $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Túl sok kérést küldtél! Kérlek várj egy kicsit, majd próbáld újra.',
                ], 429);
            }
        });

        // Catch-all for any other exceptions on API routes
        $exceptions->render(function (\Throwable $e, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                \Illuminate\Support\Facades\Log::error('Unhandled exception: ' . $e->getMessage(), [
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);

                return response()->json([
                    'success' => false,
                    'error' => 'Váratlan szerverhiba történt. Kérlek próbáld újra később!',
                ], 500);
            }
        });

    })->create();

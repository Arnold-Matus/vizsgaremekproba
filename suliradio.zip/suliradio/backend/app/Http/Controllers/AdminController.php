<?php

namespace App\Http\Controllers;

use App\Models\Song;
use App\Models\SongRequest;
use App\Models\SongSubmission;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    // ========== DASHBOARD ==========
    public function dashboard()
    {
        $nowPlaying = SongRequest::where('status', 'playing')->exists();

        $recentSubmissions = SongSubmission::with('user')
            ->orderByDesc('created_at')
            ->limit(10)
            ->get()
            ->map(fn($s) => [
                'id' => $s->id,
                'url' => $s->url,
                'title' => $s->title,
                'artist' => $s->artist,
                'status' => $s->status,
                'user' => $s->user ? ['name' => $s->user->name] : null,
                'created_at' => $s->created_at->toISOString(),
            ]);

        $recentRequests = SongRequest::with(['song', 'user'])
            ->orderByDesc('created_at')
            ->limit(10)
            ->get()
            ->map(fn($r) => [
                'id' => $r->id,
                'status' => $r->status,
                'user' => $r->user ? ['name' => $r->user->name] : null,
                'song' => $r->song ? ['title' => $r->song->title, 'artist' => $r->song->artist] : null,
                'created_at' => $r->created_at->toISOString(),
            ]);

        return response()->json([
            'success' => true,
            'dashboard' => [
                'stats' => [
                    'totalUsers' => User::count(),
                    'totalSongs' => Song::count(),
                    'totalRequests' => SongRequest::count(),
                    'pendingSubmissions' => SongSubmission::where('status', 'pending')->count(),
                    'pendingRequests' => SongRequest::where('status', 'pending')->count(),
                    'todayRequests' => SongRequest::whereDate('created_at', today())->count(),
                    'activeUsers' => User::where('last_active_at', '>=', now()->subMinutes(30))->count(),
                    'currentListeners' => User::where('last_active_at', '>=', now()->subMinutes(5))->count(),
                    'nowPlaying' => $nowPlaying,
                    'conversionPending' => Song::where('conversion_status', 'pending')->count(),
                    'conversionFailed' => Song::where('conversion_status', 'failed')->count(),
                ],
                'recentSubmissions' => $recentSubmissions,
                'recentRequests' => $recentRequests,
            ],
        ]);
    }

    // ========== SUBMISSIONS (link jóváhagyás) ==========
    public function submissions(Request $request)
    {
        $status = $request->query('status', 'pending');

        $query = SongSubmission::with('user');
        if ($status !== 'all') {
            $query->where('status', $status);
        }

        $submissions = $query->orderByDesc('created_at')->get();

        return response()->json([
            'success' => true,
            'submissions' => $submissions->map(fn($s) => [
                'id' => $s->id,
                'url' => $s->url,
                'title' => $s->title,
                'artist' => $s->artist,
                'message' => $s->message,
                'sourceType' => $s->source_type,
                'status' => $s->status,
                'adminNote' => $s->admin_note,
                'submittedBy' => $s->user->name,
                'submittedByEmail' => $s->user->email,
                'createdAt' => $s->created_at->toISOString(),
                'reviewedAt' => $s->reviewed_at?->toISOString(),
            ]),
        ]);
    }

    public function approveSubmission(Request $request, SongSubmission $submission)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'artist' => 'nullable|string|max:255',
            'album' => 'nullable|string|max:255',
            'genre' => 'nullable|string|max:100',
            'duration' => 'nullable|integer|min:1',
            'admin_note' => 'nullable|string|max:1000',
        ]);

        // Use submission data as defaults
        $title = $request->title ?: $submission->title ?: 'Ismeretlen cím';
        $artist = $request->artist ?: $submission->artist ?: 'Ismeretlen előadó';
        $duration = $request->duration ?: 200;

        // Create the song in the library
        $song = Song::create([
            'title' => $title,
            'artist' => $artist,
            'album' => $request->album,
            'genre' => $request->genre,
            'duration' => $duration,
            'source_url' => $submission->url,
            'source_type' => $submission->source_type,
            'uploaded_by' => $submission->user_id,
            'is_available' => true,
        ]);

        // Update submission status
        $submission->update([
            'status' => 'approved',
            'admin_note' => $request->admin_note,
            'reviewed_by' => $request->user()->id,
            'reviewed_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Zene jóváhagyva és hozzáadva a könyvtárhoz!',
            'song' => [
                'id' => $song->id,
                'title' => $song->title,
                'artist' => $song->artist,
            ],
        ]);
    }

    public function rejectSubmission(Request $request, SongSubmission $submission)
    {
        $request->validate([
            'admin_note' => 'nullable|string|max:1000',
        ]);

        $submission->update([
            'status' => 'rejected',
            'admin_note' => $request->admin_note ?? 'Nem megfelel az irányelveknek.',
            'reviewed_by' => $request->user()->id,
            'reviewed_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Beküldés elutasítva.',
        ]);
    }

    // ========== SONG REQUESTS (kérések jóváhagyása) ==========
    public function songRequests(Request $request)
    {
        $status = $request->query('status', 'pending');

        $query = SongRequest::with(['song', 'user']);
        if ($status !== 'all') {
            $query->where('status', $status);
        }

        // Az approved kéréseket play_order szerint rendezzük, a többit idő szerint
        if ($status === 'approved') {
            $query->orderByRaw('play_order IS NULL, play_order ASC')->orderBy('created_at', 'asc');
        } else {
            $query->orderByDesc('created_at');
        }

        $requests = $query->get();

        return response()->json([
            'success' => true,
            'requests' => $requests->map(fn($r) => [
                'id' => $r->id,
                'status' => $r->status,
                'playOrder' => $r->play_order,
                'scheduledTime' => $r->scheduled_time,
                'scheduledDate' => $r->scheduled_date?->toDateString(),
                'message' => $r->message,
                'adminNote' => $r->admin_note,
                'createdAt' => $r->created_at->toISOString(),
                'startedAt' => $r->started_at?->toISOString(),
                'song' => $r->song ? [
                    'id' => $r->song->id,
                    'title' => $r->song->title,
                    'artist' => $r->song->artist,
                    'duration' => $r->song->duration,
                    'mp3Url' => $r->song->mp3_path ? asset("storage/{$r->song->mp3_path}") : null,
                    'conversionStatus' => $r->song->conversion_status,
                ] : null,
                'user' => [
                    'id' => $r->user->id,
                    'name' => $r->user->name,
                    'class' => $r->user->class_group,
                ],
            ]),
        ]);
    }

    public function approveRequest(Request $request, SongRequest $songRequest)
    {
        $request->validate([
            'scheduled_time' => 'nullable|string',
            'admin_note' => 'nullable|string|max:1000',
        ]);

        // Auto-assign next play_order
        $maxOrder = SongRequest::where('status', 'approved')
            ->whereDate('scheduled_date', today())
            ->max('play_order') ?? 0;

        $songRequest->update([
            'status' => 'approved',
            'play_order' => $maxOrder + 1,
            'scheduled_time' => $request->scheduled_time ?? now()->format('H:i'),
            'scheduled_date' => $songRequest->scheduled_date ?? today(),
            'admin_note' => $request->admin_note,
            'reviewed_by' => $request->user()->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Kérés jóváhagyva!',
        ]);
    }

    public function rejectRequest(Request $request, SongRequest $songRequest)
    {
        $request->validate([
            'admin_note' => 'nullable|string|max:1000',
        ]);

        $songRequest->update([
            'status' => 'rejected',
            'admin_note' => $request->admin_note ?? 'Elutasítva.',
            'reviewed_by' => $request->user()->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Kérés elutasítva.',
        ]);
    }

    public function setPlaying(Request $request, SongRequest $songRequest)
    {
        // Set all other "playing" to "completed"
        SongRequest::where('status', 'playing')->update([
            'status' => 'completed',
            'played_at' => now(),
        ]);

        $songRequest->update([
            'status' => 'playing',
            'started_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Most játszik: ' . $songRequest->song->title,
        ]);
    }

    public function setCompleted(Request $request, SongRequest $songRequest)
    {
        $songRequest->update([
            'status' => 'completed',
            'played_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Lejátszás befejezve.',
        ]);
    }

    /**
     * Kérés sorrendjének módosítása (fel/le mozgatás)
     */
    public function reorderRequest(Request $request, SongRequest $songRequest)
    {
        $request->validate([
            'direction' => 'required|in:up,down',
        ], [
            'direction.required' => 'Add meg az irányt!',
            'direction.in' => 'Csak fel vagy le irány lehetséges!',
        ]);

        $direction = $request->direction;
        $currentOrder = $songRequest->play_order;

        if ($currentOrder === null) {
            return response()->json(['success' => false, 'message' => 'A kérés nincs a sorrendben.'], 400);
        }

        // Find the adjacent request
        if ($direction === 'up') {
            $swapWith = SongRequest::where('status', 'approved')
                ->whereDate('scheduled_date', $songRequest->scheduled_date)
                ->where('play_order', '<', $currentOrder)
                ->orderByDesc('play_order')
                ->first();
        } else {
            $swapWith = SongRequest::where('status', 'approved')
                ->whereDate('scheduled_date', $songRequest->scheduled_date)
                ->where('play_order', '>', $currentOrder)
                ->orderBy('play_order')
                ->first();
        }

        if (!$swapWith) {
            return response()->json(['success' => false, 'message' => 'Nem lehet tovább mozgatni.'], 400);
        }

        // Swap play_order values
        $swapOrder = $swapWith->play_order;
        $swapWith->update(['play_order' => $currentOrder]);
        $songRequest->update(['play_order' => $swapOrder]);

        return response()->json([
            'success' => true,
            'message' => 'Sorrend módosítva.',
        ]);
    }

    /**
     * Kérés törlése a műsorrendből
     */
    public function deleteRequest(SongRequest $songRequest)
    {
        $title = $songRequest->song?->title ?? 'Ismeretlen';
        $songRequest->delete();

        return response()->json([
            'success' => true,
            'message' => "'{$title}' törölve a műsorrendből.",
        ]);
    }

    // ========== SONGS MANAGEMENT ==========
    public function songs()
    {
        $songs = Song::with('uploader')->orderByDesc('created_at')->get();

        return response()->json([
            'success' => true,
            'songs' => $songs->map(fn($s) => [
                'id' => $s->id,
                'title' => $s->title,
                'artist' => $s->artist,
                'album' => $s->album,
                'duration' => $s->duration,
                'genre' => $s->genre,
                'sourceUrl' => $s->source_url,
                'sourceType' => $s->source_type,
                'mp3Url' => $s->mp3_path ? asset("storage/{$s->mp3_path}") : null,
                'conversionStatus' => $s->conversion_status,
                'isAvailable' => $s->is_available,
                'requestCount' => $s->request_count,
                'uploadedBy' => $s->uploader?->name,
                'createdAt' => $s->created_at->toISOString(),
            ]),
        ]);
    }

    public function createSong(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'artist' => 'required|string|max:255',
            'album' => 'nullable|string|max:255',
            'genre' => 'nullable|string|max:100',
            'duration' => 'required|integer|min:1',
            'source_url' => 'nullable|string|max:2048',
        ], [
            'title.required' => 'Add meg a zene címét!',
            'artist.required' => 'Add meg az előadó nevét!',
            'duration.required' => 'Add meg a zene hosszát!',
            'duration.integer' => 'A zene hosszának egész számnak kell lennie!',
            'duration.min' => 'A zene hossza legalább 1 másodperc legyen!',
        ]);

        $song = Song::create([
            'title' => $request->title,
            'artist' => $request->artist,
            'album' => $request->album,
            'genre' => $request->genre,
            'duration' => $request->duration,
            'source_url' => $request->source_url,
            'source_type' => $this->detectSourceType($request->source_url),
            'uploaded_by' => $request->user()->id,
            'is_available' => true,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Zene hozzáadva a könyvtárhoz!',
            'song' => $song,
        ], 201);
    }

    public function updateSong(Request $request, Song $song)
    {
        $request->validate([
            'title' => 'sometimes|string|max:255',
            'artist' => 'sometimes|string|max:255',
            'album' => 'nullable|string|max:255',
            'genre' => 'nullable|string|max:100',
            'duration' => 'sometimes|integer|min:1',
            'is_available' => 'sometimes|boolean',
            'isAvailable' => 'sometimes|boolean',
        ], [
            'duration.integer' => 'A zene hosszának egész számnak kell lennie!',
            'duration.min' => 'A zene hossza legalább 1 másodperc legyen!',
        ]);

        $data = $request->only(['title', 'artist', 'album', 'genre', 'duration', 'is_available']);

        // Handle camelCase from frontend
        if ($request->has('isAvailable') && !$request->has('is_available')) {
            $data['is_available'] = $request->isAvailable;
        }

        $song->update($data);

        return response()->json([
            'success' => true,
            'message' => 'Zene frissítve!',
            'song' => $song,
        ]);
    }

    public function deleteSong(Song $song)
    {
        $song->delete();

        return response()->json([
            'success' => true,
            'message' => 'Zene törölve!',
        ]);
    }

    // ========== USERS MANAGEMENT ==========
    public function users()
    {
        $users = User::orderByDesc('created_at')->get();

        return response()->json([
            'success' => true,
            'users' => $users->map(fn($u) => [
                'id' => $u->id,
                'name' => $u->name,
                'email' => $u->email,
                'educationalId' => $u->educational_id,
                'class' => $u->class_group,
                'role' => $u->role,
                'lastActiveAt' => $u->last_active_at?->toISOString(),
                'createdAt' => $u->created_at->toISOString(),
                'requestCount' => $u->songRequests()->count(),
            ]),
        ]);
    }

    public function updateUserRole(Request $request, User $user)
    {
        $request->validate([
            'role' => 'required|in:student,teacher,admin',
        ], [
            'role.required' => 'Add meg a szerepkört!',
            'role.in' => 'Érvénytelen szerepkör! Csak diák, tanár vagy admin lehet.',
        ]);

        $user->update(['role' => $request->role]);

        return response()->json([
            'success' => true,
            'message' => 'Felhasználó szerepköre frissítve!',
        ]);
    }

    private function detectSourceType(?string $url): string
    {
        if (!$url) return 'other';
        $url = strtolower($url);
        
        $platforms = [
            'youtube_music' => ['music.youtube.com'],
            'youtube'       => ['youtube.com/watch', 'youtu.be/', 'youtube.com/shorts/'],
            'spotify'       => ['open.spotify.com/track', 'open.spotify.com/album', 'spotify.com/track'],
            'soundcloud'    => ['soundcloud.com/'],
            'apple_music'   => ['music.apple.com/'],
            'deezer'        => ['deezer.com/track', 'deezer.com/album', 'deezer.page.link'],
            'tidal'         => ['tidal.com/track', 'tidal.com/browse/track', 'listen.tidal.com'],
            'bandcamp'      => ['bandcamp.com/track', 'bandcamp.com/album'],
        ];

        foreach ($platforms as $type => $patterns) {
            foreach ($patterns as $pattern) {
                if (str_contains($url, $pattern)) {
                    return $type;
                }
            }
        }
        return 'other';
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SongRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'song_id',
        'user_id',
        'scheduled_time',
        'scheduled_date',
        'status',
        'play_order',
        'message',
        'admin_note',
        'reviewed_by',
        'played_at',
        'started_at',
    ];

    protected function casts(): array
    {
        return [
            'scheduled_date' => 'date',
            'played_at' => 'datetime',
            'started_at' => 'datetime',
        ];
    }

    public function song()
    {
        return $this->belongsTo(Song::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Song extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'artist',
        'album',
        'duration',
        'genre',
        'cover_url',
        'source_url',
        'source_type',
        'mp3_path',
        'conversion_status',
        'is_available',
        'request_count',
        'uploaded_by',
    ];

    protected function casts(): array
    {
        return [
            'is_available' => 'boolean',
            'duration' => 'integer',
            'request_count' => 'integer',
        ];
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function favoritedBy()
    {
        return $this->belongsToMany(User::class, 'favorites')->withTimestamps();
    }

    public function requests()
    {
        return $this->hasMany(SongRequest::class);
    }
}

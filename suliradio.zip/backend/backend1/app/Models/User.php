<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;

    protected $fillable = [
        'name',
        'email',
        'password',
        'educational_id',
        'class_group',
        'role',
        'avatar',
        'last_active_at',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'last_active_at' => 'datetime',
        ];
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function favorites()
    {
        return $this->belongsToMany(Song::class, 'favorites')->withTimestamps();
    }

    public function songRequests()
    {
        return $this->hasMany(SongRequest::class);
    }

    public function songSubmissions()
    {
        return $this->hasMany(SongSubmission::class);
    }

    public function uploadedSongs()
    {
        return $this->hasMany(Song::class, 'uploaded_by');
    }
}

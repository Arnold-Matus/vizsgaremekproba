<?php

namespace App\Http\Controllers;

use App\Models\Song;
use App\Models\User;
use App\Models\SongRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SongController extends Controller
{
    public function index(Request $request)
    {
        $query = Song::where('is_available', true);

        // Search
        if ($search = $request->query('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('artist', 'like', "%{$search}%")
                  ->orWhere('album', 'like', "%{$search}%")
                  ->orWhere('genre', 'like', "%{$search}%");
            });
        }

        // Genre filter
        if ($genre = $request->query('genre')) {
            if ($genre !== 'all') {
                $query->where('genre', $genre);
            }
        }

        // Sort
        $sortBy = $request->query('sort_by', 'title');
        $sortOrder = $request->query('sort_order', 'asc');
        $allowedSorts = ['title', 'artist', 'duration', 'created_at', 'request_count'];
        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, $sortOrder === 'desc' ? 'desc' : 'asc');
        }

        $songs = $query->get();

        return response()->json([
            'success' => true,
            'songs' => $songs->map(fn($song) => $this->formatSong($song)),
        ]);
    }

    public function show(Song $song)
    {
        return response()->json([
            'success' => true,
            'song' => $this->formatSong($song),
        ]);
    }

    public function genres()
    {
        $genres = Song::where('is_available', true)
            ->distinct()
            ->pluck('genre')
            ->filter()
            ->values();

        return response()->json([
            'success' => true,
            'genres' => $genres,
        ]);
    }

    public function stats()
    {
        $totalSongs = Song::where('is_available', true)->count();
        $todayRequests = SongRequest::whereDate('created_at', today())->count();
        $activeUsers = User::where('last_active_at', '>=', now()->subMinutes(30))->count();
        $currentListeners = User::where('last_active_at', '>=', now()->subMinutes(5))->count();
        $currentlyPlaying = SongRequest::with('song', 'user')
            ->where('status', 'playing')
            ->first();

        return response()->json([
            'success' => true,
            'stats' => [
                'totalSongs' => $totalSongs,
                'todayRequests' => $todayRequests,
                'activeUsers' => $activeUsers,
                'currentListeners' => max($currentListeners, 1),
                'currentlyPlaying' => $currentlyPlaying ? [
                    'song' => $this->formatSong($currentlyPlaying->song),
                    'requestedBy' => $currentlyPlaying->user->name,
                    'time' => $currentlyPlaying->scheduled_time,
                    'startedAt' => ($currentlyPlaying->started_at ?? $currentlyPlaying->updated_at)->toISOString(),
                ] : null,
            ],
        ]);
    }

    private function formatSong(Song $song): array
    {
        return [
            'id' => $song->id,
            'title' => $song->title,
            'artist' => $song->artist,
            'album' => $song->album,
            'duration' => $song->duration,
            'genre' => $song->genre,
            'coverUrl' => $song->cover_url,
            'sourceUrl' => $song->source_url,
            'sourceType' => $song->source_type,
            'mp3Url' => $song->mp3_path ? asset("storage/{$song->mp3_path}") : null,
            'conversionStatus' => $song->conversion_status,
            'uploadDate' => $song->created_at->toISOString(),
            'requestCount' => $song->request_count,
            'isAvailable' => $song->is_available,
        ];
    }

    /**
     * MP3 fájl streamingelése.
     */
    public function stream(Song $song)
    {
        if (!$song->mp3_path || $song->conversion_status !== 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Ez a zene még nincs konvertálva MP3 formátumba.',
            ], 404);
        }

        $filePath = Storage::disk('public')->path($song->mp3_path);

        if (!file_exists($filePath)) {
            return response()->json([
                'success' => false,
                'message' => 'Az MP3 fájl nem található.',
            ], 404);
        }

        return response()->file($filePath, [
            'Content-Type' => 'audio/mpeg',
            'Accept-Ranges' => 'bytes',
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\SongSubmission;
use Illuminate\Http\Request;

class SongSubmissionController extends Controller
{
    /**
     * Támogatott zeneplatformok URL mintái
     */
    private const SUPPORTED_PLATFORMS = [
        'youtube'       => ['youtube.com/watch', 'youtu.be/', 'youtube.com/shorts/'],
        'youtube_music' => ['music.youtube.com'],
        'spotify'       => ['open.spotify.com/track', 'open.spotify.com/album', 'spotify.com/track'],
        'soundcloud'    => ['soundcloud.com/'],
        'apple_music'   => ['music.apple.com/'],
        'deezer'        => ['deezer.com/track', 'deezer.com/album', 'deezer.page.link'],
        'tidal'         => ['tidal.com/track', 'tidal.com/browse/track', 'listen.tidal.com'],
        'bandcamp'      => ['bandcamp.com/track', 'bandcamp.com/album'],
    ];

    /**
     * URL alapján felismeri a forrás típusát
     */
    private function detectSourceType(string $url): string
    {
        $url = strtolower($url);
        foreach (self::SUPPORTED_PLATFORMS as $type => $patterns) {
            foreach ($patterns as $pattern) {
                if (str_contains($url, $pattern)) {
                    return $type;
                }
            }
        }
        return 'other';
    }

    /**
     * Ellenőrzi, hogy az URL egy támogatott zeneplatformról származik-e
     */
    private function isSupportedMusicUrl(string $url): bool
    {
        $url = strtolower($url);
        foreach (self::SUPPORTED_PLATFORMS as $patterns) {
            foreach ($patterns as $pattern) {
                if (str_contains($url, $pattern)) {
                    return true;
                }
            }
        }
        return false;
    }

    public function store(Request $request)
    {
        $request->validate([
            'url' => 'required|url',
            'title' => 'nullable|string|max:255',
            'artist' => 'nullable|string|max:255',
            'message' => 'nullable|string|max:1000',
        ], [
            'url.required' => 'Add meg a zene linkjét!',
            'url.url' => 'Érvénytelen URL cím!',
        ]);

        $url = $request->url;

        // Ellenőrizzük, hogy támogatott platformról származik-e
        if (!$this->isSupportedMusicUrl($url)) {
            return response()->json([
                'success' => false,
                'message' => 'Csak támogatott zeneplatformok linkjeit fogadjuk el!',
                'errors' => ['url' => ['Támogatott platformok: YouTube, YouTube Music, Spotify, SoundCloud, Apple Music, Deezer, Tidal, Bandcamp']],
            ], 422);
        }

        $sourceType = $this->detectSourceType($url);

        $submission = SongSubmission::create([
            'user_id' => $request->user()->id,
            'url' => $url,
            'title' => $request->title,
            'artist' => $request->artist,
            'message' => $request->message,
            'source_type' => $sourceType,
            'status' => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Zenekérésed sikeresen elküldve! A moderátorok hamarosan átnézik.',
            'submission' => [
                'id' => $submission->id,
                'url' => $submission->url,
                'title' => $submission->title,
                'artist' => $submission->artist,
                'sourceType' => $submission->source_type,
                'status' => $submission->status,
                'createdAt' => $submission->created_at->toISOString(),
            ],
        ]);
    }

    public function mySubmissions(Request $request)
    {
        $submissions = SongSubmission::where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'success' => true,
            'submissions' => $submissions->map(fn($s) => [
                'id' => $s->id,
                'url' => $s->url,
                'title' => $s->title,
                'artist' => $s->artist,
                'sourceType' => $s->source_type,
                'status' => $s->status,
                'adminNote' => $s->admin_note,
                'createdAt' => $s->created_at->toISOString(),
            ]),
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Song;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/**
 * API a C# asztali konvertáló alkalmazás számára.
 * 
 * A C# app:
 * 1. Lekéri a konvertálandó zenéket (GET /api/converter/pending)
 * 2. Letölti a source_url-ről a zenét
 * 3. Konvertálja MP3-má
 * 4. Feltölti a szerverre (POST /api/converter/upload/{song})
 * 5. Hibát jelez ha nem sikerült (POST /api/converter/fail/{song})
 */
class ConversionController extends Controller
{
    /**
     * Konvertálásra váró zenék lekérése.
     * A C# app ezt hívja hogy megkapja a feladatokat.
     */
    public function pending()
    {
        $songs = Song::where('conversion_status', 'pending')
            ->whereNotNull('source_url')
            ->orderBy('created_at', 'asc')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'songs' => $songs->map(fn($s) => [
                'id' => $s->id,
                'title' => $s->title,
                'artist' => $s->artist,
                'sourceUrl' => $s->source_url,
                'sourceType' => $s->source_type,
                'createdAt' => $s->created_at->toISOString(),
            ]),
        ]);
    }

    /**
     * Konvertálás megkezdésének jelzése.
     * A C# app ezt hívja amikor elkezdi a konvertálást.
     */
    public function startProcessing(Song $song)
    {
        $song->update(['conversion_status' => 'processing']);

        return response()->json([
            'success' => true,
            'message' => "Konvertálás elkezdve: {$song->title}",
        ]);
    }

    /**
     * MP3 fájl feltöltése a C# alkalmazásból.
     * A konvertálás után a C# app ide küldi az MP3-at.
     */
    public function upload(Request $request, Song $song)
    {
        $request->validate([
            'mp3' => 'required|file|mimes:mp3,mpeg|max:51200', // max 50MB
            'duration' => 'nullable|integer|min:1',
        ]);

        $file = $request->file('mp3');

        // Fájlnév generálása: song_id_artist_title.mp3
        $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '_', "{$song->id}_{$song->artist}_{$song->title}");
        $safeName = substr($safeName, 0, 100) . '.mp3';

        // Mentés a storage/app/public/songs mappába
        $path = $file->storeAs('songs', $safeName, 'public');

        $updateData = [
            'mp3_path' => $path,
            'conversion_status' => 'completed',
        ];

        // Ha a C# app megadta a pontos időtartamot, frissítjük
        if ($request->duration) {
            $updateData['duration'] = $request->duration;
        }

        $song->update($updateData);

        return response()->json([
            'success' => true,
            'message' => "MP3 sikeresen feltöltve: {$song->title}",
            'mp3Url' => asset("storage/{$path}"),
        ]);
    }

    /**
     * Konvertálási hiba jelzése.
     */
    public function fail(Request $request, Song $song)
    {
        $request->validate([
            'error' => 'nullable|string|max:1000',
        ]);

        $song->update(['conversion_status' => 'failed']);

        return response()->json([
            'success' => true,
            'message' => "Konvertálás sikertelen: {$song->title}",
        ]);
    }

    /**
     * Konvertálás újraindítása (admin).
     */
    public function retry(Song $song)
    {
        $song->update(['conversion_status' => 'pending']);

        return response()->json([
            'success' => true,
            'message' => "Újrakonvertálás kérve: {$song->title}",
        ]);
    }

    /**
     * Összes konvertálás státusza (admin dashboard).
     */
    public function status()
    {
        return response()->json([
            'success' => true,
            'stats' => [
                'pending' => Song::where('conversion_status', 'pending')->count(),
                'processing' => Song::where('conversion_status', 'processing')->count(),
                'completed' => Song::where('conversion_status', 'completed')->count(),
                'failed' => Song::where('conversion_status', 'failed')->count(),
            ],
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'educational_id' => 'required|string|size:11|unique:users',
            'class_group' => 'required|string|max:20',
        ], [
            'name.required' => 'Add meg a neved!',
            'email.required' => 'Add meg az email címed!',
            'email.email' => 'Érvénytelen email cím!',
            'email.unique' => 'Ez az email cím már regisztrálva van!',
            'password.required' => 'Add meg a jelszavad!',
            'password.min' => 'A jelszónak legalább 8 karakter hosszúnak kell lennie!',
            'educational_id.required' => 'Add meg az oktatási azonosítód!',
            'educational_id.size' => 'Az oktatási azonosítónak pontosan 11 karakter hosszúnak kell lennie!',
            'educational_id.unique' => 'Ez az oktatási azonosító már regisztrálva van!',
            'class_group.required' => 'Add meg az osztályod!',
        ]);

        // Admin emails list - these get admin role on registration
        $adminEmails = ['admin@bszc.hu', 'sutozsolt13@gmail.com'];

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password,
            'educational_id' => $request->educational_id,
            'class_group' => $request->class_group,
            'role' => in_array($request->email, $adminEmails) ? 'admin' : 'student',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Sikeres regisztráció!',
            'user' => $this->formatUser($user),
        ], 201);
    }

    public function login(Request $request)
    {
        $request->validate([
            'identifier' => 'required|string',
            'password' => 'required|string',
        ]);

        $identifier = $request->identifier;

        // Find user by email, educational_id, or name
        $user = User::where('email', $identifier)
            ->orWhere('educational_id', $identifier)
            ->orWhere('name', $identifier)
            ->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                'success' => false,
                'error' => 'Hibás bejelentkezési adatok!',
            ], 401);
        }

        // Update last active
        $user->update(['last_active_at' => now()]);

        // Create token
        $token = $user->createToken('suliradio-token')->plainTextToken;

        return response()->json([
            'success' => true,
            'user' => $this->formatUser($user),
            'token' => $token,
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Sikeres kijelentkezés!',
        ]);
    }

    public function me(Request $request)
    {
        $user = $request->user();
        $user->update(['last_active_at' => now()]);

        return response()->json([
            'success' => true,
            'user' => $this->formatUser($user),
        ]);
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $user->id,
            'class_group' => 'sometimes|string|max:20',
        ]);

        $user->update($request->only(['name', 'email', 'class_group']));

        return response()->json([
            'success' => true,
            'user' => $this->formatUser($user->fresh()),
        ]);
    }

    private function formatUser(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'educationalId' => $user->educational_id,
            'class' => $user->class_group,
            'role' => $user->role,
            'avatar' => $user->avatar,
            'favorites' => $user->favorites()->pluck('songs.id')->toArray(),
            'createdAt' => $user->created_at->toISOString(),
        ];
    }
}

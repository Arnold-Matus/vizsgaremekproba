<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $favorites = $user->favorites()->get();

        return response()->json([
            'success' => true,
            'favorites' => $favorites->map(fn($song) => [
                'id' => $song->id,
                'title' => $song->title,
                'artist' => $song->artist,
                'album' => $song->album,
                'duration' => $song->duration,
                'genre' => $song->genre,
                'coverUrl' => $song->cover_url,
                'requestCount' => $song->request_count,
                'uploadDate' => $song->created_at->toISOString(),
            ]),
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'song_id' => 'required|exists:songs,id',
        ]);

        $user = $request->user();
        
        if (!$user->favorites()->where('song_id', $request->song_id)->exists()) {
            $user->favorites()->attach($request->song_id);
        }

        return response()->json([
            'success' => true,
            'message' => 'Hozzáadva a kedvencekhez!',
            'favorites' => $user->favorites()->pluck('songs.id')->toArray(),
        ]);
    }

    public function destroy(Request $request, int $songId)
    {
        $user = $request->user();
        $user->favorites()->detach($songId);

        return response()->json([
            'success' => true,
            'message' => 'Eltávolítva a kedvencekből!',
            'favorites' => $user->favorites()->pluck('songs.id')->toArray(),
        ]);
    }
}

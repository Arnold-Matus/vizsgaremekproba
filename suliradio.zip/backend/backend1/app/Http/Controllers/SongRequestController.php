<?php

namespace App\Http\Controllers;

use App\Models\SongRequest;
use App\Models\Song;
use Illuminate\Http\Request;

class SongRequestController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'song_ids' => 'required|array|min:1',
            'song_ids.*' => 'exists:songs,id',
            'message' => 'nullable|string|max:500',
        ]);

        $user = $request->user();

        // Napi limit ellenőrzés: max 3 kérés naponta
        $todayCount = SongRequest::where('user_id', $user->id)
            ->whereDate('created_at', today())
            ->count();

        $maxDaily = 3;
        $remaining = $maxDaily - $todayCount;

        if ($remaining <= 0) {
            return response()->json([
                'success' => false,
                'message' => "Elérted a napi limitet ($maxDaily zene/nap). Holnap újra kérhetsz!",
            ], 422);
        }

        if (count($request->song_ids) > $remaining) {
            return response()->json([
                'success' => false,
                'message' => "Ma már csak $remaining zenét kérhetsz (napi limit: $maxDaily).",
            ], 422);
        }

        // Legutolsó kérés ellenőrzés: nem kérheti ugyanazt egymás után
        $lastRequest = SongRequest::where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->first();

        $requests = [];
        $skipped = [];

        foreach ($request->song_ids as $songId) {
            // Ugyanazt a zenét nem kérheti kétszer egy nap
            $existingToday = SongRequest::where('user_id', $user->id)
                ->where('song_id', $songId)
                ->whereDate('created_at', today())
                ->first();

            if ($existingToday) {
                $song = Song::find($songId);
                $skipped[] = $song ? $song->title : "#{$songId}";
                continue;
            }

            // Nem kérheti ugyanazt a zenét egymás után (legutolsó kérés)
            if ($lastRequest && $lastRequest->song_id == $songId && count($request->song_ids) === 1) {
                $song = Song::find($songId);
                return response()->json([
                    'success' => false,
                    'message' => 'Nem kérheted ugyanazt a zenét egymás után! (' . ($song ? $song->title : '') . ')',
                ], 422);
            }

            $songRequest = SongRequest::create([
                'song_id' => $songId,
                'user_id' => $user->id,
                'scheduled_date' => today(),
                'status' => 'pending',
                'message' => $request->message,
            ]);

            // Increment request count
            Song::where('id', $songId)->increment('request_count');

            $requests[] = $songRequest;

            // Frissítjük a lastRequest-et az újonnan létrehozott kéréssel
            $lastRequest = $songRequest;
        }

        $msg = count($requests) . ' zene sikeresen kérve!';
        if (count($skipped) > 0) {
            $msg .= ' (Kihagyva, mert ma már kérted: ' . implode(', ', $skipped) . ')';
        }

        return response()->json([
            'success' => true,
            'message' => $msg,
            'requests' => collect($requests)->map(fn($r) => $this->formatRequest($r)),
            'dailyRemaining' => $maxDaily - $todayCount - count($requests),
        ]);
    }

    public function schedule(Request $request)
    {
        $date = $request->query('date', today()->toDateString());

        $schedule = SongRequest::with(['song', 'user'])
            ->whereDate('scheduled_date', $date)
            ->whereIn('status', ['pending', 'approved', 'playing', 'completed'])
            ->orderByRaw("FIELD(status, 'playing', 'approved', 'pending', 'completed')")
            ->orderByRaw('play_order IS NULL, play_order ASC')
            ->orderBy('scheduled_time', 'asc')
            ->orderBy('created_at', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'schedule' => $schedule->map(fn($item) => [
                'id' => $item->id,
                'songId' => $item->song_id,
                'time' => $item->scheduled_time ?? $item->created_at->format('H:i'),
                'status' => $item->status,
                'playOrder' => $item->play_order,
                'requestedBy' => $item->user->name,
                'song' => $item->song ? [
                    'id' => $item->song->id,
                    'title' => $item->song->title,
                    'artist' => $item->song->artist,
                    'album' => $item->song->album,
                    'duration' => $item->song->duration,
                    'genre' => $item->song->genre,
                    'coverUrl' => $item->song->cover_url,
                ] : null,
            ]),
        ]);
    }

    public function history(Request $request)
    {
        $user = $request->user();

        $history = SongRequest::with('song')
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->limit(50)
            ->get();

        return response()->json([
            'success' => true,
            'history' => $history->map(fn($item) => [
                'id' => $item->id,
                'songId' => $item->song_id,
                'requestedAt' => $item->created_at->toISOString(),
                'status' => $item->status === 'completed' ? 'played' : $item->status,
                'song' => $item->song ? [
                    'id' => $item->song->id,
                    'title' => $item->song->title,
                    'artist' => $item->song->artist,
                    'duration' => $item->song->duration,
                    'genre' => $item->song->genre,
                ] : null,
            ]),
        ]);
    }

    private function formatRequest($request): array
    {
        return [
            'id' => $request->id,
            'songId' => $request->song_id,
            'status' => $request->status,
            'scheduledTime' => $request->scheduled_time,
            'scheduledDate' => $request->scheduled_date?->toDateString(),
            'createdAt' => $request->created_at->toISOString(),
        ];
    }

    /**
     * Visszaadja a napi kérés állapotot: hány kérés maradt, mely zenéket kérte már ma
     */
    public function dailyStatus(Request $request)
    {
        $user = $request->user();
        $maxDaily = 3;

        $todayRequests = SongRequest::where('user_id', $user->id)
            ->whereDate('created_at', today())
            ->get();

        $lastRequest = SongRequest::where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->first();

        return response()->json([
            'success' => true,
            'maxDaily' => $maxDaily,
            'usedToday' => $todayRequests->count(),
            'remaining' => max(0, $maxDaily - $todayRequests->count()),
            'requestedSongIds' => $todayRequests->pluck('song_id')->unique()->values(),
            'lastRequestedSongId' => $lastRequest?->song_id,
        ]);
    }
}

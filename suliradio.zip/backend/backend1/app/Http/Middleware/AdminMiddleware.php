<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (!$request->user() || !$request->user()->isAdmin()) {
            return response()->json([
                'success' => false,
                'error' => 'Nincs jogosultságod ehhez a művelethez!',
            ], 403);
        }

        return $next($request);
    }
}

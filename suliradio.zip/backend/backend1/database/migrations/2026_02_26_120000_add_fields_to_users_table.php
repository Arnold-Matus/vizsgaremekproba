<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('educational_id', 11)->unique()->nullable()->after('email');
            $table->string('class_group', 20)->nullable()->after('educational_id');
            $table->enum('role', ['student', 'teacher', 'admin'])->default('student')->after('class_group');
            $table->string('avatar')->nullable()->after('role');
            $table->timestamp('last_active_at')->nullable()->after('avatar');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['educational_id', 'class_group', 'role', 'avatar', 'last_active_at']);
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('songs', function (Blueprint $table) {
            $table->string('mp3_path')->nullable()->after('source_type');
            $table->enum('conversion_status', ['pending', 'processing', 'completed', 'failed'])
                  ->default('pending')
                  ->after('mp3_path');
        });
    }

    public function down(): void
    {
        Schema::table('songs', function (Blueprint $table) {
            $table->dropColumn(['mp3_path', 'conversion_status']);
        });
    }
};

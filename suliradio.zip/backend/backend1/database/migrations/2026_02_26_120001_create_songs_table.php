<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('songs', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('artist');
            $table->string('album')->nullable();
            $table->integer('duration')->default(0); // in seconds
            $table->string('genre')->nullable();
            $table->string('cover_url')->nullable();
            $table->string('source_url')->nullable(); // YouTube/Spotify link
            $table->enum('source_type', ['youtube', 'youtube_music', 'spotify', 'soundcloud', 'apple_music', 'deezer', 'tidal', 'bandcamp', 'upload', 'other'])->default('other');
            $table->boolean('is_available')->default(true);
            $table->integer('request_count')->default(0);
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('songs');
    }
};

<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin',
            'email' => 'admin@bszc.hu',
            'password' => 'Admin1234',
            'educational_id' => '00000000001',
            'class_group' => 'Admin',
            'role' => 'admin',
        ]);

        // Create demo student
        User::create([
            'name' => 'Demo Diák',
            'email' => 'demo@bszc.hu',
            'password' => 'Demo1234',
            'educational_id' => '72345678901',
            'class_group' => '13.E',
            'role' => 'student',
        ]);

        // A zenék a felhasználók által beküldött linkekből kerülnek be
        // admin jóváhagyás után - nincs szükség mintaadatokra
    }
}

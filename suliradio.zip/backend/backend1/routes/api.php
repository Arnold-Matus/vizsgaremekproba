<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SongController;
use App\Http\Controllers\SongRequestController;
use App\Http\Controllers\SongSubmissionController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ConversionController;

// ========== PUBLIC ROUTES ==========
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Public song browsing
Route::get('/songs', [SongController::class, 'index']);
Route::get('/songs/genres', [SongController::class, 'genres']);
Route::get('/songs/{song}', [SongController::class, 'show']);
Route::get('/songs/{song}/stream', [SongController::class, 'stream']);
Route::get('/stats', [SongController::class, 'stats']);
Route::get('/schedule', [SongRequestController::class, 'schedule']);

// ========== CONVERTER API (C# asztali alkalmazás számára) ==========
Route::prefix('converter')->group(function () {
    Route::get('/pending', [ConversionController::class, 'pending']);
    Route::post('/{song}/processing', [ConversionController::class, 'startProcessing']);
    Route::post('/{song}/upload', [ConversionController::class, 'upload']);
    Route::post('/{song}/fail', [ConversionController::class, 'fail']);
    Route::get('/status', [ConversionController::class, 'status']);
});

// ========== AUTHENTICATED ROUTES ==========
Route::middleware('auth:sanctum')->group(function () {
    // Auth
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    Route::put('/profile', [AuthController::class, 'updateProfile']);

    // Song requests
    Route::post('/requests', [SongRequestController::class, 'store']);
    Route::get('/requests/history', [SongRequestController::class, 'history']);
    Route::get('/requests/daily-status', [SongRequestController::class, 'dailyStatus']);

    // Song submissions (link beküldés)
    Route::post('/submissions', [SongSubmissionController::class, 'store']);
    Route::get('/submissions/mine', [SongSubmissionController::class, 'mySubmissions']);

    // Favorites
    Route::get('/favorites', [FavoriteController::class, 'index']);
    Route::post('/favorites', [FavoriteController::class, 'store']);
    Route::delete('/favorites/{songId}', [FavoriteController::class, 'destroy']);

    // ========== ADMIN ROUTES ==========
    Route::middleware('admin')->prefix('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard']);

        // Submissions management
        Route::get('/submissions', [AdminController::class, 'submissions']);
        Route::post('/submissions/{submission}/approve', [AdminController::class, 'approveSubmission']);
        Route::post('/submissions/{submission}/reject', [AdminController::class, 'rejectSubmission']);

        // Song requests management
        Route::get('/requests', [AdminController::class, 'songRequests']);
        Route::post('/requests/{songRequest}/approve', [AdminController::class, 'approveRequest']);
        Route::post('/requests/{songRequest}/reject', [AdminController::class, 'rejectRequest']);
        Route::post('/requests/{songRequest}/playing', [AdminController::class, 'setPlaying']);
        Route::post('/requests/{songRequest}/completed', [AdminController::class, 'setCompleted']);
        Route::post('/requests/{songRequest}/reorder', [AdminController::class, 'reorderRequest']);
        Route::delete('/requests/{songRequest}', [AdminController::class, 'deleteRequest']);

        // Songs management
        Route::get('/songs', [AdminController::class, 'songs']);
        Route::post('/songs', [AdminController::class, 'createSong']);
        Route::put('/songs/{song}', [AdminController::class, 'updateSong']);
        Route::delete('/songs/{song}', [AdminController::class, 'deleteSong']);

        // Users management
        Route::get('/users', [AdminController::class, 'users']);
        Route::put('/users/{user}/role', [AdminController::class, 'updateUserRole']);

        // Conversion management
        Route::get('/conversion/status', [ConversionController::class, 'status']);
        Route::post('/conversion/{song}/retry', [ConversionController::class, 'retry']);
    });
});

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const targetFiles = [
  'node_modules/react-datepicker/src/stylesheets/datepicker.scss',
  'node_modules/react-datepicker/dist/react-datepicker.css',
  'node_modules/react-datepicker/dist/react-datepicker.module.css',
  'node_modules/react-datepicker/dist/react-datepicker-cssmodules.css',
  'node_modules/react-datepicker/dist/react-datepicker.min.css',
  'node_modules/react-datepicker/dist/react-datepicker-cssmodules.min.css',
  'node_modules/react-datepicker/dist/react-datepicker-min.module.css',
];

function patchContent(content) {
  let updated = content.replace(
    /^([ \t]*)-moz-appearance:\s*textfield;\r?\n([ \t]*)appearance:\s*textfield;\r?$/gm,
    (line, firstIndent, secondIndent) => `${secondIndent || firstIndent}appearance: textfield;`,
  );

  updated = updated.replace(
    /^([ \t]*)-moz-appearance:\s*textfield;\r?$/gm,
    (line, indent) => `${indent}appearance: textfield;`,
  );

  updated = updated.replace(
    /-moz-appearance:textfield;appearance:textfield/g,
    'appearance:textfield',
  );

  updated = updated.replace(
    /-moz-appearance:textfield/g,
    'appearance:textfield',
  );

  return updated;
}

let patchedCount = 0;

for (const relativePath of targetFiles) {
  const filePath = join(root, relativePath);

  if (!existsSync(filePath)) {
    continue;
  }

  const original = readFileSync(filePath, 'utf8');
  const patched = patchContent(original);

  if (patched === original) {
    continue;
  }

  writeFileSync(filePath, patched, 'utf8');
  patchedCount += 1;
}

console.log(`react-datepicker CSS patch applied to ${patchedCount} file(s).`);
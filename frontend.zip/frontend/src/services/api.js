// ============================================================
// SuliRadio – szerver kommunikáció (api.js)
// Minden fetch hívás itt van összegyűjtve.
// A backend alap URL-je:
// ============================================================
const API_URL = 'http://127.0.0.1:8000/api';

const AUTH_TOKEN_KEY = 'suliradio-token';
const AUTH_FLASH_MESSAGE_KEY = 'suliradio-auth-flash-message';
const AUTH_PENDING_LOGOUT_TOKEN_KEY = 'suliradio-pending-logout-token';

const getToken = () => sessionStorage.getItem(AUTH_TOKEN_KEY);

export const getAuthToken = () => getToken();

export const setAuthToken = (token) => {
  if (!token) return;
  sessionStorage.setItem(AUTH_TOKEN_KEY, token);
  localStorage.setItem(AUTH_PENDING_LOGOUT_TOKEN_KEY, token);
  localStorage.removeItem(AUTH_TOKEN_KEY);
};

export const clearAuthToken = () => {
  sessionStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(AUTH_PENDING_LOGOUT_TOKEN_KEY);
};

const sendLogoutRequest = (token, keepalive = false) => {
  if (!token || token === DEMO_TOKEN) {
    return Promise.resolve();
  }

  return fetch(`${API_URL}/kilepes`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      token,
    },
    keepalive,
  }).catch(() => undefined);
};

export const flushPendingLogout = async () => {
  const token = localStorage.getItem(AUTH_PENDING_LOGOUT_TOKEN_KEY);
  if (!token) return;

  localStorage.removeItem(AUTH_PENDING_LOGOUT_TOKEN_KEY);
  await sendLogoutRequest(token);
};

export const cancelPendingLogout = () => {
  localStorage.removeItem(AUTH_PENDING_LOGOUT_TOKEN_KEY);
};

export const closeAuthSessionOnPageExit = () => {
  const token = getToken();

  if (!token || token === DEMO_TOKEN) {
    return;
  }

  localStorage.setItem(AUTH_PENDING_LOGOUT_TOKEN_KEY, token);
};

export const setAuthFlashMessage = (message) => {
  if (!message) return;
  const payload = typeof message === 'string'
    ? { message, type: 'warning' }
    : { type: 'warning', ...message };
  sessionStorage.setItem(AUTH_FLASH_MESSAGE_KEY, JSON.stringify(payload));
};

export const consumeAuthFlashMessage = () => {
  const rawMessage = sessionStorage.getItem(AUTH_FLASH_MESSAGE_KEY);
  if (rawMessage) {
    sessionStorage.removeItem(AUTH_FLASH_MESSAGE_KEY);
  }

  if (!rawMessage) return null;

  try {
    const payload = JSON.parse(rawMessage);
    if (payload && typeof payload === 'object' && payload.message) {
      return payload;
    }
  } catch {
    // Legacy plain-text flash message fallback.
  }

  return { message: rawMessage, type: 'warning' };
};

// ============================================================
// HTTP hibakódok → Magyar hibaüzenetek
// ============================================================
const HTTP_HIBAK = {
  400: {
    hu: 'Hibás kérés. Kérlek ellenőrizd a megadott adatokat!',
    en: 'Bad request. Please check the submitted data.',
  },
  401: {
    hu: 'Érvénytelen bejelentkezési adatok!',
    en: 'Invalid sign-in credentials!',
  },
  403: {
    hu: 'Nincs jogosultságod ehhez a művelethez!',
    en: 'You do not have permission to perform this action!',
  },
  404: {
    hu: 'A keresett elem nem található.',
    en: 'The requested item could not be found.',
  },
  500: {
    hu: 'Szerverhiba történt. Kérlek próbáld újra később!',
    en: 'A server error occurred. Please try again later!',
  },
  502: {
    hu: 'A szerver átmenetileg nem elérhető. Kérlek próbáld újra később!',
    en: 'The server is temporarily unavailable. Please try again later!',
  },
  503: {
    hu: 'A szerver jelenleg karbantartás alatt áll.',
    en: 'The server is currently under maintenance.',
  },
};

// PHP belső hibák szűrése – ezeket ne mutassuk a felhasználónak
const TECHNIKAI_MINTA = [
  /SQLSTATE/i, /SQL.*error/i, /\.php:\d+/i, /Illuminate\\/i,
  /Symfony\\/i, /stack\s*trace/i, /vendor\//i, /PDOException/i,
];

const getHttpHibaSzoveg = (statusz) => {
  const hiba = HTTP_HIBAK[statusz];
  if (!hiba) return null;
  return lokalizaltSzoveg(hiba.hu, hiba.en);
};

const szuroHibaSzoveg = (szoveg, statusz) => {
  if (!szoveg || typeof szoveg !== 'string') {
    return getHttpHibaSzoveg(statusz) || lokalizaltSzoveg('Ismeretlen hiba történt!', 'An unknown error occurred!');
  }
  if (TECHNIKAI_MINTA.some(p => p.test(szoveg))) {
    return getHttpHibaSzoveg(statusz) || lokalizaltSzoveg('Váratlan hiba történt. Kérlek próbáld újra!', 'An unexpected error occurred. Please try again!');
  }
  return szoveg;
};

const encodeBase64Utf8 = (ertek) => Buffer.from(String(ertek ?? ''), 'utf8').toString('base64');

// ============================================================
// Alap fetch segédfüggvény
// A backend token-alapú hitelesítést használ (nem Bearer).
// A tokent "token" nevű fejlécként küldi el a szerver felé.
// ============================================================
const apiFetch = async (vegpont, opciok = {}) => {
  const token = getToken();
  const fejlecek = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(token ? { 'token': token } : {}),
    ...opciok.headers,
  };

  try {
    const valasz = await fetch(`${API_URL}${vegpont}`, {
      ...opciok,
      headers: fejlecek,
    });
    return valasz;
  } catch (hiba) {
    if (hiba.name === 'TypeError') {
      throw new Error(lokalizaltSzoveg(
        'Nem sikerült csatlakozni a szerverhez. Ellenőrizd, hogy a backend fut-e!',
        'Could not connect to the server. Check whether the backend is running!'
      ));
    }
    throw hiba;
  }
};

// ============================================================
// Adatátalakítók: backend rekord → frontend objektum
// ============================================================

// Zene rekord átalakítása (backend: zene tábla)
const zeneMapper = (z) => ({
  id: z.id,
  title: z.cim || lokalizaltSzoveg('(ismeretlen cím)', '(unknown title)'),
  artist: z.eloado || lokalizaltSzoveg('(ismeretlen előadó)', '(unknown artist)'),
  album: z.album || null,
  mp3Url: z.zeneurl || null,
  duration: z.hossz || 0,
  genre: z.tema || null,
  sourceUrl: z.keresurl || null,
  sourceType: z.forrastipus || 'other',
  requestCount: Number(z.keresszam || z.requestCount || 0),
  conversionStatus: z.konvertalasallapot || null,
  isAvailable: z.lejatszhatoe === 1 || z.lejatszhatoe === true,
  uploadDate: z.created_at || null,
});

// Felhasználó rekord átalakítása (backend: felhasznalo tábla)
const felhasznaloMapper = (f) => ({
  id: f.id,
  // A backend külön tárolja a keresztnevet és a vezetéknevet
  name: [f.vezeteknev, f.keresztnev].filter(Boolean).join(' ') || f.email,
  email: f.email || '',
  educationalId: f.omazonosito || '',
  classGroup: f.osztaly || f.osztalynev || '',
  // Jogszint: 1=demo, 2=normális, 3=tanár, 4+=admin/asztali
  role: f.jog >= 4 ? 'admin' : f.jog >= 3 ? 'tanar' : f.jog === 1 ? 'demo' : 'user',
  isAdmin: f.jog >= 4,
  isBanned: !!f.letiltott,
  emailVerified: !!f.emailverifikalva,
  jog: f.jog,
  createdAt: f.created_at || null,
});

// Órarend rekord átalakítása (backend: orarend tábla)
const orarendMapper = (o) => ({
  id: o.id,
  songId: o.zeneid,
  startTime: o.mikortol,
  endTime: o.meddig,
  song: null, // A zenét külön lekérdezés tölti be
});

// ============================================================
// Demo mód (offline, backend nélkül)
// ============================================================
const DEMO_TOKEN = 'demo-local-token';
const DEMO_FELHASZNALO = {
  id: 0,
  name: 'Demo Felhasználó',
  email: 'demo@bszc.hu',
  educationalId: '00000000000',
  classGroup: 'DEMO',
  role: 'demo',
  isAdmin: false,
  isBanned: false,
  emailVerified: true,
  jog: 1,
  createdAt: '2026-01-01T08:00:00.000Z',
};

const getDemoFelhasznalo = () => ({
  ...DEMO_FELHASZNALO,
  name: lokalizaltSzoveg('Demo Felhasználó', 'Demo User'),
});

const isDemoSession = () => getToken() === DEMO_TOKEN;
export const authSessionConfig = {
  inactivityTimeoutMs: 3 * 60 * 60 * 1000,
};

const STORAGE_PREFIX = 'suliradio';
const GUEST_SCOPE = 'guest';
const ACTIVE_USER_SCOPE_KEY = `${STORAGE_PREFIX}-active-user-scope`;
const ACTIVE_USER_CACHE_KEY = `${STORAGE_PREFIX}-active-user`;
const USER_STATE_EVENT = 'suliradio:user-state-updated';
const LEGACY_FAVORITES_KEY = 'suliradio-kedvencek';
const PUBLIC_SCHEDULE_CACHE_KEY = `${STORAGE_PREFIX}-public-schedule-cache`;
const ROLE_TO_JOG = {
  demo: 1,
  user: 2,
  student: 2,
  normal: 2,
  tanar: 3,
  teacher: 3,
  admin: 4,
};
const STORAGE_NAMES = {
  favorites: 'favorites',
  requestHistory: 'request-history',
  notifications: 'notifications',
  preferences: 'preferences',
  profile: 'profile',
};
export const DEFAULT_USER_PREFERENCES = Object.freeze({
  notifications: true,
  emailNotifications: true,
  autoplay: false,
  volume: 100,
  language: 'hu',
});

const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

export const sanitizeUserPreferences = (preferences) => ({
  notifications: preferences?.notifications ?? DEFAULT_USER_PREFERENCES.notifications,
  emailNotifications: preferences?.emailNotifications ?? DEFAULT_USER_PREFERENCES.emailNotifications,
  autoplay: preferences?.autoplay ?? DEFAULT_USER_PREFERENCES.autoplay,
  volume: clamp(
    Number.isFinite(Number(preferences?.volume)) ? Number(preferences.volume) : DEFAULT_USER_PREFERENCES.volume,
    0,
    200
  ),
  language: preferences?.language === 'en' ? 'en' : DEFAULT_USER_PREFERENCES.language,
});

const safeReadJson = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

const safeWriteJson = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

const lokalizaltSzoveg = (magyar, angol) => (
  getUserPreferences().language === 'en' ? angol : magyar
);

const sortByNewest = (items, field) => (
  [...items].sort((left, right) => new Date(right?.[field] || 0) - new Date(left?.[field] || 0))
);

const sanitizeSongIds = (value) => Array.from(new Set(
  (Array.isArray(value) ? value : [])
    .map((id) => Number(id))
    .filter((id) => Number.isFinite(id) && id > 0)
));

const getStorageScopeFromUser = (user) => {
  if (!user) return null;
  if (user.role === 'demo' || user.jog === 1 || user.id === 0) return 'demo';
  if (user.id != null) return `user-${user.id}`;
  if (user.email) return `email-${user.email.toLowerCase()}`;
  return null;
};

const getActiveUserScope = () => localStorage.getItem(ACTIVE_USER_SCOPE_KEY) || (isDemoSession() ? 'demo' : GUEST_SCOPE);

const setActiveUserScope = (user) => {
  const scope = getStorageScopeFromUser(user);
  if (scope) {
    localStorage.setItem(ACTIVE_USER_SCOPE_KEY, scope);
  }
  return scope;
};

const clearActiveUserScope = () => {
  localStorage.removeItem(ACTIVE_USER_SCOPE_KEY);
};

const getScopedStorageKey = (name, scope = getActiveUserScope()) => (
  scope ? `${STORAGE_PREFIX}-${name}-${scope}` : null
);

const readScopedJson = (name, fallback, scope = getActiveUserScope()) => {
  const key = getScopedStorageKey(name, scope);
  return key ? safeReadJson(key, fallback) : fallback;
};

const writeScopedJson = (name, value, scope = getActiveUserScope()) => {
  const key = getScopedStorageKey(name, scope);
  if (!key) return false;
  safeWriteJson(key, value);
  return true;
};

const cacheActiveUser = (user) => {
  if (!user) {
    localStorage.removeItem(ACTIVE_USER_CACHE_KEY);
    return;
  }
  safeWriteJson(ACTIVE_USER_CACHE_KEY, user);
};

const getCachedActiveUser = () => safeReadJson(ACTIVE_USER_CACHE_KEY, null);

const emitUserStateUpdate = (user) => {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent(USER_STATE_EVENT, { detail: user }));
};

const getStoredProfile = (scope = getActiveUserScope()) => {
  const stored = readScopedJson(STORAGE_NAMES.profile, {}, scope);
  return stored && typeof stored === 'object' ? stored : {};
};

const normalizeRole = (role) => {
  if (!role) return 'user';
  if (role === 'teacher') return 'tanar';
  if (role === 'student' || role === 'normal') return 'user';
  return role;
};

const roleToJog = (role) => ROLE_TO_JOG[normalizeRole(role)] || 2;

const jogToRole = (jog) => {
  if (jog >= 4) return 'admin';
  if (jog >= 3) return 'tanar';
  if (jog === 1) return 'demo';
  return 'user';
};

const parseNumericResponse = async (valasz) => {
  const jsonAdat = await valasz.json().catch(() => null);
  if (Array.isArray(jsonAdat) && jsonAdat.length > 0) {
    const elso = jsonAdat[0];
    if (typeof elso === 'number') return elso;
    if (elso && typeof elso === 'object') {
      const ertek = Object.values(elso).find((value) => Number.isFinite(Number(value)));
      return Number(ertek || 0);
    }
  }
  if (Number.isFinite(Number(jsonAdat))) {
    return Number(jsonAdat);
  }

  const szoveg = await valasz.text().catch(() => '0');
  return Number.parseInt(szoveg, 10) || 0;
};

const normalizeActiveUserEmail = (user) => String(user?.email || '').trim().toLowerCase();

const mergeActiveUsersWithLocalSession = (users = []) => {
  const backendUsers = Array.isArray(users) ? [...users] : [];
  const localUser = isDemoSession() ? getDemoFelhasznalo() : getCachedActiveUser();
  const hasAuthenticatedLocalSession = Boolean(getToken()) && !!localUser;
  const hasDemoUser = backendUsers.some((user) => {
    const email = normalizeActiveUserEmail(user);
    return Number(user?.jog) === 1 || email === DEMO_FELHASZNALO.email.toLowerCase();
  });

  const hasLocalUser = localUser && backendUsers.some((user) => {
    const backendEmail = normalizeActiveUserEmail(user);
    const localEmail = normalizeActiveUserEmail(localUser);

    if (backendEmail && localEmail) {
      return backendEmail === localEmail;
    }

    return Number(user?.id) > 0 && Number(user?.id) === Number(localUser?.id);
  });

  if (isDemoSession() && !hasDemoUser) {
    backendUsers.push({
      id: DEMO_FELHASZNALO.id,
      email: DEMO_FELHASZNALO.email,
      keresztnev: 'Felhasználó',
      vezeteknev: 'Demo',
      jog: DEMO_FELHASZNALO.jog,
    });
  } else if (hasAuthenticatedLocalSession && !hasLocalUser) {
    const [vezeteknev = '', keresztnev = ''] = String(localUser?.name || '')
      .trim()
      .split(/\s+/)
      .reduce((parts, piece, index) => {
        if (index === 0) {
          parts[0] = piece;
        } else {
          parts[1] = parts[1] ? `${parts[1]} ${piece}` : piece;
        }
        return parts;
      }, ['', '']);

    backendUsers.push({
      id: localUser.id,
      email: localUser.email,
      keresztnev,
      vezeteknev,
      jog: localUser.jog ?? roleToJog(localUser.role),
      tokenvaliditasanakvege: new Date(Date.now() + authSessionConfig.inactivityTimeoutMs).toISOString(),
    });
  }

  return backendUsers;
};

const deriveLastLoginAt = (activeUser) => {
  const tokenExpiry = activeUser?.tokenvaliditasanakvege;
  if (!tokenExpiry) return null;

  const expiryDate = new Date(tokenExpiry);
  if (Number.isNaN(expiryDate.getTime())) return null;

  return new Date(expiryDate.getTime() - authSessionConfig.inactivityTimeoutMs).toISOString();
};

const getMergedActiveUsers = async () => {
  const aktivFelhasznalokValasz = await apiFetch('/jelenlegbejelentkezettfelhasznalok').catch(() => null);
  if (!aktivFelhasznalokValasz || !aktivFelhasznalokValasz.ok) {
    return isDemoSession()
      ? mergeActiveUsersWithLocalSession([])
      : [];
  }

  const aktivFelhasznalok = await aktivFelhasznalokValasz.json().catch(() => []);
  return mergeActiveUsersWithLocalSession(aktivFelhasznalok);
};

const formatDateKey = (value = new Date()) => {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const normalizeScheduleEntries = (entries = []) => (
  [...entries]
    .map((entry) => ({
      ...(entry?.startTime ? entry : orarendMapper(entry)),
      songId: Number(entry?.songId ?? entry?.zeneid ?? entry?.songId),
      song: entry?.song || null,
    }))
    .filter((entry) => entry.startTime)
    .sort((left, right) => new Date(left.startTime) - new Date(right.startTime))
);

const readPublicScheduleCache = () => {
  const cached = safeReadJson(PUBLIC_SCHEDULE_CACHE_KEY, []);
  return Array.isArray(cached) ? normalizeScheduleEntries(cached) : [];
};

const writePublicScheduleCache = (entries) => {
  safeWriteJson(PUBLIC_SCHEDULE_CACHE_KEY, normalizeScheduleEntries(entries));
};

const filterScheduleByDate = (entries, dateKey) => (
  normalizeScheduleEntries(entries).filter((entry) => formatDateKey(entry.startTime) === dateKey)
);

const getFavoriteIds = (scope = getActiveUserScope()) => {
  const scopedFavorites = readScopedJson(STORAGE_NAMES.favorites, null, scope);
  if (scopedFavorites !== null) {
    return sanitizeSongIds(scopedFavorites);
  }

  const legacyFavorites = sanitizeSongIds(safeReadJson(LEGACY_FAVORITES_KEY, []));
  if (legacyFavorites.length > 0 && scope) {
    writeScopedJson(STORAGE_NAMES.favorites, legacyFavorites, scope);
  }
  return legacyFavorites;
};

const saveFavoriteIds = (songIds, scope = getActiveUserScope()) => {
  const favorites = sanitizeSongIds(songIds);
  writeScopedJson(STORAGE_NAMES.favorites, favorites, scope);
  return favorites;
};

const getUserPreferences = (scope = getActiveUserScope()) => (
  sanitizeUserPreferences(readScopedJson(STORAGE_NAMES.preferences, {}, scope))
);

const saveUserPreferences = (preferences, scope = getActiveUserScope()) => {
  const nextPreferences = sanitizeUserPreferences(preferences);
  writeScopedJson(STORAGE_NAMES.preferences, nextPreferences, scope);
  return nextPreferences;
};

const getRequestHistoryRecords = (scope = getActiveUserScope()) => {
  const history = readScopedJson(STORAGE_NAMES.requestHistory, [], scope);
  if (!Array.isArray(history)) return [];

  return sortByNewest(
    history
      .map((item) => ({
        ...item,
        songId: Number(item.songId),
        songUrl: item.songUrl || null,
        songTitle: item.songTitle || '',
        songArtist: item.songArtist || '',
        requestedAt: item.requestedAt || new Date().toISOString(),
        status: item.status || 'pending',
      }))
      .filter((item) => (
        (Number.isFinite(item.songId) && item.songId > 0) || Boolean(item.songUrl)
      )),
    'requestedAt'
  );
};

const saveRequestHistoryRecords = (history, scope = getActiveUserScope()) => {
  const normalizedHistory = sortByNewest(
    (Array.isArray(history) ? history : [])
      .map((item) => ({
        ...item,
        songId: Number(item.songId),
        songUrl: item.songUrl || null,
        songTitle: item.songTitle || '',
        songArtist: item.songArtist || '',
        requestedAt: item.requestedAt || new Date().toISOString(),
        status: item.status || 'pending',
      }))
      .filter((item) => (
        (Number.isFinite(item.songId) && item.songId > 0) || Boolean(item.songUrl)
      )),
    'requestedAt'
  );

  writeScopedJson(STORAGE_NAMES.requestHistory, normalizedHistory, scope);
  return normalizedHistory;
};

const getNotifications = (scope = getActiveUserScope()) => {
  const notifications = readScopedJson(STORAGE_NAMES.notifications, [], scope);
  return Array.isArray(notifications) ? sortByNewest(notifications, 'createdAt') : [];
};

const saveNotifications = (notifications, scope = getActiveUserScope()) => {
  const normalizedNotifications = sortByNewest(
    (Array.isArray(notifications) ? notifications : []).map((notification) => ({
      read: false,
      createdAt: new Date().toISOString(),
      ...notification,
    })),
    'createdAt'
  );

  writeScopedJson(STORAGE_NAMES.notifications, normalizedNotifications, scope);
  return normalizedNotifications;
};

const createNotificationId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const appendNotification = (notification, scope = getActiveUserScope()) => {
  const nextNotification = {
    id: createNotificationId(),
    read: false,
    createdAt: new Date().toISOString(),
    ...notification,
  };

  return saveNotifications([nextNotification, ...getNotifications(scope)], scope)[0];
};

const isSameDay = (value, reference = new Date()) => {
  const date = new Date(value);
  return (
    date.getFullYear() === reference.getFullYear() &&
    date.getMonth() === reference.getMonth() &&
    date.getDate() === reference.getDate()
  );
};

const buildDailyStatusFromHistory = (history = getRequestHistoryRecords()) => {
  const todaysRequests = history.filter((item) => isSameDay(item.requestedAt));

  return {
    maxDaily: 3,
    usedToday: todaysRequests.length,
    remaining: Math.max(0, 3 - todaysRequests.length),
    requestedSongIds: Array.from(new Set(todaysRequests.map((item) => item.songId))),
    lastRequestedSongId: history[0]?.songId || null,
  };
};

const ensureWelcomeNotification = (user, scope = getActiveUserScope()) => {
  const notifications = getNotifications(scope);
  if (notifications.some((notification) => notification.kind === 'welcome')) {
    return notifications;
  }

  const preferences = getUserPreferences(scope);
  if (preferences.notifications === false) {
    return notifications;
  }

  const welcomeNotification = user?.role === 'demo'
    ? {
        kind: 'welcome',
        type: 'info',
        title: lokalizaltSzoveg('Demo mód aktív', 'Demo mode is active'),
        message: lokalizaltSzoveg(
          'A demo fiókban böngészhetsz, kérhetsz zenét és tesztelheted a felületet, de a profiladatok nem szerkeszthetők.',
          'In the demo account you can browse, request songs, and test the interface, but profile data cannot be edited.'
        ),
      }
    : {
        kind: 'welcome',
        type: 'info',
        title: lokalizaltSzoveg('Üdvözlünk!', 'Welcome!'),
        message: lokalizaltSzoveg(
          'A fiókoddal kapcsolatos fontos események ezen az oldalon fognak megjelenni.',
          'Important events related to your account will appear on this page.'
        ),
      };

  appendNotification(welcomeNotification, scope);
  return getNotifications(scope);
};

const hydrateUserState = (user) => {
  if (!user) return null;

  const scope = setActiveUserScope(user);
  const storedProfile = getStoredProfile(scope);
  const classGroup = storedProfile.classGroup ?? storedProfile.class ?? user.classGroup ?? user.class ?? '';

  ensureWelcomeNotification(user, scope);

  const hydratedUser = {
    ...user,
    name: storedProfile.name ?? user.name ?? '',
    email: storedProfile.email ?? user.email ?? '',
    classGroup,
    class: classGroup,
    educationalId: storedProfile.educationalId ?? storedProfile.omazonosito ?? user.educationalId ?? '',
    omazonosito: storedProfile.educationalId ?? storedProfile.omazonosito ?? user.educationalId ?? '',
    favorites: getFavoriteIds(scope),
    requestHistory: getRequestHistoryRecords(scope),
    preferences: getUserPreferences(scope),
    notifications: getNotifications(scope),
  };

  cacheActiveUser(hydratedUser);
  emitUserStateUpdate(hydratedUser);
  return hydratedUser;
};

// ============================================================
// Hitelesítés (bejelentkezés, kijelentkezés, regisztráció)
// ============================================================
export const authAPI = {
  // Regisztráció a backend /regisztracio végpontján
  // Elvárja: email, jelszo (sima szöveg – itt kódoljuk base64-be),
  //          keresztnev, vezeteknev, omazonosito
  register: async (adatok) => {
    try {
      const valasz = await apiFetch('/regisztracio', {
        method: 'POST',
        body: JSON.stringify({
          email: adatok.email,
          jelszo: encodeBase64Utf8(adatok.password),
          keresztnev: adatok.keresztnev,
          vezeteknev: adatok.vezeteknev,
          omazonosito: adatok.omazonosito || '',
        }),
      });

      if (valasz.status === 201) {
        return { success: true };
      }

      const szoveg = await valasz.text().catch(() => '');
      return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Bejelentkezés a backend /bejelentkezes végpontján
  // Elsődlegesen UTF-8 alapú base64 emailt és jelszót küldünk,
  // de kompatibilitásból meghagyunk egy nyers-email fallbacket a jelenlegi backendhez.
  // Sikeres bejelentkezésnél plain-text tokennel válaszol (200)
  login: async (identifier, jelszo) => {
    try {
      const trimmedIdentifier = identifier.trim();
      const encodedPassword = encodeBase64Utf8(jelszo);
      const requestBodies = [
        {
          email: encodeBase64Utf8(trimmedIdentifier),
          jelszo: encodedPassword,
        },
        {
          email: trimmedIdentifier,
          jelszo: encodedPassword,
          ' jelszo': encodedPassword,
        },
      ];

      let valasz = null;
      for (const body of requestBodies) {
        valasz = await apiFetch('/bejelentkezes', {
          method: 'POST',
          body: JSON.stringify(body),
        });

        if (valasz.ok) {
          break;
        }
      }

      if (!valasz.ok) {
        return {
          success: false,
          error: getHttpHibaSzoveg(valasz.status) || lokalizaltSzoveg('Hibás bejelentkezési adatok!', 'Invalid sign-in credentials!'),
        };
      }

      const token = await valasz.text();
      if (!token || token.trim() === '') {
        return {
          success: false,
          error: lokalizaltSzoveg('A szerver érvénytelen tokent küldött!', 'The server returned an invalid token!'),
        };
      }

      // Token eltárolása, majd a felhasználó adatainak lekérése
      setAuthToken(token.trim());
      const felhasznaloValasz = await authAPI.me();
      return { success: true, token: token.trim(), user: felhasznaloValasz.user || null };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Kijelentkezés – a backend érvényteleníti a tokent
  logout: async () => {
    try {
      await apiFetch('/kilepes');
    } catch {
      // ha a szerver nem érhető el, akkor is kijelentkeztetjük helyben
    }
    clearAuthToken();
    clearActiveUserScope();
    cacheActiveUser(null);
    return { success: true };
  },

  // Aktuális felhasználó adatainak lekérése a tárolt token alapján
  me: async () => {
    if (isDemoSession()) {
      return { success: true, user: hydrateUserState(getDemoFelhasznalo()) };
    }

    const token = getToken();
    if (!token) return { success: false };

    try {
      const valasz = await fetch(`${API_URL}/felhasznalotokenbol/x`, {
        headers: {
          'Accept': 'application/json',
          'token': token,
        },
      });

      if (!valasz.ok) {
        if (valasz.status === 401 || valasz.status === 404) {
          clearAuthToken();
        }
        return { success: false };
      }

      const adatok = await valasz.json();
      if (!adatok) return { success: false };

      return { success: true, user: hydrateUserState(felhasznaloMapper(adatok)) };
    } catch {
      return { success: false };
    }
  },

  // Demo bejelentkezés – nem kapcsolódik a backendhez
  demoLogin: () => {
    return Promise.resolve({ success: true, token: DEMO_TOKEN, user: hydrateUserState(getDemoFelhasznalo()) });
  },

  // Profil frissítése helyi tárolásban, mert a backendhez nincs külön végpont
  updateProfile: (updates) => {
    if (isDemoSession()) {
      return Promise.resolve({
        success: false,
        error: lokalizaltSzoveg('A demo felhasználó profilja nem szerkeszthető.', 'The demo user profile cannot be edited.'),
      });
    }

    const currentUser = getCachedActiveUser();
    if (!currentUser) {
      return Promise.resolve({
        success: false,
        error: lokalizaltSzoveg('Nincs aktív felhasználó.', 'There is no active user.'),
      });
    }

    const profileUpdates = {
      name: updates.name?.trim() || currentUser.name || '',
      email: updates.email?.trim() || currentUser.email || '',
      classGroup: updates.class_group?.trim() || updates.classGroup?.trim() || updates.class?.trim() || currentUser.classGroup || currentUser.class || '',
      educationalId: updates.educationalId?.trim() || updates.omazonosito?.trim() || currentUser.educationalId || currentUser.omazonosito || '',
    };

    writeScopedJson(STORAGE_NAMES.profile, {
      ...getStoredProfile(),
      ...profileUpdates,
      class: profileUpdates.classGroup,
      omazonosito: profileUpdates.educationalId,
    });

    return Promise.resolve({
      success: true,
      user: hydrateUserState({
        ...currentUser,
        ...profileUpdates,
        class: profileUpdates.classGroup,
        omazonosito: profileUpdates.educationalId,
      }),
    });
  },

  // Szerver ideje
  getServerTime: async () => {
    const valasz = await apiFetch('/ido');
    if (!valasz.ok) return null;
    return valasz.text();
  },
};

// ============================================================
// Zenék (GET /osszeszene, GET /lejatszhatozenek)
// ============================================================
export const songsAPI = {
  // Összes zene lekérése
  getAll: async () => {
    try {
      const valasz = await apiFetch('/osszeszene');
      if (!valasz.ok) return { success: false, songs: [] };
      const adatok = await valasz.json();
      const zenek = Array.isArray(adatok) ? adatok.map(zeneMapper) : [];
      return { success: true, songs: zenek };
    } catch {
      return { success: true, songs: [] };
    }
  },

  // Egyetlen zene lekérése id alapján (a backend /osszeszene végpontból szűrünk)
  getOne: async (id) => {
    try {
      const valasz = await apiFetch('/osszeszene');
      if (!valasz.ok) return { success: false, error: lokalizaltSzoveg('A zene nem található.', 'The song could not be found.') };
      const adatok = await valasz.json();
      const zene = Array.isArray(adatok) ? adatok.find(z => z.id === Number(id)) : null;
      if (!zene) return { success: false, error: lokalizaltSzoveg('A zene nem található.', 'The song could not be found.') };
      return { success: true, song: zeneMapper(zene) };
    } catch {
      return { success: false, error: lokalizaltSzoveg('Hiba a zene lekérésekor.', 'An error occurred while fetching the song.') };
    }
  },

  // Műfajok kinyerése az összes zenéből (a backend nem rendelkezik külön végponttal)
  getGenres: async () => {
    try {
      const valasz = await apiFetch('/osszeszene');
      if (!valasz.ok) return { success: true, genres: [] };
      const adatok = await valasz.json();
      const mufajok = [...new Set(
        (Array.isArray(adatok) ? adatok : [])
          .map(z => z.tema)
          .filter(Boolean)
      )].sort();
      return { success: true, genres: mufajok };
    } catch {
      return { success: true, genres: [] };
    }
  },

  // Statisztikák: aktív felhasználószám + következő lejátszás
  getStats: async () => {
    try {
      const [zeneValasz, kovetkezoValasz, aktivFelhasznalok, felhasznalokValasz] = await Promise.all([
        apiFetch('/osszeszene').catch(() => null),
        apiFetch('/kovetkezolejatszas').catch(() => null),
        getMergedActiveUsers(),
        apiFetch('/osszesfelhasznalokilistazasa').catch(() => null),
      ]);

      let osszes = 0;
      if (zeneValasz && zeneValasz.ok) {
        const adatok = await zeneValasz.json().catch(() => []);
        osszes = Array.isArray(adatok) ? adatok.length : 0;
      }

      const aktivak = Array.isArray(aktivFelhasznalok) ? aktivFelhasznalok.length : 0;

      let osszesFelhasznalo = 0;
      if (felhasznalokValasz && felhasznalokValasz.ok) {
        const adatok = await felhasznalokValasz.json().catch(() => []);
        osszesFelhasznalo = Array.isArray(adatok) ? adatok.length : 0;
      }

      let kovetkezo = null;
      if (kovetkezoValasz && kovetkezoValasz.ok) {
        const k = await kovetkezoValasz.json().catch(() => null);
        if (k) kovetkezo = orarendMapper(k);
      }

      return {
        success: true,
        stats: {
          totalUsers: osszesFelhasznalo,
          totalSongs: osszes,
          todayRequests: 0,
          activeUsers: aktivak,
          currentListeners: aktivak,
          currentlyPlaying: null,
          nextScheduled: kovetkezo,
        },
      };
    } catch {
      return {
        success: true,
        stats: { totalUsers: 0, totalSongs: 0, todayRequests: 0, activeUsers: 0, currentListeners: 0, currentlyPlaying: null },
      };
    }
  },
};

// ============================================================
// Órarend (GET /mainapiorarend, GET /kovetkezolejatszas)
// ============================================================
export const scheduleAPI = {
  // Órarend lekérése a kiválasztott napra.
  // Bejelentkezett állapotban a teljes órarendet kérjük le és kliensoldalon szűrjük.
  // Kijelentkezve a cache-elt teljes órarendet használjuk, ma esetén pedig frissítünk a publikus végpontról.
  get: async (datum) => {
    const targetDate = datum || formatDateKey(new Date());
    const cachedSchedule = readPublicScheduleCache();

    try {
      if (getToken()) {
        const [orarendValasz, zeneValasz] = await Promise.all([
          apiFetch('/teljesorarend'),
          apiFetch('/osszeszene').catch(() => null),
        ]);

        if (orarendValasz.ok) {
          const orarendAdatok = await orarendValasz.json().catch(() => []);
          const bejegyzesek = Array.isArray(orarendAdatok) ? orarendAdatok : [];

          let zeneMap = {};
          if (zeneValasz && zeneValasz.ok) {
            const zenek = await zeneValasz.json().catch(() => []);
            if (Array.isArray(zenek)) {
              zenek.forEach((zene) => {
                zeneMap[zene.id] = zeneMapper(zene);
              });
            }
          }

          const teljesOrarend = normalizeScheduleEntries(bejegyzesek.map((bejegyzes) => ({
            ...orarendMapper(bejegyzes),
            song: zeneMap[bejegyzes.zeneid] || null,
          })));

          writePublicScheduleCache(teljesOrarend);

          return {
            success: true,
            schedule: filterScheduleByDate(teljesOrarend, targetDate),
            date: targetDate,
          };
        }
      }

      const todayDate = formatDateKey(new Date());
      if (targetDate === todayDate) {
        const [orarendValasz, zeneValasz] = await Promise.all([
          apiFetch('/mainapiorarend'),
          apiFetch('/osszeszene').catch(() => null),
        ]);

        if (orarendValasz.ok) {
          const orarendAdatok = await orarendValasz.json().catch(() => []);
          const bejegyzesek = Array.isArray(orarendAdatok) ? orarendAdatok : [];

          let zeneMap = {};
          if (zeneValasz && zeneValasz.ok) {
            const zenek = await zeneValasz.json().catch(() => []);
            if (Array.isArray(zenek)) {
              zenek.forEach((zene) => {
                zeneMap[zene.id] = zeneMapper(zene);
              });
            }
          }

          const maiOrarend = normalizeScheduleEntries(bejegyzesek.map((bejegyzes) => ({
            ...orarendMapper(bejegyzes),
            song: zeneMap[bejegyzes.zeneid] || null,
          })));

          const nemMaiCache = cachedSchedule.filter((entry) => formatDateKey(entry.startTime) !== todayDate);
          writePublicScheduleCache([...nemMaiCache, ...maiOrarend]);

          return { success: true, schedule: maiOrarend, date: targetDate };
        }
      }

      return {
        success: true,
        schedule: filterScheduleByDate(cachedSchedule, targetDate),
        date: targetDate,
      };
    } catch {
      return {
        success: true,
        schedule: filterScheduleByDate(cachedSchedule, targetDate),
        date: targetDate,
      };
    }
  },

  // Következő lejátszás lekérése
  kovetkezo: async () => {
    try {
      const valasz = await apiFetch('/kovetkezolejatszas');
      if (!valasz.ok) return { success: false, item: null };
      const adatok = await valasz.json();
      return { success: true, item: adatok ? orarendMapper(adatok) : null };
    } catch {
      return { success: false, item: null };
    }
  },

  // Jelenleg játszott zene URL-je (plain text, nem JSON)
  jelenlegiZene: async () => {
    try {
      const valasz = await apiFetch('/lejatszandozene');
      if (!valasz.ok) return { success: false, url: null };
      const url = await valasz.text();
      return { success: true, url: url && url !== 'nincs' ? url : null };
    } catch {
      return { success: false, url: null };
    }
  },
};

// ============================================================
// Zenekérések (a backend jelenleg nem rendelkezik külön
// zenekérési végponttal, de a zenevalidáció meghívható)
// ============================================================
export const requestsAPI = {
  // Zenekérés rögzítése a backend /bekeres végpontján,
  // majd a frontend helyi napi státuszának frissítése.
  create: async (songIds, uzenet) => {
    if (!getToken()) {
      return {
        success: false,
        error: lokalizaltSzoveg(
          'A zenekéréshez be kell jelentkezni!',
          'You need to sign in to request songs.'
        ),
      };
    }

    const uniqueSongIds = sanitizeSongIds(songIds);
    if (uniqueSongIds.length === 0) {
      return {
        success: false,
        error: lokalizaltSzoveg(
          'Válassz ki legalább egy zenét!',
          'Select at least one song.'
        ),
      };
    }

    try {
      const currentHistory = getRequestHistoryRecords();
      const dailyStatus = buildDailyStatusFromHistory(currentHistory);

      if (uniqueSongIds.length > dailyStatus.remaining) {
        return {
          success: false,
          error: dailyStatus.remaining === 0
            ? lokalizaltSzoveg(
              `Elérted a napi limitet (${dailyStatus.maxDaily} zene/nap). Holnap újra kérhetsz!`,
              `You reached the daily limit (${dailyStatus.maxDaily} songs/day). You can request again tomorrow.`
            )
            : lokalizaltSzoveg(
              `Ma már csak ${dailyStatus.remaining} zenét kérhetsz!`,
              `You can only request ${dailyStatus.remaining} more songs today.`
            ),
        };
      }

      const repeatedSongId = uniqueSongIds.find((songId) => dailyStatus.requestedSongIds.includes(songId));
      if (repeatedSongId) {
        return {
          success: false,
          error: lokalizaltSzoveg(
            'Ugyanazt a zenét egy napon belül csak egyszer kérheted.',
            'You can only request the same song once per day.'
          ),
        };
      }

      if (dailyStatus.lastRequestedSongId && uniqueSongIds.includes(dailyStatus.lastRequestedSongId)) {
        return {
          success: false,
          error: lokalizaltSzoveg(
            'Nem kérheted ugyanazt a zenét közvetlenül egymás után.',
            'You cannot request the same song twice in a row.'
          ),
        };
      }

      const songsData = await songsAPI.getAll().catch(() => ({ success: false, songs: [] }));
      const songMap = new Map(
        (songsData.success ? songsData.songs : []).map((song) => [song.id, song])
      );

      const resolvedSongs = uniqueSongIds.map((songId) => songMap.get(songId)).filter(Boolean);
      if (resolvedSongs.length !== uniqueSongIds.length) {
        return {
          success: false,
          error: lokalizaltSzoveg(
            'Néhány kiválasztott zenét nem sikerült betölteni. Frissítsd az oldalt, és próbáld újra!',
            'Some selected songs could not be loaded. Refresh the page and try again.'
          ),
        };
      }

      const resolveRequestSongUrl = (song) => (
        song?.sourceUrl || song?.mp3Url || song?.raw?.keresurl || song?.raw?.zeneurl || null
      );

      const missingSongUrl = resolvedSongs.find((song) => !resolveRequestSongUrl(song));
      if (missingSongUrl) {
        return {
          success: false,
          error: lokalizaltSzoveg(
            `A(z) "${missingSongUrl.title}" nem kérhető, mert hiányzik a forráslink vagy a zene útvonala.`,
            `"${missingSongUrl.title}" cannot be requested because its source link or song path is missing.`
          ),
        };
      }

      for (const song of resolvedSongs) {
        const valasz = await apiFetch('/bekeres', {
          method: 'POST',
          body: JSON.stringify({
            zeneurl: resolveRequestSongUrl(song),
          }),
        });

        if (!valasz.ok) {
          const szoveg = await valasz.text().catch(() => '');
          return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
        }
      }

      const now = new Date().toISOString();
      const newHistoryEntries = resolvedSongs.map((song, index) => ({
        id: createNotificationId(),
        songId: song.id,
        songUrl: resolveRequestSongUrl(song),
        songTitle: song.title || '',
        songArtist: song.artist || '',
        requestedAt: new Date(Date.now() + index).toISOString(),
        status: 'pending',
        message: uzenet || '',
      }));
      const updatedHistory = saveRequestHistoryRecords([...newHistoryEntries, ...currentHistory]);

      const preferences = getUserPreferences();
      if (preferences.notifications !== false) {
        const titles = uniqueSongIds
          .map((songId) => songMap.get(songId)?.title)
          .filter(Boolean);

        appendNotification({
          type: 'request',
          title: uniqueSongIds.length === 1
            ? lokalizaltSzoveg('Zenekérés rögzítve', 'Song request recorded')
            : lokalizaltSzoveg(`${uniqueSongIds.length} zenekérés rögzítve`, `${uniqueSongIds.length} song requests recorded`),
          message: titles.length > 0
            ? lokalizaltSzoveg(
              `A kérésedet elmentettük: ${titles.join(', ')}.`,
              `Your request was saved: ${titles.join(', ')}.`
            )
            : lokalizaltSzoveg(
              'A kiválasztott zenék bekerültek az előzményeid közé.',
              'The selected songs were added to your request history.'
            ),
          createdAt: now,
        });
      }

      const updatedUser = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
      return {
        success: true,
        message: uniqueSongIds.length === 1
          ? lokalizaltSzoveg('A zenekérésed rögzítve lett.', 'Your song request has been recorded.')
          : lokalizaltSzoveg(`${uniqueSongIds.length} zenekérés rögzítve lett.`, `${uniqueSongIds.length} song requests have been recorded.`),
        history: updatedHistory,
        dailyStatus: buildDailyStatusFromHistory(updatedHistory),
        user: updatedUser,
      };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  history: async () => {
    const history = getRequestHistoryRecords();
    if (history.length === 0) {
      return { success: true, history: [] };
    }

    const songsData = await songsAPI.getAll().catch(() => ({ success: false, songs: [] }));
    const songMap = new Map(
      (songsData.success ? songsData.songs : []).map((song) => [song.id, song])
    );

    return {
      success: true,
      history: history.map((item) => ({
        ...item,
        song: songMap.get(item.songId)
          || (item.songUrl
            ? Array.from(songMap.values()).find((song) => (
              song.sourceUrl === item.songUrl || song.mp3Url === item.songUrl
            )) || null
            : null)
          || ((item.songTitle || item.songArtist || item.songUrl)
            ? {
              id: item.songId || item.id,
              title: item.songTitle || item.songUrl || lokalizaltSzoveg('(ismeretlen cím)', '(unknown title)'),
              artist: item.songArtist || lokalizaltSzoveg('(ismeretlen előadó)', '(unknown artist)'),
              mp3Url: item.songUrl,
              sourceUrl: item.songUrl,
            }
            : null),
      })),
    };
  },

  createFromUrl: async (songUrl) => {
    if (!getToken()) {
      return {
        success: false,
        error: lokalizaltSzoveg(
          'A zenekéréshez be kell jelentkezni!',
          'You need to sign in to request songs.'
        ),
      };
    }

    const normalizedUrl = String(songUrl || '').trim();
    if (!normalizedUrl) {
      return {
        success: false,
        error: lokalizaltSzoveg('Add meg a zene linkjét!', 'Provide the song link.'),
      };
    }

    if (/spotify\.com/i.test(normalizedUrl)) {
      return {
        success: false,
        error: lokalizaltSzoveg(
          'Spotify linket nem lehet beküldeni. Használj közvetlenül elérhető YouTube vagy más támogatott linket.',
          'Spotify links are not supported. Use a directly accessible YouTube or other supported link instead.'
        ),
      };
    }

    try {
      const valasz = await apiFetch('/bekeres', {
        method: 'POST',
        body: JSON.stringify({ zeneurl: normalizedUrl }),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      const currentHistory = getRequestHistoryRecords();
      const updatedHistory = saveRequestHistoryRecords([
        {
          id: createNotificationId(),
          songId: Number.NaN,
          songUrl: normalizedUrl,
          songTitle: '',
          songArtist: '',
          requestedAt: new Date().toISOString(),
          status: 'pending',
        },
        ...currentHistory,
      ]);

      return {
        success: true,
        message: lokalizaltSzoveg('A linked bekérés rögzítve lett.', 'The linked request has been recorded.'),
        history: updatedHistory,
        dailyStatus: buildDailyStatusFromHistory(updatedHistory),
      };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  dailyStatus: () => Promise.resolve({
    success: true,
    ...buildDailyStatusFromHistory(),
  }),
};

// ============================================================
// Zenefeltöltési javaslatok (POST /zenefeltoltes)
// ============================================================
export const submissionsAPI = {
  // Új zene feltöltése/javaslása az adminnak
  create: async (adatok) => {
    if (!getToken()) {
      return {
        success: false,
        error: lokalizaltSzoveg('A feltöltéshez be kell jelentkezni!', 'You need to sign in to submit music!'),
      };
    }
    try {
      const valasz = await apiFetch('/zenefeltoltes', {
        method: 'POST',
        body: JSON.stringify({
          keresurl: adatok.sourceUrl || adatok.keresurl,
          zeneurl: adatok.mp3Url || adatok.zeneurl || '',
          cim: adatok.title || adatok.cim || '',
          eloado: adatok.artist || adatok.eloado || '',
          hossz: adatok.duration || adatok.hossz || null,
          tema: adatok.genre || adatok.tema || null,
          lejatszatoe: 0,
        }),
      });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      const preferences = getUserPreferences();
      if (preferences.notifications !== false) {
        appendNotification({
          type: 'submission',
          title: lokalizaltSzoveg('Linkbeküldés elküldve', 'Link submission sent'),
          message: lokalizaltSzoveg(
            `A(z) ${adatok.title || 'új zene'} beküldését elküldtük feldolgozásra.`,
            `The submission for ${adatok.title || 'your new song'} was sent for processing.`
          ),
        });
      }

      if (getCachedActiveUser()) {
        hydrateUserState(getCachedActiveUser());
      }

      return {
        success: true,
        message: lokalizaltSzoveg('A linkbeküldésed sikeresen elküldve.', 'Your link submission was sent successfully.'),
      };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  mine: () => Promise.resolve({ success: true, submissions: [] }),
};

// ============================================================
// Kedvencek (helyi tárolás – a backend nem rendelkezik
// kedvencek végponttal)
// ============================================================
export const favoritesAPI = {
  getAll: () => {
    try {
      return Promise.resolve({ success: true, favorites: getFavoriteIds() });
    } catch {
      return Promise.resolve({ success: true, favorites: [] });
    }
  },

  add: (songId) => {
    try {
      const favorites = getFavoriteIds();
      const nextFavorites = favorites.includes(songId)
        ? favorites
        : saveFavoriteIds([...favorites, songId]);

      if (getCachedActiveUser()) {
        hydrateUserState(getCachedActiveUser());
      }

      return Promise.resolve({ success: true, favorites: nextFavorites });
    } catch {
      return Promise.resolve({ success: false, error: lokalizaltSzoveg('Hiba a kedvencekhez adásnál.', 'Could not add the song to favorites.') });
    }
  },

  remove: (songId) => {
    try {
      const updatedFavorites = saveFavoriteIds(getFavoriteIds().filter((id) => id !== songId));

      if (getCachedActiveUser()) {
        hydrateUserState(getCachedActiveUser());
      }

      return Promise.resolve({ success: true, favorites: updatedFavorites });
    } catch {
      return Promise.resolve({ success: false, error: lokalizaltSzoveg('Hiba a kedvencekből eltávolításnál.', 'Could not remove the song from favorites.') });
    }
  },
};

export const preferencesAPI = {
  get: () => Promise.resolve({ success: true, preferences: getUserPreferences() }),

  update: (updates) => {
    const preferences = saveUserPreferences({
      ...getUserPreferences(),
      ...(updates || {}),
    });

    const user = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
    return Promise.resolve({ success: true, preferences, user });
  },
};

export const notificationsAPI = {
  getAll: () => Promise.resolve({ success: true, notifications: getNotifications() }),

  markAsRead: (id) => {
    const notifications = saveNotifications(
      getNotifications().map((notification) => (
        notification.id === id ? { ...notification, read: true } : notification
      ))
    );

    const user = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
    return Promise.resolve({ success: true, notifications, user });
  },

  markAllAsRead: () => {
    const notifications = saveNotifications(
      getNotifications().map((notification) => ({ ...notification, read: true }))
    );

    const user = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
    return Promise.resolve({ success: true, notifications, user });
  },

  delete: (id) => {
    const notifications = saveNotifications(
      getNotifications().filter((notification) => notification.id !== id)
    );

    const user = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
    return Promise.resolve({ success: true, notifications, user });
  },

  clearAll: () => {
    const notifications = saveNotifications([]);
    const user = getCachedActiveUser() ? hydrateUserState(getCachedActiveUser()) : null;
    return Promise.resolve({ success: true, notifications, user });
  },
};

// ============================================================
// Admin végpontok
// ============================================================
const toNumberOrNull = (value) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

const toBoolean = (value) => value === true || value === 1 || value === '1';

const adminRequestMapper = (request) => ({
  id: request.id,
  userId: request.felhasznaloid ?? null,
  songId: request.zeneid ?? null,
  songUrl: request.zeneurl || request.keresurl || null,
  requestedAt: request.mikor || request.created_at || null,
  validated: toBoolean(request.validalte),
  raw: request,
});

const adminSubmissionMapper = (submission, index) => ({
  id: submission.id ?? submission.zeneid ?? submission.keresid ?? `submission-${index}`,
  title: submission.cim || submission.title || submission.zene || submission.zenecim || '',
  artist: submission.eloado || submission.artist || '',
  sourceUrl: submission.keresurl || submission.url || '',
  mp3Url: submission.zeneurl || submission.mp3url || submission.utvonal || '',
  duration: toNumberOrNull(submission.hossz ?? submission.duration),
  genre: submission.tema || submission.genre || '',
  requestCount: Number(submission.keresszam || submission.requestCount || 0),
  createdAt: submission.created_at || submission.createdAt || submission.mikor || null,
  raw: submission,
});

const adminBreakMapper = (szunet) => ({
  id: szunet.id ?? szunet.hanyadik,
  sequence: Number(szunet.hanyadik),
  start: szunet.kezdes || null,
  end: szunet.vege || null,
  raw: szunet,
});

export const adminAPI = {
  // Irányítópult adatok: összes zene + aktív felhasználók + órarend
  dashboard: async () => {
    try {
      const [
        zeneValasz,
        orarendValasz,
        felhasznalokValasz,
        aktivFelhasznalokValasz,
        keresekValasz,
        bekuldesekValasz,
        szunetekValasz,
      ] = await Promise.all([
        apiFetch('/osszeszene'),
        apiFetch('/teljesorarend').catch(() => null),
        apiFetch('/osszesfelhasznalokilistazasa').catch(() => null),
        apiFetch('/jelenlegbejelentkezettfelhasznalok').catch(() => null),
        apiFetch('/kereseklistazasa').catch(() => null),
        apiFetch('/varolista').catch(() => null),
        apiFetch('/szuneteklistaja').catch(() => null),
      ]);

      if (!zeneValasz.ok) {
        return {
          success: false,
          error: lokalizaltSzoveg('Nem sikerült betölteni az admin adatokat.', 'Could not load the admin data.'),
        };
      }

      const zenek = await zeneValasz.json().catch(() => []);
      const teljesOrarend = orarendValasz && orarendValasz.ok
        ? await orarendValasz.json().catch(() => [])
        : [];
      const felhasznalok = felhasznalokValasz && felhasznalokValasz.ok
        ? await felhasznalokValasz.json().catch(() => [])
        : [];
      const aktivFelhasznalok = aktivFelhasznalokValasz && aktivFelhasznalokValasz.ok
        ? await aktivFelhasznalokValasz.json().catch(() => [])
        : [];
      const keresek = keresekValasz && keresekValasz.ok
        ? await keresekValasz.json().catch(() => [])
        : [];
      const bekuldesek = bekuldesekValasz && bekuldesekValasz.ok
        ? await bekuldesekValasz.json().catch(() => [])
        : [];
      const szunetek = szunetekValasz && szunetekValasz.ok
        ? await szunetekValasz.json().catch(() => [])
        : [];

      return {
        success: true,
        dashboard: {
          stats: {
            totalSongs: Array.isArray(zenek) ? zenek.length : 0,
            totalUsers: Array.isArray(felhasznalok) ? felhasznalok.length : 0,
            activeUsers: mergeActiveUsersWithLocalSession(aktivFelhasznalok).length,
            totalScheduleItems: Array.isArray(teljesOrarend) ? teljesOrarend.length : 0,
            pendingRequests: Array.isArray(keresek)
              ? keresek.filter((item) => !toBoolean(item.validalte)).length
              : 0,
            pendingSubmissions: Array.isArray(bekuldesek) ? bekuldesek.length : 0,
            totalBreaks: Array.isArray(szunetek) ? szunetek.length : 0,
          },
          capabilities: {
            canListUsers: !!(felhasznalokValasz && felhasznalokValasz.ok),
            canEditExistingUsers: true,
            canManageBreaks: !!(szunetekValasz && szunetekValasz.ok),
            canListRequests: !!(keresekValasz && keresekValasz.ok),
            canListSubmissions: !!(bekuldesekValasz && bekuldesekValasz.ok),
          },
        },
      };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Zenék listája (GET /osszeszene)
  getSongs: async () => {
    try {
      const valasz = await apiFetch('/osszeszene');
      if (!valasz.ok) return { success: false, songs: [] };
      const adatok = await valasz.json().catch(() => []);
      return { success: true, songs: Array.isArray(adatok) ? adatok.map(zeneMapper) : [] };
    } catch {
      return { success: true, songs: [] };
    }
  },

  // Új zene hozzáadása (POST /zenefeltoltes)
  createSong: async (adatok) => {
    try {
      const valasz = await apiFetch('/zenefeltoltes', {
        method: 'POST',
        body: JSON.stringify({
          keresurl: adatok.sourceUrl || adatok.keresurl || '',
          zeneurl: adatok.mp3Url || adatok.zeneurl || '',
          cim: adatok.title || adatok.cim || '',
          eloado: adatok.artist || adatok.eloado || '',
          hossz: adatok.duration || adatok.hossz || null,
          tema: adatok.genre || adatok.tema || null,
          lejatszatoe: adatok.isAvailable ? 1 : 0,
          lejatszhatoe: adatok.isAvailable ? 1 : 0,
        }),
      });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }
      return { success: true };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Zene frissítése (PUT /zenefrissites)
  updateSong: async (id, adatok) => {
    try {
      const valasz = await apiFetch('/zenefrissites', {
        method: 'PUT',
        body: JSON.stringify({
          id,
          keresurl: adatok.sourceUrl || adatok.keresurl,
          cim: adatok.title || adatok.cim,
          eloado: adatok.artist || adatok.eloado,
          hossz: adatok.duration || adatok.hossz,
          tema: adatok.genre || adatok.tema,
          lejatszhatoe: adatok.isAvailable ? 1 : 0,
          zeneurl: adatok.mp3Url || adatok.zeneurl,
        }),
      });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }
      return { success: true };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Zene törlése id alapján (DELETE /zenetorlesidalapjan/{id})
  deleteSong: async (id) => {
    try {
      const valasz = await apiFetch(`/zenetorlesidalapjan/${id}`, { method: 'DELETE' });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }
      return { success: true };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Órarend bejegyzés hozzáadása (POST /orarendmanualishozzaadas)
  addScheduleItem: async (zeneid, mikortol, meddig) => {
    try {
      const valasz = await apiFetch('/orarendmanualishozzaadas', {
        method: 'POST',
        body: JSON.stringify({ zeneid, mikortol, meddig }),
      });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }
      return { success: true };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  // Órarend bejegyzés törlése (DELETE /lejatszastorles)
  deleteScheduleItem: async (id) => {
    try {
      const valasz = await apiFetch('/lejatszastorles', {
        method: 'DELETE',
        body: JSON.stringify({ id }),
      });
      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }
      return { success: true };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  getSchedule: async () => {
    try {
      const [orarendValasz, zeneValasz] = await Promise.all([
        apiFetch('/teljesorarend'),
        apiFetch('/osszeszene').catch(() => null),
      ]);

      if (!orarendValasz.ok) {
        const szoveg = await orarendValasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, orarendValasz.status), schedule: [] };
      }

      const scheduleRows = await orarendValasz.json().catch(() => []);
      const songRows = zeneValasz && zeneValasz.ok ? await zeneValasz.json().catch(() => []) : [];
      const songsById = new Map((Array.isArray(songRows) ? songRows : []).map((row) => [row.id, zeneMapper(row)]));

      const schedule = (Array.isArray(scheduleRows) ? scheduleRows : []).map((item) => ({
        ...orarendMapper(item),
        song: songsById.get(item.zeneid) || null,
      }));

      return { success: true, schedule };
    } catch (hiba) {
      return { success: false, error: hiba.message, schedule: [] };
    }
  },

  registerUser: async (adatok) => {
    try {
      const valasz = await apiFetch('/nemnormalfelhasznaloregisztracio', {
        method: 'POST',
        body: JSON.stringify({
          email: adatok.email,
          jelszo: encodeBase64Utf8(adatok.password),
          keresztnev: adatok.keresztnev,
          vezeteknev: adatok.vezeteknev,
          omazonosito: adatok.omazonosito || '',
          jog: roleToJog(adatok.role),
        }),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('Felhasználó létrehozva.', 'User created.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  deleteUserByEmail: async (email) => {
    try {
      const valasz = await apiFetch(`/felhasznalotorlese/${encodeURIComponent(email)}`, {
        method: 'DELETE',
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('Felhasználó törölve.', 'User deleted.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  logoutUserByEmail: async (email) => {
    try {
      const valasz = await apiFetch(`/kileptetesemailalapjan/${encodeURIComponent(email)}`);

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('Felhasználó kiléptetve.', 'User signed out.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  validateRequestById: async (id) => {
    try {
      const valasz = await apiFetch(`/zenevalidacio/${id}`, {
        method: 'POST',
        body: JSON.stringify({}),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('A kérés jóváhagyva lett.', 'Request approved.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  getUsers: async () => {
    try {
      const [felhasznalokValasz, aktivFelhasznalokValasz] = await Promise.all([
        apiFetch('/osszesfelhasznalokilistazasa'),
        apiFetch('/jelenlegbejelentkezettfelhasznalok').catch(() => null),
      ]);

      if (!felhasznalokValasz.ok) {
        const szoveg = await felhasznalokValasz.text().catch(() => '');
        return { success: false, users: [], error: szuroHibaSzoveg(szoveg, felhasznalokValasz.status) };
      }

      const [felhasznalok, aktivFelhasznalok] = await Promise.all([
        felhasznalokValasz.json().catch(() => []),
        aktivFelhasznalokValasz && aktivFelhasznalokValasz.ok
          ? aktivFelhasznalokValasz.json().catch(() => [])
          : Promise.resolve([]),
      ]);

      const mergedActiveUsers = mergeActiveUsersWithLocalSession(aktivFelhasznalok);
      const activeUsersByEmail = new Map(
        mergedActiveUsers
          .filter((item) => normalizeActiveUserEmail(item))
          .map((item) => [normalizeActiveUserEmail(item), item])
      );

      return {
        success: true,
        users: (Array.isArray(felhasznalok) ? felhasznalok : []).map((item) => ({
          ...felhasznaloMapper(item),
          active: activeUsersByEmail.has(normalizeActiveUserEmail(item)),
          lastLoginAt: deriveLastLoginAt(activeUsersByEmail.get(normalizeActiveUserEmail(item))),
        })),
      };
    } catch (hiba) {
      return { success: false, users: [], error: hiba.message };
    }
  },

  updateUser: async (email, adatok) => {
    try {
      const payload = {};

      if (adatok.email && adatok.email !== email) payload.email = adatok.email;
      if (adatok.keresztnev) payload.keresztnev = adatok.keresztnev;
      if (adatok.vezeteknev) payload.vezeteknev = adatok.vezeteknev;
      if (adatok.omazonosito !== undefined) payload.omazonosito = adatok.omazonosito;
      if (adatok.jog !== undefined) payload.jog = Number(adatok.jog);
      if (adatok.emailverifikalva !== undefined) payload.emailverifikalva = adatok.emailverifikalva ? 1 : 0;
      if (adatok.password) payload.jelszo = encodeBase64Utf8(adatok.password);

      const valasz = await apiFetch(`/felhasznaloadatokfrissit/${encodeURIComponent(email)}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('A felhasználó frissítve lett.', 'The user has been updated.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  updateUserRole: async (email, role) => adminAPI.updateUser(email, { jog: roleToJog(role) }),

  getSubmissions: async () => {
    try {
      const valasz = await apiFetch('/varolista');

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, submissions: [], error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      const adatok = await valasz.json().catch(() => []);
      return {
        success: true,
        submissions: (Array.isArray(adatok) ? adatok : []).map(adminSubmissionMapper),
      };
    } catch (hiba) {
      return { success: false, submissions: [], error: hiba.message };
    }
  },

  approveSubmission: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem ad közvetlen műveletet a várólistás elem jóváhagyására.', 'The backend does not provide a direct action to approve a queued submission.') }),
  rejectSubmission: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem ad közvetlen műveletet a várólistás elem elutasítására.', 'The backend does not provide a direct action to reject a queued submission.') }),

  getRequests: async () => {
    try {
      const valasz = await apiFetch('/kereseklistazasa');

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, requests: [], error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      const adatok = await valasz.json().catch(() => []);
      return {
        success: true,
        requests: (Array.isArray(adatok) ? adatok : []).map(adminRequestMapper),
      };
    } catch (hiba) {
      return { success: false, requests: [], error: hiba.message };
    }
  },

  approveRequest: async (id) => adminAPI.validateRequestById(id),
  rejectRequest: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a kérések admin oldali elutasítását.', 'The backend does not support rejecting requests from the admin panel.') }),
  setPlaying: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a kérések lejátszási állapotának közvetlen kezelését.', 'The backend does not support directly changing the playback state of requests.') }),
  setCompleted: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a lejátszási állapot lezárását.', 'The backend does not support marking playback as completed.') }),
  reorderRequest: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a kérési sorrend módosítását.', 'The backend does not support changing the request order.') }),
  deleteRequest: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a kéréslista alapú törlést.', 'The backend does not support deleting requests from the request list.') }),
  getConversionStatus: () => Promise.resolve({ success: false, conversions: [], error: lokalizaltSzoveg('A backend nem szolgáltat konvertálási állapotlistát.', 'The backend does not provide a conversion status list.') }),
  retryConversion: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend nem támogatja a konvertálás újraindítását.', 'The backend does not support restarting the conversion.') }),

  getBreaks: async () => {
    try {
      const valasz = await apiFetch('/szuneteklistaja');

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, breaks: [], error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      const adatok = await valasz.json().catch(() => []);
      return {
        success: true,
        breaks: (Array.isArray(adatok) ? adatok : [])
          .map(adminBreakMapper)
          .sort((left, right) => left.sequence - right.sequence),
      };
    } catch (hiba) {
      return { success: false, breaks: [], error: hiba.message };
    }
  },

  createBreak: async (adatok) => {
    try {
      const valasz = await apiFetch('/szunethozzaadas', {
        method: 'POST',
        body: JSON.stringify({
          hanyadik: Number(adatok.sequence),
          kezdes: adatok.start,
          vege: adatok.end,
        }),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('A szünet létrehozva.', 'Break created.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  updateBreak: async (sequence, adatok) => {
    try {
      const payload = {};
      if (adatok.start) payload.kezdes = adatok.start;
      if (adatok.end) payload.vege = adatok.end;

      const valasz = await apiFetch(`/szunetmodositas/${encodeURIComponent(sequence)}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('A szünet frissítve lett.', 'Break updated.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  deleteBreak: async (sequence) => {
    try {
      const valasz = await apiFetch(`/szunettorles/${encodeURIComponent(sequence)}`, {
        method: 'DELETE',
      });

      if (!valasz.ok) {
        const szoveg = await valasz.text().catch(() => '');
        return { success: false, error: szuroHibaSzoveg(szoveg, valasz.status) };
      }

      return { success: true, message: lokalizaltSzoveg('A szünet törölve lett.', 'Break deleted.') };
    } catch (hiba) {
      return { success: false, error: hiba.message };
    }
  },

  updateBreaks: () => Promise.resolve({ success: false, error: lokalizaltSzoveg('A backend csak egyes szünetek létrehozását, frissítését és törlését támogatja.', 'The backend only supports creating, updating, and deleting breaks one by one.') }),
  mapRoleFromJog: jogToRole,
  mapJogFromRole: roleToJog,
};

export default apiFetch;

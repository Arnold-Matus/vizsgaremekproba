import appLogo from '../assets/images/picilogo.ico';

const AppLogo = ({ className = '', alt = 'SuliRadio logo', decorative = false }) => (
  <img
    src={appLogo}
    alt={decorative ? '' : alt}
    aria-hidden={decorative ? 'true' : undefined}
    className={`app-logo-image${className ? ` ${className}` : ''}`}
    draggable="false"
  />
);

export default AppLogo;
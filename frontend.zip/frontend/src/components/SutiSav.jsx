﻿import { useState } from 'react';
import { X, Cookie, Settings, Shield, Check } from 'lucide-react';
import { useCookies } from '../contexts/SutiKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const CookieBanner = () => {
  const { showBanner, acceptAll, acceptNecessary, updateConsent } = useCookies();
  const { language } = useI18n();
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true,
    preferences: true,
    statistics: true,
    marketing: false
  });
  const tr = (hu, en) => (language === 'en' ? en : hu);

  if (!showBanner) return null;

  const handlePreferenceChange = (key) => {
    if (key === 'necessary') return;
    setPreferences(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSavePreferences = () => {
    updateConsent(preferences);
  };

  return (
    <div className="cookie-banner" role="dialog" aria-labelledby="cookie-title" aria-modal="true">
      <div className="cookie-banner-content">
        <div className="cookie-banner-header">
          <Cookie size={24} className="cookie-icon" aria-hidden="true" />
          <h2 id="cookie-title" className="cookie-title">{tr('Cookie beállítások', 'Cookie settings')}</h2>
        </div>

        {!showDetails ? (
          <>
            <p className="cookie-text">
              {tr('Ez a weboldal sütiket (cookie-kat) használ a jobb felhasználói élmény érdekében. A sütik segítenek a bejelentkezésben, a beállítások mentésében és a weboldal fejlesztésében. Az Európai Unió GDPR rendelete értelmében a beleegyezésedet kérjük.', 'This website uses cookies to improve your experience. Cookies help with sign-in, saving your settings, and improving the site. Under the GDPR rules of the European Union, we ask for your consent.')}
            </p>
            <div className="cookie-actions">
              <button 
                className="cookie-btn cookie-btn-secondary"
                onClick={() => setShowDetails(true)}
              >
                <Settings size={18} />
                {tr('Testreszabás', 'Customize')}
              </button>
              <button 
                className="cookie-btn cookie-btn-outline"
                onClick={acceptNecessary}
              >
                {tr('Csak szükséges', 'Necessary only')}
              </button>
              <button 
                className="cookie-btn cookie-btn-primary"
                onClick={acceptAll}
              >
                <Check size={18} />
                {tr('Összes elfogadása', 'Accept all')}
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="cookie-details">
              <div className="cookie-category">
                <div className="cookie-category-header">
                  <div className="cookie-category-info">
                    <Shield size={20} aria-hidden="true" />
                    <div>
                      <h3>{tr('Szükséges sütik', 'Necessary cookies')}</h3>
                      <p>{tr('Ezek a sütik elengedhetetlenek a weboldal működéséhez.', 'These cookies are required for the website to work.')}</p>
                    </div>
                  </div>
                  <label className="cookie-toggle disabled">
                    <input 
                      type="checkbox" 
                      checked={preferences.necessary}
                      disabled
                      aria-label={tr('Szükséges sütik (mindig aktív)', 'Necessary cookies (always active)')}
                    />
                    <span className="cookie-toggle-slider"></span>
                  </label>
                </div>
              </div>

              <div className="cookie-category">
                <div className="cookie-category-header">
                  <div className="cookie-category-info">
                    <Settings size={20} aria-hidden="true" />
                    <div>
                      <h3>{tr('Preferencia sütik', 'Preference cookies')}</h3>
                      <p>{tr('Beállításaid mentéséhez, mint a sötét mód vagy betűméret.', 'Used to save your settings, such as dark mode or font size.')}</p>
                    </div>
                  </div>
                  <label className="cookie-toggle">
                    <input 
                      type="checkbox" 
                      checked={preferences.preferences}
                      onChange={() => handlePreferenceChange('preferences')}
                      aria-label={tr('Preferencia sütik engedélyezése', 'Enable preference cookies')}
                    />
                    <span className="cookie-toggle-slider"></span>
                  </label>
                </div>
              </div>

              <div className="cookie-category">
                <div className="cookie-category-header">
                  <div className="cookie-category-info">
                    <Cookie size={20} aria-hidden="true" />
                    <div>
                      <h3>{tr('Statisztikai sütik', 'Analytics cookies')}</h3>
                      <p>{tr('Segítenek megérteni, hogyan használják a látogatók a weboldalt.', 'They help us understand how visitors use the website.')}</p>
                    </div>
                  </div>
                  <label className="cookie-toggle">
                    <input 
                      type="checkbox" 
                      checked={preferences.statistics}
                      onChange={() => handlePreferenceChange('statistics')}
                      aria-label={tr('Statisztikai sütik engedélyezése', 'Enable analytics cookies')}
                    />
                    <span className="cookie-toggle-slider"></span>
                  </label>
                </div>
              </div>
            </div>

            <div className="cookie-actions">
              <button 
                className="cookie-btn cookie-btn-secondary"
                onClick={() => setShowDetails(false)}
              >
                {tr('Vissza', 'Back')}
              </button>
              <button 
                className="cookie-btn cookie-btn-primary"
                onClick={handleSavePreferences}
              >
                <Check size={18} />
                {tr('Beállítások mentése', 'Save settings')}
              </button>
            </div>
          </>
        )}

        <p className="cookie-privacy-link">
          {tr('További információ az', 'More information in the')} <a href="/privacy">{tr('Adatvédelmi tájékoztatóban', 'Privacy Notice')}</a>.
        </p>
      </div>
    </div>
  );
};

export default CookieBanner;

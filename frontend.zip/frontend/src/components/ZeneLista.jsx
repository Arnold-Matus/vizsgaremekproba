﻿import { useState } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  CheckSquare,
  Square,
  Music,
  Clock,
  Calendar,
  TrendingUp,
  User,
  Play,
  Heart,
  MoreVertical,
  Send,
  X,
  Loader2,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { useMusic } from '../contexts/ZeneKontextus';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const SongList = () => {
  const {
    searchQuery,
    setSearchQuery,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
    filterGenre,
    setFilterGenre,
    genres,
    filteredSongs,
    selectedSongs,
    toggleSongSelection,
    selectAllSongs,
    clearSelection,
    requestSongs,
    formatDuration
  } = useMusic();

  const { user, isLoggedIn, addToFavorites, removeFromFavorites } = useUser();
  const { language } = useI18n();
  const [showFilters, setShowFilters] = useState(false);
  const [requestMessage, setRequestMessage] = useState('');
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const songs = filteredSongs();
  const hasSelection = selectedSongs.length > 0;
  const allSelected = songs.length > 0 && selectedSongs.length === songs.length;

  const handleRequestSongs = async () => {
    if (!isLoggedIn) {
      setRequestMessage(tr('Kérlek jelentkezz be a zenék kéréséhez!', 'Please sign in to request songs.'));
      setTimeout(() => setRequestMessage(''), 3000);
      return;
    }
    if (selectedSongs.length === 0) {
      setRequestMessage(tr('Válassz ki legalább egy zenét!', 'Select at least one song.'));
      setTimeout(() => setRequestMessage(''), 3000);
      return;
    }

    try {
      const result = await requestSongs(selectedSongs, user?.id);
      setRequestMessage(result?.message || tr(`${selectedSongs.length} zene sikeresen kérve!`, `${selectedSongs.length} songs requested successfully!`));
    } catch (error) {
      setRequestMessage(error.message || tr('A zenekérés nem sikerült.', 'Song request failed.'));
    }

    setTimeout(() => setRequestMessage(''), 3000);
  };

  const toggleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const getSortIcon = (field) => {
    if (sortBy !== field) return <ArrowUpDown size={14} className="sort-icon inactive" />;
    return sortOrder === 'asc' 
      ? <ArrowUp size={14} className="sort-icon active" />
      : <ArrowDown size={14} className="sort-icon active" />;
  };

  const isFavorite = (songId) => {
    return user?.favorites?.includes(songId);
  };

  const handleFavoriteToggle = (e, songId) => {
    e.stopPropagation();
    if (!isLoggedIn) return;
    if (isFavorite(songId)) {
      removeFromFavorites(songId);
    } else {
      addToFavorites(songId);
    }
  };

  return (
    <div className="song-list-container">
      {/* Search and filter bar */}
      <div className="song-list-header">
        <div className="search-container">
          <Search size={20} className="search-icon" aria-hidden="true" />
          <input
            type="search"
            placeholder={tr('Keresés cím, előadó, album vagy műfaj alapján...', 'Search by title, artist, album, or genre...')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
            aria-label={tr('Zenék keresése', 'Search songs')}
          />
          {searchQuery && (
            <button 
              className="search-clear"
              onClick={() => setSearchQuery('')}
              aria-label={tr('Keresés törlése', 'Clear search')}
            >
              <X size={18} />
            </button>
          )}
        </div>

        <button
          className={`filter-toggle ${showFilters ? 'active' : ''}`}
          onClick={() => setShowFilters(!showFilters)}
          aria-expanded={showFilters}
          aria-label={tr('Szűrők megjelenítése', 'Show filters')}
        >
          <SlidersHorizontal size={20} />
          <span>{tr('Szűrők', 'Filters')}</span>
        </button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="filters-panel" role="region" aria-label={tr('Szűrési beállítások', 'Filter settings')}>
          <div className="filter-group">
            <label htmlFor="genre-filter" className="filter-label">{tr('Műfaj', 'Genre')}</label>
            <select
              id="genre-filter"
              value={filterGenre}
              onChange={(e) => setFilterGenre(e.target.value)}
              className="filter-select"
            >
              <option value="all">{tr('Összes műfaj', 'All genres')}</option>
              {genres.map(genre => (
                <option key={genre} value={genre}>{genre}</option>
              ))}
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="sort-by" className="filter-label">{tr('Rendezés', 'Sort by')}</label>
            <select
              id="sort-by"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="filter-select"
            >
              <option value="title">{tr('Cím', 'Title')}</option>
              <option value="artist">{tr('Előadó', 'Artist')}</option>
              <option value="duration">{tr('Hossz', 'Length')}</option>
              <option value="uploadDate">{tr('Feltöltés dátuma', 'Upload date')}</option>
              <option value="requestCount">{tr('Népszerűség', 'Popularity')}</option>
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="sort-order" className="filter-label">{tr('Sorrend', 'Order')}</label>
            <select
              id="sort-order"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
              className="filter-select"
            >
              <option value="asc">{tr('Növekvő', 'Ascending')}</option>
              <option value="desc">{tr('Csökkenő', 'Descending')}</option>
            </select>
          </div>
        </div>
      )}

      {/* Selection toolbar */}
      {hasSelection && (
        <div className="selection-toolbar" role="toolbar" aria-label={tr('Kiválasztott zenék műveletek', 'Selected song actions')}>
          <div className="selection-info">
            <CheckSquare size={18} />
            <span>{tr(`${selectedSongs.length} zene kiválasztva`, `${selectedSongs.length} songs selected`)}</span>
          </div>
          <div className="selection-actions">
            <button className="selection-btn" onClick={clearSelection}>
              <X size={18} />
              {tr('Kijelölés törlése', 'Clear selection')}
            </button>
            <button className="selection-btn primary" onClick={handleRequestSongs}>
              <Send size={18} />
              {tr('Kiválasztottak kérése', 'Request selected')}
            </button>
          </div>
        </div>
      )}

      {/* Request message */}
      {requestMessage && (
        <div className={`request-message ${requestMessage.includes('sikeresen') ? 'success' : 'warning'}`} role="alert">
          {requestMessage}
        </div>
      )}

      {/* Song table */}
      <div className="song-table-wrapper">
        <table className="song-table" role="grid" aria-label={tr('Zenék listája', 'Song list')}>
          <thead>
            <tr>
              <th className="th-checkbox">
                <button
                  className="select-all-btn"
                  onClick={allSelected ? clearSelection : selectAllSongs}
                  aria-label={allSelected ? tr('Összes kijelölés törlése', 'Clear all selections') : tr('Összes kijelölése', 'Select all')}
                >
                  {allSelected ? <CheckSquare size={18} /> : <Square size={18} />}
                </button>
              </th>
              <th className="th-title">
                <button className="sort-btn" onClick={() => toggleSort('title')}>
                  <Music size={16} />
                  <span>{tr('Cím', 'Title')}</span>
                  {getSortIcon('title')}
                </button>
              </th>
              <th className="th-artist">
                <button className="sort-btn" onClick={() => toggleSort('artist')}>
                  <User size={16} />
                  <span>{tr('Előadó', 'Artist')}</span>
                  {getSortIcon('artist')}
                </button>
              </th>
              <th className="th-duration">
                <button className="sort-btn" onClick={() => toggleSort('duration')}>
                  <Clock size={16} />
                  <span>{tr('Hossz', 'Length')}</span>
                  {getSortIcon('duration')}
                </button>
              </th>
              <th className="th-genre">
                <span>{tr('Műfaj', 'Genre')}</span>
              </th>
              <th className="th-date">
                <button className="sort-btn" onClick={() => toggleSort('uploadDate')}>
                  <Calendar size={16} />
                  <span>{tr('Feltöltve', 'Uploaded')}</span>
                  {getSortIcon('uploadDate')}
                </button>
              </th>
              <th className="th-popularity">
                <button className="sort-btn" onClick={() => toggleSort('requestCount')}>
                  <TrendingUp size={16} />
                  <span>{tr('Kérések', 'Requests')}</span>
                  {getSortIcon('requestCount')}
                </button>
              </th>
              <th className="th-status">
                <span>{tr('Státusz', 'Status')}</span>
              </th>
              <th className="th-actions">
                <span className="visually-hidden">{tr('Műveletek', 'Actions')}</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {songs.length === 0 ? (
              <tr>
                <td colSpan="9" className="no-results">
                  <Music size={48} />
                  <p>
                    {searchQuery 
                      ? tr('Nincs találat a keresési feltételeknek megfelelően.', 'No songs match the current search.')
                      : tr('A könyvtár jelenleg üres. Küldj be zenéket a "Zene hozzáadása" oldalon!', 'The library is currently empty. Submit songs on the "Add song" page!')
                    }
                  </p>
                </td>
              </tr>
            ) : (
              songs.map(song => (
                <tr 
                  key={song.id} 
                  className={`song-row ${selectedSongs.includes(song.id) ? 'selected' : ''}`}
                  onClick={() => toggleSongSelection(song.id)}
                >
                  <td className="td-checkbox">
                    <button
                      className="checkbox-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSongSelection(song.id);
                      }}
                      aria-label={selectedSongs.includes(song.id) ? tr(`${song.title} kijelölés törlése`, `Remove ${song.title} from selection`) : tr(`${song.title} kijelölése`, `Select ${song.title}`)}
                    >
                      {selectedSongs.includes(song.id) ? (
                        <CheckSquare size={18} className="checked" />
                      ) : (
                        <Square size={18} />
                      )}
                    </button>
                  </td>
                  <td className="td-title">
                    <div className="song-title-cell">
                      <div className="song-cover">
                        {song.coverUrl ? (
                          <img src={song.coverUrl} alt="" />
                        ) : (
                          <Music size={20} />
                        )}
                        <div className="song-cover-overlay">
                          <Play size={16} />
                        </div>
                      </div>
                      <div className="song-info">
                        <span className="song-title">{song.title}</span>
                        <span className="song-album">{song.album}</span>
                      </div>
                    </div>
                  </td>
                  <td className="td-artist">{song.artist}</td>
                  <td className="td-duration">{formatDuration(song.duration)}</td>
                  <td className="td-genre">
                    <span className="genre-badge">{song.genre}</span>
                  </td>
                  <td className="td-date">
                    {new Date(song.uploadDate).toLocaleDateString(language === 'en' ? 'en-GB' : 'hu-HU')}
                  </td>
                  <td className="td-popularity">
                    <div className="popularity-bar">
                      <div 
                        className="popularity-fill" 
                        style={{ width: `${Math.min(song.requestCount / 2.5, 100)}%` }}
                      />
                      <span>{song.requestCount}</span>
                    </div>
                  </td>
                  <td className="td-status">
                    {song.conversionStatus === 'completed' ? (
                      <span className="conversion-badge completed">
                        <CheckCircle size={12} /> {tr('Kész', 'Ready')}
                      </span>
                    ) : song.conversionStatus === 'processing' ? (
                      <span className="conversion-badge processing">
                        <Loader2 size={12} className="spinning" /> {tr('Feldolgozás', 'Processing')}
                      </span>
                    ) : song.conversionStatus === 'failed' ? (
                      <span className="conversion-badge failed">
                        <AlertCircle size={12} /> {tr('Hiba', 'Error')}
                      </span>
                    ) : (
                      <span className="conversion-badge pending">
                        <Clock size={12} /> {tr('Várakozik', 'Pending')}
                      </span>
                    )}
                  </td>
                  <td className="td-actions">
                    <button
                      className={`action-btn favorite ${isFavorite(song.id) ? 'active' : ''}`}
                      onClick={(e) => handleFavoriteToggle(e, song.id)}
                      aria-label={isFavorite(song.id) ? tr('Eltávolítás a kedvencekből', 'Remove from favorites') : tr('Hozzáadás a kedvencekhez', 'Add to favorites')}
                      disabled={!isLoggedIn}
                    >
                      <Heart size={18} fill={isFavorite(song.id) ? 'currentColor' : 'none'} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Results count */}
      <div className="song-list-footer">
        <p className="results-count">
          {tr(`${songs.length} zene találat`, `${songs.length} song results`)}
          {searchQuery && tr(` "${searchQuery}" keresésre`, ` for "${searchQuery}"`)}
        </p>
      </div>
    </div>
  );
};

export default SongList;

import { Globe } from 'lucide-react';
import { useI18n } from '../contexts/NyelvKontextus';

const LanguageToggle = ({ compact = false, className = '' }) => {
  const { language, setLanguage } = useI18n();
  const label = language === 'hu' ? 'Nyelv kiválasztása' : 'Choose language';

  return (
    <div className={`language-toggle ${compact ? 'compact' : ''} ${className}`.trim()} role="group" aria-label={label}>
      <Globe size={compact ? 14 : 16} aria-hidden="true" />
      <button
        type="button"
        className={`language-toggle-option ${language === 'hu' ? 'active' : ''}`}
        onClick={() => setLanguage('hu')}
        aria-pressed={language === 'hu'}
      >
        HU
      </button>
      <span className="language-toggle-separator" aria-hidden="true">/</span>
      <button
        type="button"
        className={`language-toggle-option ${language === 'en' ? 'active' : ''}`}
        onClick={() => setLanguage('en')}
        aria-pressed={language === 'en'}
      >
        EN
      </button>
    </div>
  );
};

export default LanguageToggle;
﻿import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Mail, 
  MapPin, 
  Phone,
  Heart,
  Coffee
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL } from '../constants/appInfo';
import AppLogo from './AppLogo';

const Footer = () => {
  const { sessionToken, user } = useUser();
  const { t } = useI18n();
  const [showToken, setShowToken] = useState(false);

  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer" role="contentinfo">
      <div className="footer-main">
        <div className="footer-container">
          {/* Brand section */}
          <div className="footer-section footer-brand">
            <Link to="/" className="footer-logo">
              <span className="footer-logo-icon" aria-hidden="true">
                <AppLogo className="app-logo-image" decorative />
              </span>
              <span>SuliRadio</span>
            </Link>
            <p className="footer-description">
              {t('footer.description')}
            </p>
            <div className="footer-social">
            </div>
          </div>

          {/* Quick links */}
          <div className="footer-section">
            <h3 className="footer-section-title">{t('footer.quickLinks')}</h3>
            <nav aria-label={t('footer.navigationAria')}>
              <ul className="footer-links">
                <li><Link to="/">{t('nav.home')}</Link></li>
                <li><Link to="/musorrend">{t('footer.schedule')}</Link></li>
                <li><Link to="/zene-keres">{t('footer.requestMusic')}</Link></li>
                <li><Link to="/rolunk">{t('footer.about')}</Link></li>
                <li><Link to="/segitseg">{t('footer.help')}</Link></li>
              </ul>
            </nav>
          </div>

          {/* Legal */}
          <div className="footer-section">
            <h3 className="footer-section-title">{t('footer.info')}</h3>
            <ul className="footer-links">
              <li><Link to="/adatvedelem">{t('footer.privacy')}</Link></li>
              <li><Link to="/sutik">{t('footer.cookieSettings')}</Link></li>
              <li><Link to="/akadalymentes">{t('footer.accessibility')}</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="footer-section">
            <h3 className="footer-section-title">{t('footer.contact')}</h3>
            <ul className="footer-contact">
              <li>
                <MapPin size={16} aria-hidden="true" />
                <span>5600 Békéscsaba, Kazinczy u. 7.</span>
              </li>
              <li>
                <Mail size={16} aria-hidden="true" />
                <a href={`mailto:${RADIO_EMAIL}`}>{RADIO_EMAIL}</a>
              </li>
              <li>
                <Phone size={16} aria-hidden="true" />
                <span>+36 66 441 459</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Session info */}
        {(sessionToken || user) && (
          <div className="footer-session">
            {sessionToken && (
              <div className="footer-session-item">
                <span className="footer-session-label">{t('footer.session')}</span>
                <button 
                  className="footer-session-toggle"
                  onClick={() => setShowToken(!showToken)}
                  aria-expanded={showToken}
                >
                  {showToken ? (
                    <code className="footer-session-value">{sessionToken}</code>
                  ) : (
                    <span>••••••••••••</span>
                  )}
                </button>
              </div>
            )}
            {user && (
              <div className="footer-session-item">
                <span className="footer-session-label">{t('footer.userId')}</span>
                <code className="footer-session-value">{user.id}</code>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Copyright */}
      <div className="footer-bottom">
        <div className="footer-container">
          <p className="footer-copyright">
            © {currentYear} SuliRadio - {t('footer.copyrightSuffix')}
          </p>
          <p className="footer-made-with">
            {t('footer.country')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

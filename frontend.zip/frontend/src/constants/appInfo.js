export const SCHOOL_NAME = 'Békéscsabai Nemes Tihamér Technikum';
export const RADIO_EMAIL = 'suliradio004@gmail.com';
export const SCHOOL_EMAIL = 'nemes@bszc.hu';

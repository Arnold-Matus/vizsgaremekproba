import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { DEFAULT_USER_PREFERENCES, authAPI, authSessionConfig, cancelPendingLogout, clearAuthToken, closeAuthSessionOnPageExit, favoritesAPI, flushPendingLogout, getAuthToken, preferencesAPI, sanitizeUserPreferences, setAuthFlashMessage, setAuthToken } from '../services/api';

const UserContext = createContext();

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [preferences, setPreferences] = useState(DEFAULT_USER_PREFERENCES);
  const [loading, setLoading] = useState(true);
  const inactivityTimerRef = useRef(null);
  const preferencesRef = useRef(DEFAULT_USER_PREFERENCES);

  const tr = useCallback((hu, en) => (preferencesRef.current?.language === 'en' ? en : hu), []);

  useEffect(() => {
    preferencesRef.current = preferences;
  }, [preferences]);

  const mergePreferencesWithCurrentLanguage = useCallback((incomingPreferences) => {
    const currentLanguage = preferencesRef.current?.language === 'en' ? 'en' : 'hu';
    return sanitizeUserPreferences({
      ...(incomingPreferences || {}),
      language: currentLanguage,
    });
  }, []);

  useEffect(() => {
    const handleUserStateUpdate = (event) => {
      if (!event.detail) return;
      setUser(event.detail);
      setPreferences(sanitizeUserPreferences(event.detail.preferences));
    };

    window.addEventListener('suliradio:user-state-updated', handleUserStateUpdate);
    return () => {
      window.removeEventListener('suliradio:user-state-updated', handleUserStateUpdate);
    };
  }, [mergePreferencesWithCurrentLanguage]);

  useEffect(() => {
    const token = sessionStorage.getItem('suliradio-token');
    localStorage.removeItem('suliradio-token');

    if (!token) {
      Promise.allSettled([flushPendingLogout(), preferencesAPI.get()])
        .then(([, preferencesResult]) => {
          const nextPreferences = preferencesResult.status === 'fulfilled'
            ? sanitizeUserPreferences(preferencesResult.value.preferences)
            : DEFAULT_USER_PREFERENCES;
          setPreferences(nextPreferences);
        })
        .finally(() => {
          setLoading(false);
        });
      return undefined;
    }

    if (token) {
      cancelPendingLogout();
      authAPI.me()
        .then(data => {
          if (data.success) {
            setUser(data.user);
            setIsLoggedIn(true);
            setPreferences(sanitizeUserPreferences(data.user?.preferences));
          } else {
            clearAuthToken();
          }
        })
        .catch(() => {
          clearAuthToken();
        })
        .finally(() => setLoading(false));
    }
    return undefined;
  }, [mergePreferencesWithCurrentLanguage]);

  useEffect(() => {
    if (!user?.preferences) return;
    setPreferences(sanitizeUserPreferences(user.preferences));
  }, [user?.preferences]);

  const register = async (userData) => {
    try {
      const data = await authAPI.register(userData);
      if (data.success) {
        return { success: true };
      }
      return { success: false, error: data.error || tr('Hiba történt a regisztráció során!', 'An error occurred during registration!') };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const login = async (identifier, password) => {
    try {
      const data = await authAPI.login(identifier, password);
      if (data.success) {
        const nextPreferences = mergePreferencesWithCurrentLanguage(data.user?.preferences);
        const persistedPreferences = await preferencesAPI.update(nextPreferences);
        const nextUser = persistedPreferences.user || { ...data.user, preferences: nextPreferences };
        setAuthToken(data.token);
        setUser(nextUser);
        setIsLoggedIn(true);
        setPreferences(nextPreferences);
        return { success: true, user: nextUser };
      }
      return { success: false, error: data.error };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const logout = useCallback(async ({ redirectToLogin = true } = {}) => {
    const guestPreferences = sanitizeUserPreferences(preferencesRef.current);

    try {
      await authAPI.logout();
    } catch {

    }
    clearAuthToken();
    setUser(null);
    setIsLoggedIn(false);
    setPreferences(guestPreferences);
    try {
      await preferencesAPI.update(guestPreferences);
    } catch {

    }
    if (redirectToLogin && window.location.pathname !== '/bejelentkezes') {
      window.location.assign('/bejelentkezes');
    }
  }, []);

  const clearInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) {
      window.clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
  }, []);

  const resetInactivityTimer = useCallback(() => {
    if (!isLoggedIn) return;

    clearInactivityTimer();
    inactivityTimerRef.current = window.setTimeout(() => {
      setAuthFlashMessage(tr(
        'Inaktivitás miatt kijelentkeztettünk. Kérlek jelentkezz be újra.',
        'You were signed out due to inactivity. Please sign in again.'
      ));
      logout();
    }, authSessionConfig.inactivityTimeoutMs);
  }, [clearInactivityTimer, isLoggedIn, logout, tr]);

  const demoLogin = useCallback(async () => {
    try {
      const data = await authAPI.demoLogin();
      if (data.success) {
        const nextPreferences = mergePreferencesWithCurrentLanguage(data.user?.preferences);
        const persistedPreferences = await preferencesAPI.update(nextPreferences);
        const nextUser = persistedPreferences.user || { ...data.user, preferences: nextPreferences };
        setAuthToken(data.token);
        setUser(nextUser);
        setIsLoggedIn(true);
        setPreferences(nextPreferences);
        return { success: true, user: nextUser };
      }
      return { success: false, error: data.error || tr('Demo bejelentkezés sikertelen!', 'Demo sign-in failed!') };
    } catch (error) {
      return { success: false, error: error.message || tr('Nem sikerült csatlakozni a szerverhez.', 'Could not connect to the server.') };
    }
  }, [mergePreferencesWithCurrentLanguage, tr]);

  const updateUser = useCallback(async (updates) => {
    try {
      const data = await authAPI.updateProfile(updates);
      if (data.success) {
        setUser(data.user);
        return { success: true, user: data.user };
      }
      return { success: false, error: data.error || tr('Nem sikerült frissíteni a profilt.', 'Could not update the profile.') };
    } catch {
      return { success: false, error: tr('Nem sikerült frissíteni a profilt.', 'Could not update the profile.') };
    }
  }, [tr]);

  const updatePreferences = useCallback(async (preferences) => {
    const previousPreferences = preferencesRef.current;
    const nextPreferences = sanitizeUserPreferences({
      ...previousPreferences,
      ...(preferences || {}),
    });

    setPreferences(nextPreferences);

    try {
      const data = await preferencesAPI.update(nextPreferences);
      if (data.success && data.user) {
        setUser(data.user);
      }
      if (!data.success) {
        setPreferences(previousPreferences);
        return data;
      }

      const persistedPreferences = sanitizeUserPreferences(data.preferences || nextPreferences);
      setPreferences(persistedPreferences);
      return { ...data, preferences: persistedPreferences };
    } catch {
      setPreferences(previousPreferences);
      return { success: false, error: tr('Nem sikerült menteni a beállításokat.', 'Could not save the settings.') };
    }
  }, [tr]);

  const addToFavorites = useCallback(async (songId) => {
    try {
      const data = await favoritesAPI.add(songId);
      if (data.success) {
        setUser(prev => prev ? { ...prev, favorites: data.favorites } : prev);
      }
    } catch {

    }
  }, []);

  const removeFromFavorites = useCallback(async (songId) => {
    try {
      const data = await favoritesAPI.remove(songId);
      if (data.success) {
        setUser(prev => prev ? { ...prev, favorites: data.favorites } : prev);
      }
    } catch {

    }
  }, []);

  const addToHistory = useCallback(() => {

  }, []);

  useEffect(() => {
    if (!isLoggedIn) {
      clearInactivityTimer();
      return undefined;
    }

    const handleActivity = () => {
      resetInactivityTimer();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        resetInactivityTimer();
      }
    };

    const handlePageHide = (event) => {
      if (event.persisted) return;
      closeAuthSessionOnPageExit();
    };

    const activityEvents = ['pointerdown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    activityEvents.forEach((eventName) => {
      window.addEventListener(eventName, handleActivity, { passive: true });
    });
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pagehide', handlePageHide);

    resetInactivityTimer();

    return () => {
      clearInactivityTimer();
      activityEvents.forEach((eventName) => {
        window.removeEventListener(eventName, handleActivity);
      });
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pagehide', handlePageHide);
    };
  }, [clearInactivityTimer, isLoggedIn, resetInactivityTimer]);

  return (
    <UserContext.Provider value={{
      user,
      sessionToken: getAuthToken(),
      preferences,
      isLoggedIn,
      loading,
      register,
      login,
      logout,
      demoLogin,
      updateUser,
      updatePreferences,
      addToFavorites,
      removeFromFavorites,
      addToHistory,
    }}>
      {children}
    </UserContext.Provider>
  );
};

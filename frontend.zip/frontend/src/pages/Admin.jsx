import { useCallback, useEffect, useMemo, useState } from 'react';
import DatePicker from 'react-datepicker';
import { enGB, hu } from 'date-fns/locale';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle,
  Edit2,
  ListChecks,
  Loader2,
  LogIn,
  LogOut,
  Music,
  Plus,
  RefreshCw,
  Save,
  Search,
  Shield,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import { adminAPI } from '../services/api';
import 'react-datepicker/dist/react-datepicker.css';

const EMPTY_SONG = {
  title: '',
  artist: '',
  duration: '',
  genre: '',
  sourceUrl: '',
  mp3Url: '',
  isAvailable: true,
};

const EMPTY_SCHEDULE = {
  zeneid: '',
  mikortol: '',
  meddig: '',
};

const EMPTY_USER_FORM = {
  vezeteknev: '',
  keresztnev: '',
  email: '',
  omazonosito: '',
  password: '',
  role: 'user',
};

const EMPTY_BREAK = {
  sequence: '',
  start: '',
  end: '',
};

const ROLE_OPTIONS = [
  { value: 'user', labelHu: 'Felhasználó', labelEn: 'User', jog: 2 },
  { value: 'tanar', labelHu: 'Tanár', labelEn: 'Teacher', jog: 3 },
  { value: 'admin', labelHu: 'Admin', labelEn: 'Admin', jog: 4 },
];

const toDateTimeLocalValue = (value) => {
  if (!value) return '';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';

  const adjusted = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return adjusted.toISOString().slice(0, 16);
};

const toPickerDate = (value) => {
  const normalizedValue = toDateTimeLocalValue(value);
  if (!normalizedValue) return null;

  const [datePart, timePart] = normalizedValue.split('T');
  if (!datePart || !timePart) return null;

  const [year, month, day] = datePart.split('-').map(Number);
  const [hour, minute] = timePart.split(':').map(Number);

  if ([year, month, day, hour, minute].some((part) => Number.isNaN(part))) {
    return null;
  }

  return new Date(year, month - 1, day, hour, minute);
};

const formatDateTime = (value, language = 'hu') => {
  if (!value) return '-';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString(language === 'en' ? 'en-GB' : 'hu-HU', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const formatDuration = (seconds) => {
  const totalSeconds = Number(seconds) || 0;
  const minutes = Math.floor(totalSeconds / 60);
  const remainder = totalSeconds % 60;
  return `${minutes}:${remainder.toString().padStart(2, '0')}`;
};

const formatRole = (role, language = 'hu', jog) => {
  if (role === 'admin') return 'Admin';
  if (Number(jog) === 1 || role === 'demo') return language === 'en' ? 'Demo' : 'Demo';
  if (role === 'tanar') return language === 'en' ? 'Teacher' : 'Tanár';
  return language === 'en' ? 'User' : 'Felhasználó';
};

const buildEditableUser = (user) => ({
  originalEmail: user.email,
  email: user.email,
  keresztnev: user.name?.split(' ').slice(1).join(' ') || '',
  vezeteknev: user.name?.split(' ')[0] || '',
  omazonosito: user.educationalId || '',
  jog: Number(user.jog) || 2,
  emailverifikalva: !!user.emailVerified,
  password: '',
});

const resolveRequestSong = (request, songsById, songs) => {
  if (request.songId && songsById.has(request.songId)) {
    return songsById.get(request.songId);
  }

  if (!request.songUrl) {
    return null;
  }

  return songs.find((song) => (
    song.sourceUrl === request.songUrl || song.mp3Url === request.songUrl
  )) || null;
};

const AdminPage = () => {
  const { user, isLoggedIn, loading: userLoading, logout } = useUser();
  const { language } = useI18n();
  const tr = useCallback((hu, en) => (language === 'en' ? en : hu), [language]);
  const dateInputPlaceholder = language === 'en' ? 'YYYY.MM.DD. HH:MM' : 'ÉÉÉÉ.HH.NN. ÓÓ:PP';
  const adminDateLocale = language === 'en' ? enGB : hu;
  const adminDateFormat = 'yyyy.MM.dd. HH:mm';
  const ui = useMemo(() => ({
    refresh: tr('Frissítés', 'Refresh'),
    save: tr('Mentés', 'Save'),
    cancel: tr('Mégse', 'Cancel'),
    delete: tr('Törlés', 'Delete'),
    edit: tr('Szerkesztés', 'Edit'),
    create: tr('Létrehozás', 'Create'),
    add: tr('Hozzáadás', 'Add'),
    close: tr('Bezárás', 'Close'),
    actions: tr('Műveletek', 'Actions'),
    yes: tr('Igen', 'Yes'),
    no: tr('Nem', 'No'),
  }), [tr]);

  const tableLabels = useMemo(() => ({
    songs: {
      title: tr('Cím', 'Title'),
      artist: tr('Előadó', 'Artist'),
      length: tr('Hossz', 'Length'),
      genre: tr('Műfaj', 'Genre'),
      mp3Path: tr('MP3 útvonal', 'MP3 path'),
      requests: tr('Kérések', 'Requests'),
      available: tr('Elérhető', 'Available'),
      actions: ui.actions,
    },
    schedule: {
      song: tr('Zene', 'Song'),
      start: tr('Kezdés', 'Start'),
      end: tr('Vége', 'End'),
      actions: ui.actions,
    },
    users: {
      name: tr('Név', 'Name'),
      email: 'Email',
      om: 'OM',
      role: tr('Szerepkör', 'Role'),
      verification: tr('Email ellenőrzés', 'Email verification'),
      status: tr('Állapot', 'Status'),
      actions: ui.actions,
    },
    requests: {
      id: 'ID',
      user: tr('Felhasználó', 'User'),
      song: tr('Zene', 'Song'),
      requested: tr('Kérve', 'Requested'),
      status: tr('Állapot', 'Status'),
      actions: ui.actions,
    },
    submissions: {
      title: tr('Cím', 'Title'),
      artist: tr('Előadó', 'Artist'),
      source: tr('Forrás', 'Source'),
      mp3Path: tr('MP3 útvonal', 'MP3 path'),
      requests: tr('Kérések', 'Requests'),
      recorded: tr('Rögzítve', 'Recorded'),
    },
    breaks: {
      sequence: tr('Sorszám', 'Sequence'),
      start: tr('Kezdés', 'Start'),
      end: tr('Vége', 'End'),
      actions: ui.actions,
    },
  }), [tr, ui.actions]);

  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState(null);

  const [dashboardData, setDashboardData] = useState(null);
  const [songs, setSongs] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [users, setUsers] = useState([]);
  const [requests, setRequests] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [breaks, setBreaks] = useState([]);

  const [songSearch, setSongSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [requestSearch, setRequestSearch] = useState('');
  const [submissionSearch, setSubmissionSearch] = useState('');

  const [showAddSong, setShowAddSong] = useState(false);
  const [newSong, setNewSong] = useState(EMPTY_SONG);
  const [editingSongId, setEditingSongId] = useState(null);
  const [editingSong, setEditingSong] = useState(null);

  const [newSchedule, setNewSchedule] = useState(EMPTY_SCHEDULE);
  const [userForm, setUserForm] = useState(EMPTY_USER_FORM);
  const [editableUser, setEditableUser] = useState(null);
  const [breakForm, setBreakForm] = useState(EMPTY_BREAK);
  const [editingBreakSequence, setEditingBreakSequence] = useState(null);

  const isAdmin = Boolean(user?.isAdmin || user?.role === 'admin' || Number(user?.jog) >= 4);

  const showMessage = useCallback((text, type = 'success') => {
    setMessage({ text, type });
    window.setTimeout(() => setMessage(null), 4500);
  }, []);

  const loadOverview = useCallback(async () => {
    const [overviewData, usersData, requestsData, scheduleData, submissionsData, breaksData, songsData] = await Promise.all([
      adminAPI.dashboard(),
      adminAPI.getUsers().catch(() => ({ success: false, users: [] })),
      adminAPI.getRequests().catch(() => ({ success: false, requests: [] })),
      adminAPI.getSchedule().catch(() => ({ success: false, schedule: [] })),
      adminAPI.getSubmissions().catch(() => ({ success: false, submissions: [] })),
      adminAPI.getBreaks().catch(() => ({ success: false, breaks: [] })),
      adminAPI.getSongs().catch(() => ({ success: false, songs: [] })),
    ]);

    if (!overviewData.success) {
      throw new Error(overviewData.error || tr('Nem sikerült betölteni az admin áttekintést.', 'Could not load the admin overview.'));
    }

    setDashboardData(overviewData.dashboard);

    if (usersData.success) {
      setUsers(usersData.users || []);
    }

    if (requestsData.success) {
      setRequests(requestsData.requests || []);
    }

    if (scheduleData.success) {
      setSchedule(scheduleData.schedule || []);
    }

    if (submissionsData.success) {
      setSubmissions(submissionsData.submissions || []);
    }

    if (breaksData.success) {
      setBreaks(breaksData.breaks || []);
    }

    if (songsData.success) {
      setSongs(songsData.songs || []);
    }
  }, [tr]);

  const loadSongs = useCallback(async () => {
    const data = await adminAPI.getSongs();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni a zenéket.', 'Could not load songs.'));
    }
    setSongs(data.songs || []);
  }, [tr]);

  const loadSchedule = useCallback(async () => {
    const data = await adminAPI.getSchedule();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni az órarendet.', 'Could not load the schedule.'));
    }
    setSchedule(data.schedule || []);
  }, [tr]);

  const loadUsers = useCallback(async () => {
    const data = await adminAPI.getUsers();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni a felhasználókat.', 'Could not load users.'));
    }

    setUsers(data.users || []);
    setEditableUser((current) => {
      if (!current) return current;

      const updatedUser = (data.users || []).find(
        (item) => item.email === current.originalEmail || item.email === current.email
      );

      return updatedUser ? buildEditableUser(updatedUser) : null;
    });
  }, [tr]);

  const loadRequests = useCallback(async () => {
    const data = await adminAPI.getRequests();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni a kéréslistát.', 'Could not load requests.'));
    }
    setRequests(data.requests || []);
  }, [tr]);

  const loadSubmissions = useCallback(async () => {
    const data = await adminAPI.getSubmissions();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni a várólistát.', 'Could not load submissions.'));
    }
    setSubmissions(data.submissions || []);
  }, [tr]);

  const loadBreaks = useCallback(async () => {
    const data = await adminAPI.getBreaks();
    if (!data.success) {
      throw new Error(data.error || tr('Nem sikerült betölteni a szüneteket.', 'Could not load breaks.'));
    }
    setBreaks(data.breaks || []);
  }, [tr]);

  useEffect(() => {
    if (!isAdmin) return;

    let active = true;

    const run = async () => {
      setLoading(true);

      try {
        if (activeTab === 'overview') {
          await loadOverview();
        }

        if (activeTab === 'songs') {
          await loadSongs();
        }

        if (activeTab === 'schedule') {
          await Promise.all([loadSongs(), loadSchedule()]);
        }

        if (activeTab === 'users') {
          await loadUsers();
        }

        if (activeTab === 'requests') {
          await Promise.all([loadRequests(), loadUsers(), loadSongs()]);
        }

        if (activeTab === 'submissions') {
          await loadSubmissions();
        }

        if (activeTab === 'breaks') {
          await loadBreaks();
        }
      } catch (error) {
        if (active) {
          showMessage(error.message || tr('Betöltési hiba történt.', 'A loading error occurred.'), 'error');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    run();

    return () => {
      active = false;
    };
  }, [
    activeTab,
    isAdmin,
    loadBreaks,
    loadOverview,
    loadRequests,
    loadSchedule,
    loadSongs,
    loadSubmissions,
    loadUsers,
    showMessage,
  ]);

  const songsById = useMemo(() => new Map(songs.map((song) => [song.id, song])), [songs]);
  const usersById = useMemo(() => new Map(users.map((currentUser) => [currentUser.id, currentUser])), [users]);

  const filteredSongs = useMemo(() => {
    const query = songSearch.trim().toLowerCase();
    if (!query) return songs;

    return songs.filter((song) => (
      song.title.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query) ||
      (song.genre || '').toLowerCase().includes(query)
    ));
  }, [songSearch, songs]);

  const filteredUsers = useMemo(() => {
    const query = userSearch.trim().toLowerCase();
    if (!query) return users;

    return users.filter((currentUser) => (
      currentUser.name.toLowerCase().includes(query) ||
      currentUser.email.toLowerCase().includes(query) ||
      (currentUser.educationalId || '').toLowerCase().includes(query)
    ));
  }, [userSearch, users]);

  const filteredRequests = useMemo(() => {
    const query = requestSearch.trim().toLowerCase();

    return requests
      .map((request) => {
        const requestUser = usersById.get(request.userId);
        const requestSong = resolveRequestSong(request, songsById, songs);

        return {
          ...request,
          user: requestUser || null,
          song: requestSong || null,
        };
      })
      .filter((request) => {
        if (!query) return true;

        const haystack = [
          request.id,
          request.user?.name,
          request.user?.email,
          request.song?.title,
          request.song?.artist,
          request.songUrl,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();

        return haystack.includes(query);
      })
      .sort((left, right) => new Date(right.requestedAt || 0) - new Date(left.requestedAt || 0));
  }, [requestSearch, requests, songsById, usersById]);

  const filteredSubmissions = useMemo(() => {
    const query = submissionSearch.trim().toLowerCase();
    if (!query) return submissions;

    return submissions.filter((submission) => (
      [submission.title, submission.artist, submission.sourceUrl, submission.mp3Url]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(query)
    ));
  }, [submissionSearch, submissions]);

  const sortedSchedule = useMemo(() => (
    [...schedule].sort((left, right) => new Date(left.startTime) - new Date(right.startTime))
  ), [schedule]);

  const sortedBreaks = useMemo(() => (
    [...breaks].sort((left, right) => left.sequence - right.sequence)
  ), [breaks]);

  const overviewRecentUsers = useMemo(() => (
    [...users]
      .sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))
      .slice(0, 5)
  ), [users]);

  const overviewRecentLogins = useMemo(() => (
    users
      .filter((currentUser) => currentUser.active)
      .sort((left, right) => new Date(right.lastLoginAt || 0) - new Date(left.lastLoginAt || 0))
      .slice(0, 5)
  ), [users]);

  const overviewUpcomingSchedule = useMemo(() => (
    [...schedule]
      .sort((left, right) => new Date(left.startTime || 0) - new Date(right.startTime || 0))
      .slice(0, 5)
  ), [schedule]);

  const overviewPendingRequests = useMemo(() => (
    requests
      .filter((request) => !request.validated)
      .map((request) => ({
        ...request,
        user: usersById.get(request.userId) || null,
        song: resolveRequestSong(request, songsById, songs),
      }))
      .sort((left, right) => new Date(right.requestedAt || 0) - new Date(left.requestedAt || 0))
      .slice(0, 5)
  ), [requests, usersById, songsById, songs]);

  const overviewLatestSubmissions = useMemo(() => (
    [...submissions]
      .sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))
      .slice(0, 5)
  ), [submissions]);

  const overviewUpcomingBreaks = useMemo(() => (
    [...breaks]
      .filter((currentBreak) => new Date(currentBreak.start || 0) >= new Date())
      .sort((left, right) => new Date(left.start || 0) - new Date(right.start || 0))
      .slice(0, 5)
  ), [breaks]);

  const handleCreateSong = async (event) => {
    event.preventDefault();

    const data = await adminAPI.createSong({
      ...newSong,
      duration: Number(newSong.duration) || 0,
    });

    if (!data.success) {
      showMessage(data.error || tr('A zene hozzáadása nem sikerült.', 'Could not add the song.'), 'error');
      return;
    }

    setNewSong(EMPTY_SONG);
    setShowAddSong(false);
    showMessage(data.message || tr('A zene sikeresen hozzáadva.', 'Song added successfully.'));
    await loadSongs();
  };

  const beginSongEdit = (song) => {
    setEditingSongId(song.id);
    setEditingSong({
      ...song,
      duration: Number(song.duration) || 0,
      sourceUrl: song.sourceUrl || '',
      mp3Url: song.mp3Url || '',
    });
  };

  const handleUpdateSong = async () => {
    if (!editingSongId || !editingSong) return;

    const data = await adminAPI.updateSong(editingSongId, editingSong);
    if (!data.success) {
      showMessage(data.error || tr('A zene frissítése nem sikerült.', 'Could not update the song.'), 'error');
      return;
    }

    setEditingSongId(null);
    setEditingSong(null);
    showMessage(tr('A zene frissítve lett.', 'Song updated.'));
    await loadSongs();
  };

  const handleDeleteSong = async (song) => {
    if (!window.confirm(tr(`Biztosan törlöd ezt a zenét: ${song.artist} - ${song.title}?`, `Are you sure you want to delete this song: ${song.artist} - ${song.title}?`))) return;

    const data = await adminAPI.deleteSong(song.id);
    if (!data.success) {
      showMessage(data.error || tr('A zene törlése nem sikerült.', 'Could not delete the song.'), 'error');
      return;
    }

    showMessage(tr('A zene törölve lett.', 'Song deleted.'));
    await loadSongs();
  };

  const handleCreateSchedule = async (event) => {
    event.preventDefault();

    const data = await adminAPI.addScheduleItem(
      Number(newSchedule.zeneid),
      newSchedule.mikortol,
      newSchedule.meddig,
    );

    if (!data.success) {
      showMessage(data.error || tr('Az órarend bejegyzés hozzáadása nem sikerült.', 'Could not add the schedule entry.'), 'error');
      return;
    }

    setNewSchedule(EMPTY_SCHEDULE);
    showMessage(tr('Az órarend bejegyzés létrejött.', 'Schedule entry created.'));
    await loadSchedule();
  };

  const handleDeleteSchedule = async (item) => {
    if (!window.confirm(tr('Biztosan törlöd ezt az órarend bejegyzést?', 'Are you sure you want to delete this schedule entry?'))) return;

    const data = await adminAPI.deleteScheduleItem(item.id);
    if (!data.success) {
      showMessage(data.error || tr('Az órarend bejegyzés törlése nem sikerült.', 'Could not delete the schedule entry.'), 'error');
      return;
    }

    showMessage(tr('Az órarend bejegyzés törölve lett.', 'Schedule entry deleted.'));
    await loadSchedule();
  };

  const handleRegisterUser = async (event) => {
    event.preventDefault();

    const data = await adminAPI.registerUser(userForm);
    if (!data.success) {
      showMessage(data.error || tr('A felhasználó létrehozása nem sikerült.', 'Could not create the user.'), 'error');
      return;
    }

    setUserForm(EMPTY_USER_FORM);
    showMessage(data.message || tr('A felhasználó létrehozva.', 'User created.'));
    await loadUsers();
  };

  const handleDeleteUser = async (email) => {
    if (email === user?.email) {
      showMessage(tr('A saját admin fiókodat innen nem törölheted.', 'You cannot delete your own admin account from here.'), 'error');
      return;
    }

    if (!window.confirm(tr(`Biztosan törlöd ezt a felhasználót: ${email}?`, `Are you sure you want to delete this user: ${email}?`))) return;

    const data = await adminAPI.deleteUserByEmail(email);
    if (!data.success) {
      showMessage(data.error || tr('A felhasználó törlése nem sikerült.', 'Could not delete the user.'), 'error');
      return;
    }

    if (editableUser?.originalEmail === email) {
      setEditableUser(null);
    }

    showMessage(data.message || tr('A felhasználó törölve lett.', 'User deleted.'));
    await loadUsers();
  };

  const handleLogoutUser = async (email) => {
    if (email === user?.email) {
      await logout();
      return;
    }

    const data = await adminAPI.logoutUserByEmail(email);
    if (!data.success) {
      showMessage(data.error || tr('A felhasználó kiléptetése nem sikerült.', 'Could not sign out the user.'), 'error');
      return;
    }

    showMessage(data.message || tr('A felhasználó kiléptetve lett.', 'User signed out.'));
    await loadUsers();
  };

  const handleSaveUser = async (event) => {
    event.preventDefault();
    if (!editableUser) return;

    const data = await adminAPI.updateUser(editableUser.originalEmail, editableUser);
    if (!data.success) {
      showMessage(data.error || tr('A felhasználó frissítése nem sikerült.', 'Could not update the user.'), 'error');
      return;
    }

    showMessage(data.message || tr('A felhasználó adatai frissültek.', 'User details updated.'));
    await loadUsers();
  };

  const handleApproveRequest = async (id) => {
    const data = await adminAPI.approveRequest(id);
    if (!data.success) {
      showMessage(data.error || tr('A kérés jóváhagyása nem sikerült.', 'Could not approve the request.'), 'error');
      return;
    }

    showMessage(data.message || tr('A kérés jóváhagyva lett.', 'Request approved.'));
    await loadRequests();
  };

  const beginBreakEdit = (currentBreak) => {
    setEditingBreakSequence(currentBreak.sequence);
    setBreakForm({
      sequence: String(currentBreak.sequence),
      start: toDateTimeLocalValue(currentBreak.start),
      end: toDateTimeLocalValue(currentBreak.end),
    });
  };

  const resetBreakEditor = () => {
    setEditingBreakSequence(null);
    setBreakForm(EMPTY_BREAK);
  };

  const handleSaveBreak = async (event) => {
    event.preventDefault();

    const payload = {
      sequence: Number(breakForm.sequence),
      start: breakForm.start,
      end: breakForm.end,
    };

    const data = editingBreakSequence === null
      ? await adminAPI.createBreak(payload)
      : await adminAPI.updateBreak(editingBreakSequence, payload);

    if (!data.success) {
      showMessage(data.error || tr('A szünet mentése nem sikerült.', 'Could not save the break.'), 'error');
      return;
    }

    resetBreakEditor();
    showMessage(data.message || tr('A szünet mentve lett.', 'Break saved.'));
    await loadBreaks();
  };

  const handleDeleteBreak = async (sequence) => {
    if (!window.confirm(tr(`Biztosan törlöd a(z) ${sequence}. szünetet?`, `Are you sure you want to delete break ${sequence}?`))) return;

    const data = await adminAPI.deleteBreak(sequence);
    if (!data.success) {
      showMessage(data.error || tr('A szünet törlése nem sikerült.', 'Could not delete the break.'), 'error');
      return;
    }

    if (editingBreakSequence === sequence) {
      resetBreakEditor();
    }

    showMessage(data.message || tr('A szünet törölve lett.', 'Break deleted.'));
    await loadBreaks();
  };

  const tabs = [
    { id: 'overview', label: tr('Áttekintés', 'Overview'), icon: Shield },
    { id: 'songs', label: tr('Zenék', 'Songs'), icon: Music },
    { id: 'schedule', label: tr('Órarend', 'Schedule'), icon: CalendarClock },
    { id: 'users', label: tr('Felhasználók', 'Users'), icon: Users },
    { id: 'requests', label: tr('Kérések', 'Requests'), icon: ListChecks },
    { id: 'submissions', label: tr('Beküldések', 'Submissions'), icon: Music },
    { id: 'breaks', label: tr('Szünetek', 'Breaks'), icon: CalendarClock },
  ];

  const renderLoading = () => (
    <div className="admin-loading">
      <Loader2 size={32} className="spinner" />
      <p>{tr('Betöltés...', 'Loading...')}</p>
    </div>
  );

  const renderAdminDateTimePicker = (value, onChange) => (
    <DatePicker
      selected={toPickerDate(value)}
      onChange={(date) => onChange(date ? toDateTimeLocalValue(date) : '')}
      showTimeSelect
      timeFormat="HH:mm"
      timeIntervals={5}
      dateFormat={adminDateFormat}
      locale={adminDateLocale}
      placeholderText={dateInputPlaceholder}
      className="admin-date-picker-input"
      wrapperClassName="admin-date-picker-wrapper"
      calendarClassName="admin-date-picker-calendar"
      popperClassName="admin-date-picker-popper"
      required
    />
  );

  const renderOverview = () => {
    const stats = dashboardData?.stats || {};

    return (
      <div className="admin-dashboard">
        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalSongs ?? 0}</span>
              <span className="admin-stat-label">{tr('Összes zene', 'Total songs')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <Users size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalUsers ?? 0}</span>
              <span className="admin-stat-label">{tr('Felhasználók', 'Users')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <CheckCircle size={24} />
            <div>
              <span className="admin-stat-value">{stats.activeUsers ?? 0}</span>
              <span className="admin-stat-label">{tr('Aktív bejelentkezések', 'Active sessions')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <CalendarClock size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalScheduleItems ?? 0}</span>
              <span className="admin-stat-label">{tr('Órarend elemek', 'Schedule items')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <ListChecks size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingRequests ?? 0}</span>
              <span className="admin-stat-label">{tr('Függő kérések', 'Pending requests')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <AlertCircle size={24} />
            <div>
              <span className="admin-stat-value">{stats.totalBreaks ?? 0}</span>
              <span className="admin-stat-label">{tr('Szünetek', 'Breaks')}</span>
            </div>
          </div>

          <div className="admin-stat-card">
            <Music size={24} />
            <div>
              <span className="admin-stat-value">{stats.pendingSubmissions ?? 0}</span>
              <span className="admin-stat-label">{tr('Várólistás beküldések', 'Queued submissions')}</span>
            </div>
          </div>
        </div>

        <div className="admin-overview-grid">
          <div className="admin-section admin-panel-card">
            <h3><Users size={20} /> {tr('Legutóbb létrehozott felhasználók', 'Recently created users')}</h3>
            <div className="admin-overview-list">
              {overviewRecentUsers.length === 0 ? (
                <p>{tr('Nincs megjeleníthető felhasználó.', 'There are no users to display.')}</p>
              ) : overviewRecentUsers.map((currentUser) => (
                <div key={currentUser.email} className="admin-overview-item">
                  <div>
                    <strong>{currentUser.name}</strong>
                    <span>{currentUser.email}</span>
                  </div>
                  <span className="admin-tag">{formatRole(currentUser.role, language, currentUser.jog)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><LogIn size={20} /> {tr('Legutóbbi bejelentkezett felhasználók', 'Recently signed-in users')}</h3>
            <div className="admin-overview-list">
              {overviewRecentLogins.length === 0 ? (
                <p>{tr('Nincs aktív bejelentkezett felhasználó.', 'There are no active signed-in users.')}</p>
              ) : overviewRecentLogins.map((currentUser) => (
                <div key={`${currentUser.email}-login`} className="admin-overview-item">
                  <div>
                    <strong>{currentUser.name}</strong>
                    <span>{currentUser.email}</span>
                  </div>
                  <span>{formatDateTime(currentUser.lastLoginAt, language)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><ListChecks size={20} /> {tr('Függő kérések', 'Pending requests')}</h3>
            <div className="admin-overview-list">
              {overviewPendingRequests.length === 0 ? (
                <p>{tr('Nincs függő kérés.', 'There are no pending requests.')}</p>
              ) : overviewPendingRequests.map((request) => (
                <div key={request.id} className="admin-overview-item">
                  <div>
                    <strong>
                      {request.song
                        ? `${request.song.artist} - ${request.song.title}`
                        : request.songUrl || `Kérés #${request.id}`}
                    </strong>
                    <span>
                      {request.user ? `${request.user.name} • ${formatDateTime(request.requestedAt, language)}` : formatDateTime(request.requestedAt, language)}
                    </span>
                  </div>
                  <button className="admin-action-btn approve" onClick={() => handleApproveRequest(request.id)} title={tr('Jóváhagyás', 'Approve')}>
                    <CheckCircle size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><CalendarClock size={20} /> {tr('Következő órarend elemek', 'Upcoming schedule items')}</h3>
            <div className="admin-overview-list">
              {overviewUpcomingSchedule.length === 0 ? (
                <p>{tr('Nincs közelgő órarend elem.', 'There are no upcoming schedule items.')}</p>
              ) : overviewUpcomingSchedule.map((item) => (
                <div key={item.id || `${item.songId}-${item.startTime}`} className="admin-overview-item">
                  <div>
                    <strong>{item.song ? `${item.song.artist} - ${item.song.title}` : `Zene #${item.songId}`}</strong>
                    <span>{formatDateTime(item.startTime, language)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><Music size={20} /> {tr('Friss beküldések', 'Recent submissions')}</h3>
            <div className="admin-overview-list">
              {overviewLatestSubmissions.length === 0 ? (
                <p>{tr('Nincs friss várólistás beküldés.', 'There are no recent queued submissions.')}</p>
              ) : overviewLatestSubmissions.map((submission) => (
                <div key={submission.id} className="admin-overview-item">
                  <div>
                    <strong>{submission.title || submission.sourceUrl || tr('Névtelen beküldés', 'Untitled submission')}</strong>
                    <span>{submission.artist || formatDateTime(submission.createdAt, language)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="admin-section admin-panel-card">
            <h3><CalendarClock size={20} /> {tr('Közelgő szünetek', 'Upcoming breaks')}</h3>
            <div className="admin-overview-list">
              {overviewUpcomingBreaks.length === 0 ? (
                <p>{tr('Nincs közelgő szünet.', 'There are no upcoming breaks.')}</p>
              ) : overviewUpcomingBreaks.map((currentBreak) => (
                <div key={`break-${currentBreak.sequence}`} className="admin-overview-item">
                  <div>
                    <strong>{language === 'en' ? `Break ${currentBreak.sequence}` : `${currentBreak.sequence}. szünet`}</strong>
                    <span>{formatDateTime(currentBreak.start, language)}</span>
                  </div>
                  <span>{formatDateTime(currentBreak.end, language)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSongs = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Music size={20} /> {tr(`Song management (${songs.length} zene)`, `Song management (${songs.length} songs)` , )}</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder={tr('Keresés címre vagy előadóra...', 'Search by title or artist...')}
              value={songSearch}
              onChange={(event) => setSongSearch(event.target.value)}
            />
          </div>

          <button className="admin-add-btn" onClick={() => setShowAddSong((value) => !value)}>
            <Plus size={16} /> {tr('Új zene', 'New song')}
          </button>

          <button className="admin-icon-btn" onClick={loadSongs} title={ui.refresh}>
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {showAddSong && (
        <form className="admin-form" onSubmit={handleCreateSong}>
          <h4>{tr('Új zene hozzáadása', 'Add new song')}</h4>
          <div className="admin-form-grid">
            <div className="form-group">
              <label>{tr('Cím', 'Title')}</label>
              <input value={newSong.title} onChange={(event) => setNewSong((prev) => ({ ...prev, title: event.target.value }))} required />
            </div>

            <div className="form-group">
              <label>{tr('Előadó', 'Artist')}</label>
              <input value={newSong.artist} onChange={(event) => setNewSong((prev) => ({ ...prev, artist: event.target.value }))} required />
            </div>

            <div className="form-group">
              <label>{tr('Hossz (mp)', 'Length (sec)')}</label>
              <input type="number" min="1" value={newSong.duration} onChange={(event) => setNewSong((prev) => ({ ...prev, duration: event.target.value }))} />
            </div>

            <div className="form-group">
              <label>{tr('Műfaj', 'Genre')}</label>
              <input value={newSong.genre} onChange={(event) => setNewSong((prev) => ({ ...prev, genre: event.target.value }))} />
            </div>

            <div className="form-group">
              <label>{tr('Keresési / forrás URL', 'Search / source URL')}</label>
              <input value={newSong.sourceUrl} onChange={(event) => setNewSong((prev) => ({ ...prev, sourceUrl: event.target.value }))} placeholder={tr('Pl.: https://youtube.com/watch?v=...', 'e.g. https://youtube.com/watch?v=...')} />
            </div>

            <div className="form-group">
              <label>{tr('MP3 útvonal', 'MP3 path')}</label>
              <input value={newSong.mp3Url} onChange={(event) => setNewSong((prev) => ({ ...prev, mp3Url: event.target.value }))} placeholder={tr('Pl.: C:\\...\\zene.mp3', 'e.g. C:\\...\\song.mp3')} required />
            </div>

            <div className="form-group">
              <label className="admin-checkbox-label">
                <input
                  type="checkbox"
                  checked={newSong.isAvailable}
                  onChange={(event) => setNewSong((prev) => ({ ...prev, isAvailable: event.target.checked }))}
                />
                {tr('Lejátszható', 'Playable')}
              </label>
            </div>
          </div>

          <div className="admin-form-actions">
            <button type="submit" className="btn btn-primary"><Save size={16} /> {ui.save}</button>
            <button type="button" className="btn btn-secondary" onClick={() => { setShowAddSong(false); setNewSong(EMPTY_SONG); }}><X size={16} /> {ui.cancel}</button>
          </div>
        </form>
      )}

      {filteredSongs.length === 0 ? (
        <p className="admin-empty">{tr('Nincs találat.', 'No results.')}</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>{tr('Cím', 'Title')}</th>
                <th>{tr('Előadó', 'Artist')}</th>
                <th>{tr('Hossz', 'Length')}</th>
                <th>{tr('Műfaj', 'Genre')}</th>
                <th>{tr('MP3 útvonal', 'MP3 path')}</th>
                <th>{tr('Kérések', 'Requests')}</th>
                <th>{tr('Elérhető', 'Available')}</th>
                <th>{ui.actions}</th>
              </tr>
            </thead>
            <tbody>
              {filteredSongs.map((song) => (
                <tr key={song.id}>
                  {editingSongId === song.id ? (
                    <>
                      <td data-label={tableLabels.songs.title}><input className="admin-inline-input" value={editingSong.title} onChange={(event) => setEditingSong((prev) => ({ ...prev, title: event.target.value }))} /></td>
                      <td data-label={tableLabels.songs.artist}><input className="admin-inline-input" value={editingSong.artist} onChange={(event) => setEditingSong((prev) => ({ ...prev, artist: event.target.value }))} /></td>
                      <td data-label={tableLabels.songs.length}><input className="admin-inline-input" type="number" value={editingSong.duration} onChange={(event) => setEditingSong((prev) => ({ ...prev, duration: Number(event.target.value) || 0 }))} /></td>
                      <td data-label={tableLabels.songs.genre}><input className="admin-inline-input" value={editingSong.genre || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, genre: event.target.value }))} /></td>
                      <td data-label={tableLabels.songs.mp3Path}><input className="admin-inline-input" value={editingSong.mp3Url || ''} onChange={(event) => setEditingSong((prev) => ({ ...prev, mp3Url: event.target.value }))} /></td>
                      <td data-label={tableLabels.songs.requests}>{song.requestCount ?? 0}</td>
                      <td data-label={tableLabels.songs.available}><input type="checkbox" checked={editingSong.isAvailable} onChange={(event) => setEditingSong((prev) => ({ ...prev, isAvailable: event.target.checked }))} /></td>
                      <td data-label={tableLabels.songs.actions} className="admin-actions">
                        <button className="admin-action-btn approve" onClick={handleUpdateSong} title={ui.save}><Save size={16} /></button>
                        <button className="admin-action-btn" onClick={() => { setEditingSongId(null); setEditingSong(null); }} title={ui.cancel}><X size={16} /></button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td data-label={tableLabels.songs.title}><strong>{song.title}</strong></td>
                      <td data-label={tableLabels.songs.artist}>{song.artist}</td>
                      <td data-label={tableLabels.songs.length}>{formatDuration(song.duration)}</td>
                      <td data-label={tableLabels.songs.genre}>{song.genre || '-'}</td>
                      <td data-label={tableLabels.songs.mp3Path}>{song.mp3Url || '-'}</td>
                      <td data-label={tableLabels.songs.requests}>{song.requestCount ?? 0}</td>
                      <td data-label={tableLabels.songs.available}>{song.isAvailable ? ui.yes : ui.no}</td>
                      <td data-label={tableLabels.songs.actions} className="admin-actions">
                        <button className="admin-action-btn" onClick={() => beginSongEdit(song)} title={ui.edit}><Edit2 size={16} /></button>
                        <button className="admin-action-btn reject" onClick={() => handleDeleteSong(song)} title={ui.delete}><Trash2 size={16} /></button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSchedule = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><CalendarClock size={20} /> {tr('Órarend kezelése', 'Schedule management')}</h3>
        <button className="admin-icon-btn" onClick={loadSchedule} title={ui.refresh}><RefreshCw size={16} /></button>
      </div>

      <form className="admin-form" onSubmit={handleCreateSchedule}>
        <h4>{tr('Új órarend bejegyzés', 'New schedule entry')}</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>{tr('Zene', 'Song')}</label>
            <select value={newSchedule.zeneid} onChange={(event) => setNewSchedule((prev) => ({ ...prev, zeneid: event.target.value }))} required>
              <option value="">{tr('Válassz zenét...', 'Choose a song...')}</option>
              {songs.map((song) => (
                <option key={song.id} value={song.id}>{song.artist} - {song.title}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>{tr('Kezdés', 'Start')}</label>
            {renderAdminDateTimePicker(newSchedule.mikortol, (nextValue) => setNewSchedule((prev) => ({ ...prev, mikortol: nextValue })))}
          </div>

          <div className="form-group">
            <label>{tr('Vége', 'End')}</label>
            {renderAdminDateTimePicker(newSchedule.meddig, (nextValue) => setNewSchedule((prev) => ({ ...prev, meddig: nextValue })))}
          </div>
        </div>

        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Plus size={16} /> {ui.add}</button>
        </div>
      </form>

      {sortedSchedule.length === 0 ? (
        <p className="admin-empty">{tr('Nincs elérhető órarend bejegyzés.', 'No schedule entries available.')}</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>{tr('Zene', 'Song')}</th>
                <th>{tr('Kezdés', 'Start')}</th>
                <th>{tr('Vége', 'End')}</th>
                <th>{ui.actions}</th>
              </tr>
            </thead>
            <tbody>
              {sortedSchedule.map((item) => (
                <tr key={item.id || `${item.songId}-${item.startTime}`}>
                  <td data-label={tableLabels.schedule.song}>{item.song ? `${item.song.artist} - ${item.song.title}` : language === 'en' ? `Song #${item.songId}` : `Zene #${item.songId}`}</td>
                  <td data-label={tableLabels.schedule.start}>{formatDateTime(item.startTime, language)}</td>
                  <td data-label={tableLabels.schedule.end}>{formatDateTime(item.endTime, language)}</td>
                  <td data-label={tableLabels.schedule.actions} className="admin-actions">
                    <button className="admin-action-btn reject" onClick={() => handleDeleteSchedule(item)} title={ui.delete}><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderUsers = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Users size={20} /> {tr(`Felhasználók (${users.length})`, `Users (${users.length})`)}</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder={tr('Keresés névre, emailre, OM-re...', 'Search by name, email, or education ID...')}
              value={userSearch}
              onChange={(event) => setUserSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadUsers} title={ui.refresh}>
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-split-layout">
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>{tr('Név', 'Name')}</th>
                <th>Email</th>
                <th>OM</th>
                <th>{tr('Szerepkör', 'Role')}</th>
                <th>{tr('Email ellenőrzés', 'Email verification')}</th>
                <th>{tr('Állapot', 'Status')}</th>
                <th>{ui.actions}</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((currentUser) => (
                <tr key={currentUser.email} className={editableUser?.originalEmail === currentUser.email ? 'admin-row-selected' : ''}>
                  <td data-label={tableLabels.users.name}>{currentUser.name}</td>
                  <td data-label={tableLabels.users.email}>{currentUser.email}</td>
                  <td data-label={tableLabels.users.om}>{currentUser.educationalId || '-'}</td>
                  <td data-label={tableLabels.users.role}><span className="admin-tag">{formatRole(currentUser.role, language)}</span></td>
                  <td data-label={tableLabels.users.verification}>{currentUser.emailVerified ? tr('Verifikált', 'Verified') : tr('Nincs verifikálva', 'Not verified')}</td>
                  <td data-label={tableLabels.users.status}>{currentUser.active ? tr('Aktív', 'Active') : tr('Kilépve', 'Signed out')}</td>
                  <td data-label={tableLabels.users.actions} className="admin-actions">
                    <button className="admin-action-btn" onClick={() => setEditableUser(buildEditableUser(currentUser))} title={ui.edit}><Edit2 size={16} /></button>
                    <button className="admin-action-btn" onClick={() => handleLogoutUser(currentUser.email)} title={currentUser.email === user?.email ? tr('Saját kijelentkezés', 'Sign out yourself') : tr('Kiléptetés', 'Force sign-out')}><LogOut size={16} /></button>
                    <button className="admin-action-btn reject" onClick={() => handleDeleteUser(currentUser.email)} title={currentUser.email === user?.email ? tr('A saját fiók innen nem törölhető', 'Your own account cannot be deleted here') : ui.delete} disabled={currentUser.email === user?.email}><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="admin-stack-panel">
          {editableUser ? (
            <form className="admin-form" onSubmit={handleSaveUser}>
              <h4><Edit2 size={18} /> {tr('Meglévő felhasználó szerkesztése', 'Edit existing user')}</h4>
              <div className="admin-form-grid">
                <div className="form-group">
                  <label>{tr('Vezetéknév', 'Last name')}</label>
                  <input value={editableUser.vezeteknev} onChange={(event) => setEditableUser((prev) => ({ ...prev, vezeteknev: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>{tr('Keresztnév', 'First name')}</label>
                  <input value={editableUser.keresztnev} onChange={(event) => setEditableUser((prev) => ({ ...prev, keresztnev: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>Email</label>
                  <input type="email" value={editableUser.email} onChange={(event) => setEditableUser((prev) => ({ ...prev, email: event.target.value }))} required />
                </div>

                <div className="form-group">
                  <label>{tr('OM azonosító', 'Education ID')}</label>
                  <input value={editableUser.omazonosito} onChange={(event) => setEditableUser((prev) => ({ ...prev, omazonosito: event.target.value }))} />
                </div>

                <div className="form-group">
                  <label>{tr('Szerepkör', 'Role')}</label>
                  <select value={editableUser.jog} onChange={(event) => setEditableUser((prev) => ({ ...prev, jog: Number(event.target.value) }))}>
                    {ROLE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.jog}>{formatRole(option.value, language)}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>{tr('Új jelszó', 'New password')}</label>
                  <input type="password" value={editableUser.password} onChange={(event) => setEditableUser((prev) => ({ ...prev, password: event.target.value }))} placeholder={tr('Csak ha cserélni szeretnéd', 'Only if you want to change it')} />
                </div>

                <div className="form-group">
                  <label className="admin-checkbox-label">
                    <input
                      type="checkbox"
                      checked={editableUser.emailverifikalva}
                      onChange={(event) => setEditableUser((prev) => ({ ...prev, emailverifikalva: event.target.checked }))}
                    />
                    {tr('Email verifikálva', 'Email verified')}
                  </label>
                </div>
              </div>

              <div className="admin-form-actions">
                <button type="submit" className="btn btn-primary"><Save size={16} /> {ui.save}</button>
                <button type="button" className="btn btn-secondary" onClick={() => setEditableUser(null)}><X size={16} /> {ui.close}</button>
              </div>
            </form>
          ) : (
            <div className="admin-empty">
              <p>{tr('Válassz ki egy felhasználót a táblából a szerkesztéshez.', 'Choose a user from the table to edit.')}</p>
            </div>
          )}

          <form className="admin-form" onSubmit={handleRegisterUser}>
            <h4><UserPlus size={18} /> {tr('Új felhasználó létrehozása', 'Create new user')}</h4>
            <div className="admin-form-grid">
              <div className="form-group">
                <label>{tr('Vezetéknév', 'Last name')}</label>
                <input value={userForm.vezeteknev} onChange={(event) => setUserForm((prev) => ({ ...prev, vezeteknev: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>{tr('Keresztnév', 'First name')}</label>
                <input value={userForm.keresztnev} onChange={(event) => setUserForm((prev) => ({ ...prev, keresztnev: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>Email</label>
                <input type="email" value={userForm.email} onChange={(event) => setUserForm((prev) => ({ ...prev, email: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>{tr('OM azonosító', 'Education ID')}</label>
                <input value={userForm.omazonosito} onChange={(event) => setUserForm((prev) => ({ ...prev, omazonosito: event.target.value }))} />
              </div>

              <div className="form-group">
                <label>{tr('Jelszó', 'Password')}</label>
                <input type="password" value={userForm.password} onChange={(event) => setUserForm((prev) => ({ ...prev, password: event.target.value }))} required />
              </div>

              <div className="form-group">
                <label>{tr('Szerepkör', 'Role')}</label>
                <select value={userForm.role} onChange={(event) => setUserForm((prev) => ({ ...prev, role: event.target.value }))}>
                  {ROLE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>{formatRole(option.value, language)}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="admin-form-actions">
              <button type="submit" className="btn btn-primary"><Save size={16} /> {ui.create}</button>
            </div>
          </form>

          <div className="admin-form">
            <h4><LogOut size={18} /> {tr('Saját munkamenet', 'Current session')}</h4>
            <div className="admin-form-actions">
              <button type="button" className="btn btn-secondary" onClick={logout}><LogOut size={16} /> {tr('Saját kijelentkezés', 'Sign out')}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRequests = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><ListChecks size={20} /> {tr(`Kérések kezelése (${requests.length})`, `Request management (${requests.length})`)}</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder={tr('Keresés kérésre, felhasználóra, zenére...', 'Search by request, user, or song...')}
              value={requestSearch}
              onChange={(event) => setRequestSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadRequests} title={ui.refresh}>
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-empty admin-empty-left">
        <p>{tr('A kéréslista közvetlenül mutatja a kért zenét és innen soronként jóváhagyható. Elutasítás, sorrendezés és törlés továbbra sincs külön végponthoz kötve.', 'The request list shows the requested song directly and each row can be approved here. Reject, reorder, and delete actions are still not exposed by separate backend endpoints.')}</p>
      </div>

      {filteredRequests.length === 0 ? (
        <p className="admin-empty">{tr('Nincs elérhető kérés.', 'No requests available.')}</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>ID</th>
                <th>{tr('Felhasználó', 'User')}</th>
                <th>{tr('Zene', 'Song')}</th>
                <th>{tr('Kérve', 'Requested')}</th>
                <th>{tr('Állapot', 'Status')}</th>
                <th>{ui.actions}</th>
              </tr>
            </thead>
            <tbody>
              {filteredRequests.map((request) => (
                <tr key={request.id}>
                  <td data-label={tableLabels.requests.id}>#{request.id}</td>
                  <td data-label={tableLabels.requests.user}>
                    {request.user
                      ? `${request.user.name} (${request.user.email})`
                      : request.userId
                        ? language === 'en' ? `User #${request.userId}` : `Felhasználó #${request.userId}`
                        : '-'}
                  </td>
                  <td data-label={tableLabels.requests.song}>
                    {request.song
                      ? `${request.song.artist} - ${request.song.title}`
                      : request.songUrl || (request.songId ? (language === 'en' ? `Song #${request.songId}` : `Zene #${request.songId}`) : '-')}
                  </td>
                  <td data-label={tableLabels.requests.requested}>{formatDateTime(request.requestedAt, language)}</td>
                  <td data-label={tableLabels.requests.status}>
                    <span className={`admin-tag ${request.validated ? 'is-success' : 'is-warning'}`}>
                      {request.validated ? tr('Jóváhagyva', 'Approved') : tr('Függőben', 'Pending')}
                    </span>
                  </td>
                  <td data-label={tableLabels.requests.actions} className="admin-actions">
                    {!request.validated && (
                      <button className="admin-action-btn approve" onClick={() => handleApproveRequest(request.id)} title={tr('Jóváhagyás', 'Approve')}>
                        <CheckCircle size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderSubmissions = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><Music size={20} /> {tr(`Beküldéslista (${submissions.length})`, `Submission queue (${submissions.length})`)}</h3>

        <div className="admin-filters">
          <div className="admin-search">
            <Search size={16} />
            <input
              type="text"
              placeholder={tr('Keresés címre, előadóra, URL-re...', 'Search by title, artist, or URL...')}
              value={submissionSearch}
              onChange={(event) => setSubmissionSearch(event.target.value)}
            />
          </div>

          <button className="admin-icon-btn" onClick={loadSubmissions} title={ui.refresh}>
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      <div className="admin-empty admin-empty-left">
        <p>{tr('A lista a backend várólistáját mutatja. Ehhez jelenleg nincs külön sor-szintű jóváhagyó vagy elutasító végpont, ezért ez a nézet ellenőrzésre szolgál.', 'This list shows the backend submission queue. There is currently no dedicated row-level approve or reject endpoint, so this view is for review only.')}</p>
      </div>

      {filteredSubmissions.length === 0 ? (
        <p className="admin-empty">{tr('Nincs várólistás beküldés.', 'No queued submissions.')}</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>{tr('Cím', 'Title')}</th>
                <th>{tr('Előadó', 'Artist')}</th>
                <th>{tr('Forrás', 'Source')}</th>
                <th>{tr('MP3 útvonal', 'MP3 path')}</th>
                <th>{tr('Kérések', 'Requests')}</th>
                <th>{tr('Rögzítve', 'Recorded')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredSubmissions.map((submission) => (
                <tr key={submission.id}>
                  <td data-label={tableLabels.submissions.title}>{submission.title || '-'}</td>
                  <td data-label={tableLabels.submissions.artist}>{submission.artist || '-'}</td>
                  <td data-label={tableLabels.submissions.source} className="admin-cell-wrap">{submission.sourceUrl || '-'}</td>
                  <td data-label={tableLabels.submissions.mp3Path} className="admin-cell-wrap">{submission.mp3Url || '-'}</td>
                  <td data-label={tableLabels.submissions.requests}>{submission.requestCount || 0}</td>
                  <td data-label={tableLabels.submissions.recorded}>{formatDateTime(submission.createdAt, language)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderBreaks = () => (
    <div className="admin-section">
      <div className="admin-section-header">
        <h3><CalendarClock size={20} /> {tr(`Szünetek kezelése (${breaks.length})`, `Break management (${breaks.length})`)}</h3>
        <button className="admin-icon-btn" onClick={loadBreaks} title={ui.refresh}><RefreshCw size={16} /></button>
      </div>

      <form className="admin-form" onSubmit={handleSaveBreak}>
        <h4>{editingBreakSequence === null ? tr('Új szünet létrehozása', 'Create new break') : language === 'en' ? `Edit break ${editingBreakSequence}` : `${editingBreakSequence}. szünet szerkesztése`}</h4>
        <div className="admin-form-grid">
          <div className="form-group">
            <label>{tr('Sorszám', 'Sequence')}</label>
            <input
              type="number"
              min="1"
              value={breakForm.sequence}
              onChange={(event) => setBreakForm((prev) => ({ ...prev, sequence: event.target.value }))}
              required
              disabled={editingBreakSequence !== null}
            />
          </div>

          <div className="form-group">
            <label>{tr('Kezdés', 'Start')}</label>
            {renderAdminDateTimePicker(breakForm.start, (nextValue) => setBreakForm((prev) => ({ ...prev, start: nextValue })))}
          </div>

          <div className="form-group">
            <label>{tr('Vége', 'End')}</label>
            {renderAdminDateTimePicker(breakForm.end, (nextValue) => setBreakForm((prev) => ({ ...prev, end: nextValue })))}
          </div>
        </div>

        <div className="admin-form-actions">
          <button type="submit" className="btn btn-primary"><Save size={16} /> {editingBreakSequence === null ? ui.create : ui.save}</button>
          {editingBreakSequence !== null && (
            <button type="button" className="btn btn-secondary" onClick={resetBreakEditor}><X size={16} /> {ui.cancel}</button>
          )}
        </div>
      </form>

      {sortedBreaks.length === 0 ? (
        <p className="admin-empty">{tr('Nincs rögzített szünet.', 'No recorded breaks.')}</p>
      ) : (
        <div className="admin-table-wrapper">
          <table className="admin-table admin-table-cards">
            <thead>
              <tr>
                <th>{tr('Sorszám', 'Sequence')}</th>
                <th>{tr('Kezdés', 'Start')}</th>
                <th>{tr('Vége', 'End')}</th>
                <th>{ui.actions}</th>
              </tr>
            </thead>
            <tbody>
              {sortedBreaks.map((currentBreak) => (
                <tr key={currentBreak.id} className={editingBreakSequence === currentBreak.sequence ? 'admin-row-selected' : ''}>
                  <td data-label={tableLabels.breaks.sequence}>{currentBreak.sequence}</td>
                  <td data-label={tableLabels.breaks.start}>{formatDateTime(currentBreak.start, language)}</td>
                  <td data-label={tableLabels.breaks.end}>{formatDateTime(currentBreak.end, language)}</td>
                  <td data-label={tableLabels.breaks.actions} className="admin-actions">
                    <button className="admin-action-btn" onClick={() => beginBreakEdit(currentBreak)} title={ui.edit}><Edit2 size={16} /></button>
                    <button className="admin-action-btn reject" onClick={() => handleDeleteBreak(currentBreak.sequence)} title={ui.delete}><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    if (loading) {
      return renderLoading();
    }

    if (activeTab === 'overview') return renderOverview();
    if (activeTab === 'songs') return renderSongs();
    if (activeTab === 'schedule') return renderSchedule();
    if (activeTab === 'users') return renderUsers();
    if (activeTab === 'requests') return renderRequests();
    if (activeTab === 'submissions') return renderSubmissions();
    if (activeTab === 'breaks') return renderBreaks();
    return null;
  };

  if (userLoading) {
    return renderLoading();
  }

  if (!isLoggedIn || !isAdmin) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Shield size={64} />
          <h2>{tr('Hozzáférés megtagadva', 'Access denied')}</h2>
          <p>{tr('Az admin panel csak admin felhasználóknak érhető el.', 'The admin panel is only available for administrator accounts.')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page admin-page">
      <section className="page-header">
        <div className="page-header-content">
          <Shield size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Admin Panel', 'Admin Panel')}</h1>
            <p className="page-subtitle">{tr('A jelenlegi backendhez és az asztali kliens közös adatmodelljéhez igazított admin műveletek', 'Administrative actions aligned with the current backend and the shared desktop client data model.')}</p>
          </div>
        </div>
      </section>

      {message && (
        <div className={`admin-toast ${message.type}`}>
          {message.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} title={ui.close}><X size={16} /></button>
        </div>
      )}

      <div className="admin-tabs">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`admin-tab ${activeTab === id ? 'active' : ''}`} onClick={() => setActiveTab(id)}>
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      <div className="admin-content">
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminPage;
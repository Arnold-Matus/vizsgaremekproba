﻿import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import LanguageToggle from '../components/NyelvValtoGomb';
import AppLogo from '../components/AppLogo';

const REMEMBERED_IDENTIFIER_KEY = 'suliradio-remembered-identifier';
const REMEMBERED_ACCOUNTS_KEY = 'suliradio-remembered-accounts';
const MAX_REMEMBERED_ACCOUNTS = 5;

const normalizeIdentifier = (identifier) => String(identifier || '').trim();

const normalizeRememberedAccounts = (accounts) => {
  const seen = new Set();

  return (Array.isArray(accounts) ? accounts : [])
    .map((account) => {
      if (typeof account === 'string') {
        return {
          identifier: normalizeIdentifier(account),
          lastUsedAt: null,
        };
      }

      if (!account || typeof account !== 'object') {
        return null;
      }

      return {
        identifier: normalizeIdentifier(account.identifier),
        lastUsedAt: account.lastUsedAt || null,
      };
    })
    .filter((account) => {
      if (!account?.identifier) {
        return false;
      }

      const dedupeKey = account.identifier.toLowerCase();
      if (seen.has(dedupeKey)) {
        return false;
      }

      seen.add(dedupeKey);
      return true;
    })
    .slice(0, MAX_REMEMBERED_ACCOUNTS);
};

const getRememberedAccounts = () => {
  if (typeof window === 'undefined') {
    return [];
  }

  const rawAccounts = localStorage.getItem(REMEMBERED_ACCOUNTS_KEY);
  if (rawAccounts) {
    try {
      return normalizeRememberedAccounts(JSON.parse(rawAccounts));
    } catch {
      localStorage.removeItem(REMEMBERED_ACCOUNTS_KEY);
    }
  }

  const legacyIdentifier = localStorage.getItem(REMEMBERED_IDENTIFIER_KEY) || '';
  const normalizedLegacyIdentifier = normalizeIdentifier(legacyIdentifier);

  return normalizedLegacyIdentifier
    ? [{ identifier: normalizedLegacyIdentifier, lastUsedAt: null }]
    : [];
};

const getRememberedIdentifier = () => {
  return getRememberedAccounts()[0]?.identifier || '';
};

const persistRememberedAccounts = (accounts) => {
  if (typeof window === 'undefined') {
    return [];
  }

  const normalizedAccounts = normalizeRememberedAccounts(accounts);

  if (normalizedAccounts.length === 0) {
    localStorage.removeItem(REMEMBERED_ACCOUNTS_KEY);
    localStorage.removeItem(REMEMBERED_IDENTIFIER_KEY);
    return [];
  }

  localStorage.setItem(REMEMBERED_ACCOUNTS_KEY, JSON.stringify(normalizedAccounts));
  localStorage.setItem(REMEMBERED_IDENTIFIER_KEY, normalizedAccounts[0].identifier);
  return normalizedAccounts;
};

const persistRememberedIdentifier = (identifier) => {
  const trimmedIdentifier = normalizeIdentifier(identifier);
  if (!trimmedIdentifier) {
    return [];
  }

  const nextAccounts = [
    {
      identifier: trimmedIdentifier,
      lastUsedAt: new Date().toISOString(),
    },
    ...getRememberedAccounts().filter((account) => account.identifier.toLowerCase() !== trimmedIdentifier.toLowerCase()),
  ];

  return persistRememberedAccounts(nextAccounts);
};

const clearRememberedIdentifier = () => {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.removeItem(REMEMBERED_IDENTIFIER_KEY);
  localStorage.removeItem(REMEMBERED_ACCOUNTS_KEY);
};

const removeRememberedIdentifier = (identifier) => {
  const trimmedIdentifier = normalizeIdentifier(identifier);
  if (!trimmedIdentifier) {
    return getRememberedAccounts();
  }

  return persistRememberedAccounts(
    getRememberedAccounts().filter((account) => account.identifier.toLowerCase() !== trimmedIdentifier.toLowerCase())
  );
};

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, demoLogin, isLoggedIn } = useUser();
  const { language } = useI18n();
  const formRef = useRef(null);
  const passwordInputRef = useRef(null);
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rememberedAccounts, setRememberedAccounts] = useState(() => getRememberedAccounts());
  const [rememberIdentifier, setRememberIdentifier] = useState(() => Boolean(getRememberedIdentifier()));
  const formAutocomplete = rememberIdentifier ? 'on' : 'off';
  const identifierAutocomplete = rememberIdentifier ? 'username' : 'off';
  const passwordAutocomplete = rememberIdentifier ? 'current-password' : 'off';

  useEffect(() => {
    if (isLoggedIn) {
      navigate('/', { replace: true });
    }
  }, [isLoggedIn, navigate]);

  useEffect(() => {
    setSuccessMessage(location.state?.message || '');
  }, [location]);

  const finalizeRememberedIdentifier = (trimmedIdentifier) => {
    if (rememberIdentifier) {
      const rememberedValues = persistRememberedIdentifier(trimmedIdentifier);
      setRememberedAccounts(rememberedValues);
      return;
    }

    const remainingAccounts = removeRememberedIdentifier(trimmedIdentifier);
    setRememberedAccounts(remainingAccounts);
  };

  const submitLogin = async ({ nextIdentifier, nextPassword }) => {
    const trimmedIdentifier = nextIdentifier.trim();

    if (!trimmedIdentifier || !nextPassword) {
      setError(tr('Kérlek töltsd ki az összes mezőt!', 'Please fill in all fields.'));
      return false;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const result = await login(trimmedIdentifier, nextPassword);
      if (result.success) {
        finalizeRememberedIdentifier(trimmedIdentifier);
        navigate('/');
        return true;
      }

      setError(result.error || tr('Hibás bejelentkezési adatok!', 'Invalid login details.'));
      return false;
    } catch {
      setError(tr('Hiba történt a bejelentkezés során!', 'An error occurred during sign-in.'));
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRememberIdentifierToggle = (checked) => {
    setRememberIdentifier(checked);

    const trimmedIdentifier = normalizeIdentifier(identifier);
    if (!checked && trimmedIdentifier) {
      setRememberedAccounts(removeRememberedIdentifier(trimmedIdentifier));
    }
  };

  const handleUseRememberedIdentifier = async (rememberedIdentifier) => {
    const trimmedIdentifier = normalizeIdentifier(rememberedIdentifier);
    if (!trimmedIdentifier) {
      return;
    }

    setIdentifier(trimmedIdentifier);
    setRememberIdentifier(true);
    setError('');

    setPassword('');

    requestAnimationFrame(() => {
      passwordInputRef.current?.focus();
    });
  };

  const handleForgetRememberedIdentifier = (rememberedIdentifier) => {
    const updatedAccounts = removeRememberedIdentifier(rememberedIdentifier);
    setRememberedAccounts(updatedAccounts);
    if (updatedAccounts.length === 0) {
      setRememberIdentifier(false);
    }

    if (normalizeIdentifier(identifier) === normalizeIdentifier(rememberedIdentifier)) {
      setIdentifier('');
      setPassword('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await submitLogin({
      nextIdentifier: identifier,
      nextPassword: password,
    });
  };

  const handleDemoLogin = async () => {
    setIsSubmitting(true);
    setError('');
    try {
      const result = await demoLogin();
      if (result && result.success) {
        navigate('/');
      } else {
        setError(result?.error || tr('Demo bejelentkezés sikertelen! Ellenőrizd, hogy a backend szerver fut-e.', 'Demo sign-in failed. Check whether the backend server is running.'));
      }
    } catch {
      setError(tr('Nem sikerült csatlakozni a szerverhez. Ellenőrizd, hogy a backend fut-e!', 'Could not connect to the server. Check whether the backend is running.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <div className="auth-language-toggle-row">
          <LanguageToggle />
        </div>
        <div className="auth-logo">
          <div className="auth-logo-icon" aria-hidden="true">
            <AppLogo className="app-logo-image" decorative />
          </div>
          <h1>SuliRadio</h1>
        </div>

        <h2 className="auth-title">{tr('Bejelentkezés', 'Log in')}</h2>
        <p className="auth-subtitle">{tr('Üdv újra! Kérlek jelentkezz be a fiókodba.', 'Welcome back. Sign in to continue to your account.')}</p>

        {successMessage && (
          <div className="auth-message success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
            <span>{successMessage}</span>
          </div>
        )}

        {error && (
          <div className="auth-message error">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{error}</span>
          </div>
        )}

        {rememberedAccounts.length > 0 && (
          <div className="remembered-account-panel">
            {rememberedAccounts.map((account) => (
              <div key={account.identifier.toLowerCase()} className="remembered-account-entry">
                <button
                  type="button"
                  className="remembered-account-card"
                  onClick={() => handleUseRememberedIdentifier(account.identifier)}
                  disabled={isSubmitting}
                >
                  <span className="remembered-account-avatar" aria-hidden="true">
                    {account.identifier.slice(0, 1).toUpperCase()}
                  </span>
                  <span className="remembered-account-content">
                    <strong>{account.identifier}</strong>
                    <span>{tr('Folytatás ezzel a fiókkal', 'Continue with this account')}</span>
                  </span>
                  <span className="remembered-account-chevron" aria-hidden="true">›</span>
                </button>

                <div className="remembered-account-actions">
                  <button
                    type="button"
                    className="remembered-account-action"
                    onClick={() => handleForgetRememberedIdentifier(account.identifier)}
                    disabled={isSubmitting}
                  >
                    {tr('Elfelejtés', 'Forget')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <form ref={formRef} onSubmit={handleSubmit} className="auth-form" autoComplete={formAutocomplete}>
          <div className="form-group">
            <label htmlFor="identifier">{tr('Email cím', 'Email address')}</label>
            <input
              type="email"
              id="identifier"
              name="email"
              value={identifier}
              onChange={(e) => {
                setIdentifier(e.target.value);
                setError('');
              }}
              placeholder={tr('pelda@bszc.hu', 'example@bszc.hu')}
              disabled={isSubmitting}
              autoComplete={identifierAutocomplete}
              autoCapitalize="none"
              autoFocus
            />
            <small style={{ color: 'var(--color-text-secondary)' }}>
              {tr('A jelenlegi bejelentkezés email címmel működik.', 'Sign-in currently works with your email address.')}
            </small>
          </div>

          <div className="form-group">
            <div className="form-label-row">
              <label htmlFor="password">{tr('Jelszó', 'Password')}</label>
              <Link to="/elfelejtett-jelszo" className="form-link">
                {tr('Elfelejtett jelszó?', 'Forgot password?')}
              </Link>
            </div>
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                ref={passwordInputRef}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="••••••••"
                disabled={isSubmitting}
                autoComplete={passwordAutocomplete}
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? tr('Jelszó elrejtése', 'Hide password') : tr('Jelszó mutatása', 'Show password')}
              >
                {showPassword ? (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                )}
              </button>
            </div>
          </div>

          <div className="form-checkboxes">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="remember"
                checked={rememberIdentifier}
                onChange={(e) => handleRememberIdentifierToggle(e.target.checked)}
                disabled={isSubmitting}
              />
              <span className="checkbox-custom" aria-hidden="true"></span>
              <span>{tr('Fiók megjegyzése ezen az eszközön', 'Remember this account on this device')}</span>
            </label>
          </div>

          <button type="submit" className="auth-submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <span className="spinner"></span>
                {tr('Bejelentkezés...', 'Signing in...')}
              </>
            ) : (
              tr('Bejelentkezés', 'Log in')
            )}
          </button>
        </form>

        <div className="auth-divider">
          <span>{tr('vagy', 'or')}</span>
        </div>

        <button 
          type="button"
          className="auth-demo-btn"
          onClick={handleDemoLogin}
          disabled={isSubmitting}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          {tr('Demo fiók kipróbálása', 'Try the demo account')}
        </button>

        <p className="auth-footer">
          {tr('Még nincs fiókod?', 'Do you need an account?')}{' '}
          <Link to="/regisztracio">{tr('Regisztrálj most!', 'Create one now!')}</Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;

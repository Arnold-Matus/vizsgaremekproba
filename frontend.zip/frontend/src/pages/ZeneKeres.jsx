﻿import { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  Link as LinkIcon, 
  Search, 
  Music, 
  Send, 
  CheckCircle, 
  AlertCircle,
  Info,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { useMusic } from '../contexts/ZeneKontextus';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import { requestsAPI } from '../services/api';

const RequestPage = () => {
  const { filteredSongs, searchQuery, setSearchQuery, selectedSongs, toggleSongSelection, requestSongs, formatDuration, dailyStatus, loadDailyStatus, loadSongs } = useMusic();
  const { user, isLoggedIn } = useUser();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const [activeTab, setActiveTab] = useState('library');
  const [linkUrl, setLinkUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);
  const [isRefreshingLibrary, setIsRefreshingLibrary] = useState(false);

  useEffect(() => {
    if (isLoggedIn) {
      loadDailyStatus();
    }
  }, [isLoggedIn, loadDailyStatus]);

  const handleLibraryRequest = async () => {
    if (!isLoggedIn) {
      setSubmitResult({ type: 'error', message: tr('Kérlek jelentkezz be a zenék kéréséhez!', 'Please sign in to request songs.') });
      return;
    }
    if (selectedSongs.length === 0) {
      setSubmitResult({ type: 'error', message: tr('Válassz ki legalább egy zenét!', 'Select at least one song.') });
      return;
    }
    if (dailyStatus.remaining <= 0) {
      setSubmitResult({ type: 'error', message: tr(`Elérted a napi limitet (${dailyStatus.maxDaily} zene/nap). Holnap újra kérhetsz!`, `You reached the daily limit (${dailyStatus.maxDaily} songs/day). You can request again tomorrow.`) });
      return;
    }
    if (selectedSongs.length > dailyStatus.remaining) {
      setSubmitResult({ type: 'error', message: tr(`Ma már csak ${dailyStatus.remaining} zenét kérhetsz!`, `You can only request ${dailyStatus.remaining} more songs today.`) });
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await requestSongs(selectedSongs, user?.id);
      setSubmitResult({ type: 'success', message: result.message });
    } catch (error) {
      setSubmitResult({ type: 'error', message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLinkRequest = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) {
      setSubmitResult({ type: 'error', message: tr('Kérlek jelentkezz be a zenék kéréséhez!', 'Please sign in to request songs.') });
      return;
    }
    if (!linkUrl.trim()) {
      setSubmitResult({ type: 'error', message: tr('Add meg a zene linkjét!', 'Provide the song link.') });
      return;
    }

    if (/spotify\.com/i.test(linkUrl.trim())) {
      setSubmitResult({
        type: 'error',
        message: tr(
          'Spotify linket nem tudsz beküldeni. Használj YouTube vagy más közvetlenül elérhető linket.',
          'Spotify links are not supported. Use a YouTube or another directly accessible link.'
        ),
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const data = await requestsAPI.createFromUrl(linkUrl);
      if (!data.success) {
        throw new Error(data.error || tr('A kérés elküldése nem sikerült.', 'Could not send the request.'));
      }
      setSubmitResult({ type: 'success', message: data.message || tr('Kérésed elküldve! Hamarosan feldolgozzuk.', 'Your request was sent. We will review it soon.') });
      setLinkUrl('');
    } catch (error) {
      setSubmitResult({ type: 'error', message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const refreshLibrary = async () => {
    setIsRefreshingLibrary(true);
    try {
      await Promise.all([loadSongs(), loadDailyStatus()]);
    } finally {
      setIsRefreshingLibrary(false);
    }
  };

  const displayedSongs = filteredSongs();

  const isSongRequested = (songId) => dailyStatus.requestedSongIds.includes(songId);
  const isSongLastRequested = (songId) => dailyStatus.lastRequestedSongId === songId;
  const canSelectMore = selectedSongs.length < dailyStatus.remaining;

  return (
    <div className="page request-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <PlusCircle size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Zenekérés', 'Music request')}</h1>
            <p className="page-subtitle">
              {tr('Kérj zenét a könyvtárból vagy küldj be egy közvetlen linket!', 'Request a song from the library or send a direct link!')}
            </p>
          </div>
        </div>
      </section>

      {/* Daily limit info */}
      {isLoggedIn && (
        <div className={`info-banner ${dailyStatus.remaining === 0 ? 'warning' : ''}`} role="status">
          <Info size={18} />
          <p>
            {tr('Napi limit:', 'Daily limit:')} <strong>{dailyStatus.usedToday}/{dailyStatus.maxDaily}</strong> {tr('kérés elhasználva.', 'requests used.')}
            {dailyStatus.remaining > 0
              ? <> {tr('Még', 'You can still request')} <strong>{dailyStatus.remaining}</strong> {tr('zenét kérhetsz ma.', 'songs today.')}</>
              : <> {tr('Holnap újra kérhetsz!', 'You can request again tomorrow!')}</>
            }
          </p>
        </div>
      )}

      {/* Login warning */}
      {!isLoggedIn && (
        <div className="warning-banner" role="alert">
          <AlertCircle size={20} />
          <p>
            {tr('A zenék kéréséhez be kell jelentkezned.', 'You need to sign in to request songs.')}
            <a href="/bejelentkezes"> {tr('Jelentkezz be', 'Sign in')}</a> {tr('vagy', 'or')}
            <a href="/regisztracio"> {tr('regisztrálj', 'register')}</a>!
          </p>
        </div>
      )}

      {/* Submit result */}
      {submitResult && (
        <div className={`result-banner ${submitResult.type}`} role="alert">
          {submitResult.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
          <p>{submitResult.message}</p>
          <button onClick={() => setSubmitResult(null)} aria-label={tr('Bezárás', 'Close')}>×</button>
        </div>
      )}

      {/* Tabs */}
      <div className="request-tabs" role="tablist">
        <button
          role="tab"
          aria-selected={activeTab === 'library'}
          className={`request-tab ${activeTab === 'library' ? 'active' : ''}`}
          onClick={() => setActiveTab('library')}
        >
          <Music size={18} />
          <span>{tr('Könyvtár', 'Library')}</span>
        </button>
        <button
          role="tab"
          aria-selected={activeTab === 'link'}
          className={`request-tab ${activeTab === 'link' ? 'active' : ''}`}
          onClick={() => setActiveTab('link')}
        >
          <LinkIcon size={18} />
          <span>{tr('Link beküldése', 'Submit link')}</span>
        </button>
      </div>

      {/* Tab content */}
      <div className="request-content">
        {activeTab === 'library' && (
          <div className="library-request" role="tabpanel">
            <div className="library-header">
              <div className="search-container">
                <Search size={20} className="search-icon" />
                <input
                  type="search"
                  placeholder={tr('Keresés a könyvtárban...', 'Search in the library...')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                  aria-label={tr('Keresés', 'Search')}
                />
              </div>
              <button
                className="refresh-btn"
                type="button"
                onClick={refreshLibrary}
                aria-label={tr('Frissítés', 'Refresh')}
                disabled={isRefreshingLibrary}
              >
                <RefreshCw size={18} className={isRefreshingLibrary ? 'spinning' : ''} />
                <span>{tr('Frissítés', 'Refresh')}</span>
              </button>
              {selectedSongs.length > 0 && (
                <button 
                  className="submit-btn"
                  onClick={handleLibraryRequest}
                  disabled={isSubmitting || !isLoggedIn}
                >
                  {isSubmitting ? (
                    <Loader2 size={18} className="spinning" />
                  ) : (
                    <Send size={18} />
                  )}
                  <span>{tr('Kérés', 'Request')} ({selectedSongs.length})</span>
                </button>
              )}
            </div>

            <div className="library-songs">
              {displayedSongs.length === 0 ? (
                <div className="no-songs">
                  <Music size={48} />
                  <p>{tr('Nincs találat', 'No results')}</p>
                </div>
              ) : (
                <div className="songs-grid">
                  {displayedSongs.map(song => {
                    const alreadyRequested = isSongRequested(song.id);
                    const isLastReq = isSongLastRequested(song.id);
                    const isSelected = selectedSongs.includes(song.id);
                    const isDisabled = alreadyRequested || (isLastReq && !isSelected) || (!isSelected && !canSelectMore);

                    return (
                    <div 
                      key={song.id}
                      className={`song-card ${isSelected ? 'selected' : ''} ${alreadyRequested ? 'disabled already-requested' : ''} ${isDisabled && !isSelected ? 'disabled' : ''}`}
                      onClick={() => !alreadyRequested && !(isLastReq && !isSelected) && toggleSongSelection(song.id)}
                      role="checkbox"
                      aria-checked={isSelected}
                      aria-disabled={isDisabled}
                      tabIndex={isDisabled && !isSelected ? -1 : 0}
                      onKeyDown={(e) => e.key === 'Enter' && !alreadyRequested && !(isLastReq && !isSelected) && toggleSongSelection(song.id)}
                      title={alreadyRequested ? tr('Ma már kérted ezt a zenét', 'You already requested this song today') : isLastReq ? tr('Nem kérheted ugyanazt egymás után', 'You cannot request the same song twice in a row') : !canSelectMore && !isSelected ? tr('Elérted a napi limitet', 'You reached the daily limit') : ''}
                    >
                      <div className="song-card-cover">
                        {song.coverUrl ? (
                          <img src={song.coverUrl} alt="" />
                        ) : (
                          <div className="cover-placeholder">
                            <Music size={32} />
                          </div>
                        )}
                        {isSelected && (
                          <div className="selected-overlay">
                            <CheckCircle size={32} />
                          </div>
                        )}
                        {alreadyRequested && (
                          <div className="selected-overlay requested-overlay">
                            <CheckCircle size={32} />
                            <span className="requested-label">{tr('Már kérted', 'Already requested')}</span>
                          </div>
                        )}
                      </div>
                      <div className="song-card-info">
                        <h3 className="song-card-title">{song.title}</h3>
                        <p className="song-card-artist">{song.artist}</p>
                        <span className="song-card-duration">{formatDuration(song.duration)}</span>
                      </div>
                    </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'link' && (
          <div className="link-request" role="tabpanel">
            <form onSubmit={handleLinkRequest} className="link-form">
              <div className="form-group">
                <label htmlFor="link-url">
                  <LinkIcon size={16} />
                  {tr('Zene linkje', 'Song link')} *
                </label>
                <input
                  type="url"
                  id="link-url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder={tr('Pl.: https://youtube.com/watch?v=...', 'e.g. https://youtube.com/watch?v=...')}
                  required
                  className="form-input"
                />
                <span className="form-hint">{tr('YouTube, YouTube Music, SoundCloud, Apple Music, Deezer, Tidal vagy Bandcamp link. Spotify link nem támogatott.', 'YouTube, YouTube Music, SoundCloud, Apple Music, Deezer, Tidal, or Bandcamp link. Spotify links are not supported.')}</span>
              </div>

              <button 
                type="submit" 
                className="submit-btn full-width"
                disabled={isSubmitting || !isLoggedIn}
              >
                {isSubmitting ? (
                  <Loader2 size={18} className="spinning" />
                ) : (
                  <Send size={18} />
                )}
                <span>{tr('Kérés elküldése', 'Send request')}</span>
              </button>
            </form>

            <div className="link-info">
              <h3><Info size={18} /> {tr('Tudnivalók', 'Good to know')}</h3>
              <ul>
                <li>{tr('Csak közvetlenül elérhető linket küldj be, mert ez kerül a kéréshez.', 'Send only directly accessible links because that exact link is stored with the request.')}</li>
                <li>{tr('Spotify linket nem fogad el a rendszer.', 'Spotify links are not accepted by the system.')}</li>
                <li>{tr('A beküldött link a kéréslistába kerül, ahol az admin jóváhagyhatja.', 'The submitted link goes to the request list where an admin can approve it.')}</li>
                <li>{tr('Ha a link hibás vagy nem lejátszható, a kérés nem fog teljesülni.', 'If the link is invalid or cannot be played, the request cannot be fulfilled.')}</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RequestPage;

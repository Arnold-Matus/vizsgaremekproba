﻿import { 
  Accessibility as AccessibilityIcon, 
  Eye, 
  Type, 
  Palette, 
  MousePointer, 
  Volume2,
  Keyboard,
  Monitor
} from 'lucide-react';
import { useTheme } from '../contexts/TemaKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL } from '../constants/appInfo';

const AccessibilityPage = () => {
  const { 
    darkMode, 
    toggleDarkMode, 
    highContrast, 
    toggleHighContrast, 
    fontSize, 
    increaseFontSize, 
    decreaseFontSize, 
    resetFontSize 
  } = useTheme();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const accessibilityFeatures = [
    {
      icon: Eye,
      title: tr('Látás', 'Vision'),
      features: [
        tr('Sötét mód a szemkímélő használatért', 'Dark mode for easier reading'),
        tr('Magas kontraszt mód', 'High-contrast mode'),
        tr('Állítható betűméret (12-24px)', 'Adjustable font size (12-24px)'),
        tr('Színvak-barát színek', 'Color-blind-friendly colors'),
      ]
    },
    {
      icon: Keyboard,
      title: tr('Billentyűzet navigáció', 'Keyboard navigation'),
      features: [
        tr('Teljes billentyűzet-támogatás', 'Full keyboard support'),
        tr('Tab navigáció minden elemhez', 'Tab navigation for every element'),
        tr('Skip linkek a gyors navigációhoz', 'Skip links for faster navigation'),
        tr('Fókusz indikátorok', 'Visible focus indicators'),
      ]
    },
    {
      icon: Volume2,
      title: tr('Képernyőolvasók', 'Screen readers'),
      features: [
        tr('ARIA címkék minden elemhez', 'ARIA labels for each element'),
        tr('Strukturált HTML5 elemek', 'Structured HTML5 elements'),
        tr('Alt szövegek a képekhez', 'Alt text for images'),
        tr('Szerepkör meghatározások', 'Explicit role definitions'),
      ]
    },
    {
      icon: Monitor,
      title: tr('Megjelenítés', 'Display'),
      features: [
        tr('Reszponzív design minden eszközre', 'Responsive design for every device'),
        tr('Csökkentett mozgás opció', 'Reduced motion support'),
        tr('Nagyítható tartalom', 'Scalable content'),
        tr('200% zoom támogatás', '200% zoom support'),
      ]
    },
  ];

  const shortcuts = [
    { keys: ['Tab'], description: tr('Következő elemre ugrás', 'Move to the next element') },
    { keys: ['Shift', 'Tab'], description: tr('Előző elemre ugrás', 'Move to the previous element') },
    { keys: ['Enter'], description: tr('Elem aktiválása', 'Activate element') },
    { keys: ['Esc'], description: tr('Menü/dialog bezárása', 'Close menu or dialog') },
    { keys: ['Alt', 'S'], description: tr('Keresés megnyitása', 'Open search') },
    { keys: ['Alt', 'M'], description: tr('Menü megnyitása', 'Open menu') },
  ];

  return (
    <div className="page accessibility-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <AccessibilityIcon size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Akadálymentesség', 'Accessibility')}</h1>
            <p className="page-subtitle">
              {tr('A SuliRadio mindenki számára elérhető', 'SuliRadio is accessible for everyone')}
            </p>
          </div>
        </div>
      </section>

      <div className="accessibility-content">
        {/* Quick settings */}
        <section className="accessibility-quick-settings">
          <h2>{tr('Gyors beállítások', 'Quick settings')}</h2>
          <div className="quick-settings-grid">
            <div className="quick-setting-card">
              <Palette size={24} />
              <h3>{tr('Sötét mód', 'Dark mode')}</h3>
              <p>{darkMode ? tr('Bekapcsolva', 'Enabled') : tr('Kikapcsolva', 'Disabled')}</p>
              <button 
                className={`toggle-btn ${darkMode ? 'active' : ''}`}
                onClick={toggleDarkMode}
                aria-pressed={darkMode}
              >
                {darkMode ? tr('Kikapcsolás', 'Turn off') : tr('Bekapcsolás', 'Turn on')}
              </button>
            </div>

            <div className="quick-setting-card">
              <Eye size={24} />
              <h3>{tr('Magas kontraszt', 'High contrast')}</h3>
              <p>{highContrast ? tr('Bekapcsolva', 'Enabled') : tr('Kikapcsolva', 'Disabled')}</p>
              <button 
                className={`toggle-btn ${highContrast ? 'active' : ''}`}
                onClick={toggleHighContrast}
                aria-pressed={highContrast}
              >
                {highContrast ? tr('Kikapcsolás', 'Turn off') : tr('Bekapcsolás', 'Turn on')}
              </button>
            </div>

            <div className="quick-setting-card">
              <Type size={24} />
              <h3>{tr('Betűméret', 'Font size')}</h3>
              <p>{fontSize}px</p>
              <div className="font-controls">
                <button 
                  onClick={decreaseFontSize}
                  disabled={fontSize <= 12}
                  aria-label={tr('Betűméret csökkentése', 'Decrease font size')}
                >
                  A-
                </button>
                <button onClick={resetFontSize} aria-label={tr('Alapértelmezett betűméret', 'Default font size')}>
                  {tr('Alapértelmezett', 'Default')}
                </button>
                <button 
                  onClick={increaseFontSize}
                  disabled={fontSize >= 24}
                  aria-label={tr('Betűméret növelése', 'Increase font size')}
                >
                  A+
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="accessibility-features">
          <h2>{tr('Akadálymentességi funkciók', 'Accessibility features')}</h2>
          <div className="features-grid">
            {accessibilityFeatures.map(({ icon: Icon, title, features }) => (
              <div key={title} className="feature-card">
                <Icon size={32} />
                <h3>{title}</h3>
                <ul>
                  {features.map((feature, index) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Keyboard shortcuts */}
        <section className="accessibility-shortcuts">
          <h2>
            <Keyboard size={20} />
            {tr('Billentyűparancsok', 'Keyboard shortcuts')}
          </h2>
          <div className="shortcuts-table">
            <table>
              <thead>
                <tr>
                  <th>{tr('Billentyű', 'Key')}</th>
                  <th>{tr('Művelet', 'Action')}</th>
                </tr>
              </thead>
              <tbody>
                {shortcuts.map(({ keys, description }, index) => (
                  <tr key={index}>
                    <td>
                      {keys.map((key, i) => (
                        <span key={i}>
                          <kbd>{key}</kbd>
                          {i < keys.length - 1 && ' + '}
                        </span>
                      ))}
                    </td>
                    <td>{description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Standards */}
        <section className="accessibility-standards">
          <h2>{tr('Megfelelőség', 'Compliance')}</h2>
          <div className="standards-content">
            <p>
              {tr('A SuliRadio megfelel a következő akadálymentességi szabványoknak:', 'SuliRadio follows these accessibility standards:')}
            </p>
            <ul>
              <li>
                <strong>WCAG 2.1 Level AA</strong> - Web Content Accessibility Guidelines
              </li>
              <li>
                <strong>{tr('EU Akadálymentességi Irányelv', 'EU Accessibility Directive')}</strong> (2016/2102)
              </li>
              <li>
                <strong>{tr('Esélyegyenlőségi törvény', 'Equal Opportunities Act')}</strong> (2007. évi XXVI. törvény)
              </li>
            </ul>
            <p>
              {tr('Folyamatosan dolgozunk azon, hogy weboldalunk mindenki számára használható legyen. Ha bármilyen akadálymentességi problémát tapasztalsz, kérjük jelezd nekünk!', 'We keep improving the site so it stays usable for everyone. If you notice any accessibility issue, please let us know!')}
            </p>
          </div>
        </section>

        {/* Contact */}
        <section className="accessibility-contact">
          <h2>{tr('Segítségkérés', 'Need help?')}</h2>
          <p>
            {tr('Ha akadálymentességi problémát tapasztalsz vagy segítségre van szükséged:', 'If you experience an accessibility issue or need help:')}
          </p>
          <ul>
            <li>Email: <a href={`mailto:${RADIO_EMAIL}`}>{RADIO_EMAIL}</a></li>
            <li>{tr('Telefon', 'Phone')}: +36 1 234 5678</li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default AccessibilityPage;

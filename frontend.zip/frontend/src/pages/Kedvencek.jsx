﻿import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, 
  Music, 
  Play, 
  Trash2, 
  Search,
  X,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useMusic } from '../contexts/ZeneKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const FavoritesPage = () => {
  const { user, isLoggedIn, removeFromFavorites } = useUser();
  const { formatDuration, requestSongs, getSongById, loading: musicLoading } = useMusic();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);
  const [searchQuery, setSearchQuery] = useState('');
  const [message, setMessage] = useState(null);
  const [favoriteIds, setFavoriteIds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoggedIn || !user) {
      setFavoriteIds([]);
      setLoading(false);
      return;
    }

    setFavoriteIds(user.favorites || []);
    setLoading(false);
  }, [isLoggedIn, user]);

  if (!isLoggedIn || !user) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Heart size={64} />
          <h2>{tr('Nincs bejelentkezve', 'Not signed in')}</h2>
          <p>{tr('A kedvencek megtekintéséhez jelentkezz be.', 'Sign in to view your favorites.')}</p>
          <Link to="/bejelentkezes" className="btn btn-primary">{tr('Bejelentkezés', 'Log in')}</Link>
        </div>
      </div>
    );
  }

  const favoriteSongs = favoriteIds
    .map((songId) => getSongById(songId))
    .filter(Boolean);

  const filteredFavorites = favoriteSongs.filter(song => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      song.title.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query)
    );
  });

  const handleRemove = async (songId) => {
    await removeFromFavorites(songId);
    setFavoriteIds(prev => prev.filter(id => id !== songId));
    setMessage({ type: 'success', text: tr('Eltávolítva a kedvencekből!', 'Removed from favorites.') });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleRequest = async (songId) => {
    try {
      await requestSongs([songId], user.id);
      setMessage({ type: 'success', text: tr('Zene sikeresen kérve!', 'Song requested successfully.') });
    } catch {
      setMessage({ type: 'error', text: tr('Hiba történt!', 'Something went wrong.') });
    }
    setTimeout(() => setMessage(null), 3000);
  };

  return (
    <div className="page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Heart size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Kedvencek', 'Favorites')}</h1>
            <p className="page-subtitle">
              {tr(`${favoriteIds.length} kedvenc zene`, `${favoriteIds.length} favorite songs`)}
            </p>
          </div>
        </div>
      </section>

      {/* Message */}
      {message && (
        <div className={`result-banner ${message.type}`} role="alert">
          {message.type === 'success' ? <Heart size={20} /> : <AlertCircle size={20} />}
          <p>{message.text}</p>
          <button onClick={() => setMessage(null)}>×</button>
        </div>
      )}

      {loading || (musicLoading && favoriteIds.length > 0 && favoriteSongs.length === 0) ? (
        <div className="not-logged-in">
          <Loader2 size={48} className="spinning" />
          <p>{tr('Betöltés...', 'Loading...')}</p>
        </div>
      ) : favoriteIds.length === 0 ? (
        <div className="not-logged-in">
          <Heart size={64} />
          <h2>{tr('Még nincsenek kedvenceid', 'You do not have favorites yet')}</h2>
          <p>{tr('Böngéssz a zenék között és jelöld meg a kedvenceidet!', 'Browse the songs and save the ones you love.')}</p>
          <Link to="/" className="btn btn-primary">{tr('Zenék böngészése', 'Browse songs')}</Link>
        </div>
      ) : (
        <>
          {/* Search */}
          <div className="song-list-header" style={{ marginBottom: '1rem' }}>
            <div className="search-container">
              <Search size={20} className="search-icon" />
              <input
                type="search"
                placeholder={tr('Keresés a kedvencek között...', 'Search favorites...')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
              {searchQuery && (
                <button 
                  className="search-clear"
                  onClick={() => setSearchQuery('')}
                >
                  <X size={18} />
                </button>
              )}
            </div>
          </div>

          {/* Favorites list */}
          <div className="song-list-container">
            <div style={{ overflowX: 'auto' }}>
              <table className="song-table">
                <thead>
                  <tr>
                    <th style={{ width: '50%' }}>{tr('Zene', 'Song')}</th>
                    <th>{tr('Hossz', 'Duration')}</th>
                    <th>{tr('Műfaj', 'Genre')}</th>
                    <th style={{ width: '120px' }}>{tr('Műveletek', 'Actions')}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredFavorites.map(song => (
                    <tr key={song.id}>
                      <td>
                        <div className="song-info">
                          <div className="song-cover">
                            <Music size={20} />
                          </div>
                          <div className="song-details">
                            <span className="song-title">{song.title}</span>
                            <span className="song-artist">{song.artist}</span>
                          </div>
                        </div>
                      </td>
                      <td>{formatDuration(song.duration)}</td>
                      <td>{song.genre}</td>
                      <td>
                        <div className="song-actions">
                          <button 
                            className="song-action-btn"
                            onClick={() => handleRequest(song.id)}
                            title={tr('Zene kérése', 'Request song')}
                          >
                            <Play size={18} />
                          </button>
                          <button 
                            className="song-action-btn"
                            onClick={() => handleRemove(song.id)}
                            title={tr('Eltávolítás', 'Remove')}
                            style={{ color: 'var(--color-error)' }}
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredFavorites.length === 0 && searchQuery && (
              <div className="song-list-empty">
                <Search size={48} />
                <p>{tr(`Nincs találat a keresésre: "${searchQuery}"`, `No results for: "${searchQuery}"`)}</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default FavoritesPage;

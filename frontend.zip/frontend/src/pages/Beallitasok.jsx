﻿import { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Bell, 
  Volume2, 
  Moon, 
  Globe, 
  Shield, 
  Trash2,
  Download,
  RefreshCw
} from 'lucide-react';
import { useTheme } from '../contexts/TemaKontextus';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useCookies } from '../contexts/SutiKontextus';
import { useMusic } from '../contexts/ZeneKontextus';
import { useI18n } from '../contexts/NyelvKontextus';
import { DEFAULT_USER_PREFERENCES, favoritesAPI, notificationsAPI, preferencesAPI, requestsAPI, songsAPI } from '../services/api';

const SettingsPage = () => {
  const { darkMode, toggleDarkMode, highContrast, toggleHighContrast, fontSize, setFontSize, resetFontSize } = useTheme();
  const { user, preferences, isLoggedIn, updatePreferences, logout } = useUser();
  const { cookieConsent, resetConsent } = useCookies();
  const { volume, setVolume } = useMusic();
  const { language, t } = useI18n();
  const [exportState, setExportState] = useState({ status: 'idle', message: t('settings.exportStatusReady') });

  const settings = preferences ?? DEFAULT_USER_PREFERENCES;
  const currentVolume = Number.isFinite(settings?.volume) ? settings.volume : Math.round(volume * 100);

  const handlePreferenceChange = (key, value) => {
    updatePreferences({ [key]: value });
  };

  const handleVolumeChange = (nextVolume) => {
    setVolume(nextVolume / 100);
    updatePreferences({ volume: nextVolume });
  };

  const handleExportData = async () => {
    setExportState({ status: 'loading', message: t('settings.exportInProgress') });

    try {
      const [preferencesResult, notificationsResult, favoritesResult, historyResult, songsResult] = await Promise.all([
        preferencesAPI.get(),
        notificationsAPI.getAll(),
        favoritesAPI.getAll(),
        requestsAPI.history(),
        songsAPI.getAll(),
      ]);

      const songMap = new Map(
        (songsResult?.success ? songsResult.songs : []).map((song) => [song.id, song])
      );

      const favoriteIds = favoritesResult?.success ? favoritesResult.favorites : [];
      const favoriteSongs = favoriteIds.map((songId) => ({
        songId,
        song: songMap.get(songId) || null,
      }));

      const exportedAt = new Date().toISOString();
      const payload = {
        meta: {
          application: 'SuliRadio',
          exportVersion: 1,
          source: 'frontend',
          exportedAt,
          locale: language,
        },
        account: user ? {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          classGroup: user.classGroup || user.class || '',
          educationalId: user.educationalId || user.omazonosito || '',
        } : {
          guest: true,
        },
        preferences: preferencesResult?.success ? preferencesResult.preferences : settings,
        appearance: {
          darkMode,
          highContrast,
          fontSize,
        },
        audio: {
          preferredVolumePercent: currentVolume,
          liveGainPercent: Math.round(volume * 100),
          boosted: volume > 1,
        },
        privacy: {
          cookieConsent: cookieConsent ?? null,
        },
        activity: {
          favorites: favoriteSongs,
          notifications: notificationsResult?.success ? notificationsResult.notifications : [],
          requestHistory: historyResult?.success ? historyResult.history : [],
        },
        summary: {
          favoriteCount: favoriteSongs.length,
          notificationCount: notificationsResult?.success ? notificationsResult.notifications.length : 0,
          requestCount: historyResult?.success ? historyResult.history.length : 0,
        },
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
      const downloadUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = downloadUrl;
      anchor.download = `suliradio-adat-export-${exportedAt.replace(/[:.]/g, '-')}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(downloadUrl);

      setExportState({ status: 'success', message: t('settings.exportSuccess') });
    } catch {
      setExportState({ status: 'error', message: t('settings.exportError') });
    }
  };

  const handleResetAll = async () => {
    if (window.confirm(t('settings.resetConfirm'))) {
      await updatePreferences(DEFAULT_USER_PREFERENCES);
      setVolume(DEFAULT_USER_PREFERENCES.volume / 100);
      resetFontSize();
      if (darkMode) toggleDarkMode();
      if (highContrast) toggleHighContrast();
      resetConsent();
      setExportState({ status: 'idle', message: t('settings.exportStatusReady') });
    }
  };

  const handleDeleteAccount = () => {
    if (window.confirm(t('settings.deleteConfirm'))) {
      logout();
    }
  };

  return (
    <div className="page settings-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <SettingsIcon size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{t('settings.title')}</h1>
            <p className="page-subtitle">
              {t('settings.subtitle')}
            </p>
            <p className="settings-auto-save">{t('settings.autoSave')}</p>
          </div>
        </div>
      </section>

      <div className="settings-content">
        {/* Appearance */}
        <section className="settings-section">
          <h2>
            <Moon size={20} />
            {t('settings.appearance')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="dark-mode">{t('settings.darkModeLabel')}</label>
              <p>{t('settings.darkModeDescription')}</p>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                id="dark-mode"
                checked={darkMode}
                onChange={toggleDarkMode}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="high-contrast">{t('settings.highContrastLabel')}</label>
              <p>{t('settings.highContrastDescription')}</p>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                id="high-contrast"
                checked={highContrast}
                onChange={toggleHighContrast}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="font-size">{t('settings.fontSizeLabel')}</label>
              <p>{t('settings.fontSizeValue', { value: fontSize })}</p>
            </div>
            <div className="font-size-controls">
              <button 
                onClick={() => setFontSize(Math.max(12, fontSize - 2))}
                disabled={fontSize <= 12}
                aria-label={t('settings.decreaseFontSize')}
              >
                A-
              </button>
              <input
                type="range"
                id="font-size"
                min="12"
                max="24"
                value={fontSize}
                onChange={(e) => setFontSize(parseInt(e.target.value))}
              />
              <button 
                onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                disabled={fontSize >= 24}
                aria-label={t('settings.increaseFontSize')}
              >
                A+
              </button>
            </div>
          </div>
        </section>

        {/* Notifications */}
        <section className="settings-section">
          <h2>
            <Bell size={20} />
            {t('settings.notifications')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="notifications">{t('settings.pushNotificationsLabel')}</label>
              <p>{t('settings.pushNotificationsDescription')}</p>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                id="notifications"
                checked={settings.notifications}
                onChange={(e) => handlePreferenceChange('notifications', e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="email-notifications">{t('settings.emailNotificationsLabel')}</label>
              <p>{t('settings.emailNotificationsDescription')}</p>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                id="email-notifications"
                checked={settings.emailNotifications}
                onChange={(e) => handlePreferenceChange('emailNotifications', e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </section>

        {/* Audio */}
        <section className="settings-section">
          <h2>
            <Volume2 size={20} />
            {t('settings.audio')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="autoplay">{t('settings.autoplayLabel')}</label>
              <p>{t('settings.autoplayDescription')}</p>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                id="autoplay"
                checked={settings.autoplay}
                onChange={(e) => handlePreferenceChange('autoplay', e.target.checked)}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="volume">{t('settings.volumeLabel')}</label>
              <p>{t('settings.volumeDescription', { value: currentVolume })}</p>
            </div>
            <input
              type="range"
              id="volume"
              min="0"
              max="200"
              value={currentVolume}
              onChange={(e) => handleVolumeChange(parseInt(e.target.value, 10))}
              className="volume-slider"
            />
          </div>
        </section>

        {/* Language */}
        <section className="settings-section">
          <h2>
            <Globe size={20} />
            {t('settings.languageSection')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label htmlFor="language">{t('settings.languageLabel')}</label>
              <p>{t('settings.languageDescription')}</p>
            </div>
            <select
              id="language"
              value={settings.language}
              onChange={(e) => handlePreferenceChange('language', e.target.value)}
              className="setting-select"
            >
              <option value="hu">Magyar</option>
              <option value="en">English</option>
            </select>
          </div>
        </section>

        {/* Privacy */}
        <section className="settings-section">
          <h2>
            <Shield size={20} />
            {t('settings.privacy')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label>{t('settings.cookieSettingsLabel')}</label>
              <p>{t('settings.cookieSettingsDescription')}</p>
            </div>
            <button className="btn btn-secondary" onClick={resetConsent}>
              {t('settings.modify')}
            </button>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label>{t('settings.downloadMyDataLabel')}</label>
              <p>{t('settings.downloadMyDataDescription')}</p>
            </div>
            <button className="btn btn-secondary" onClick={handleExportData} disabled={exportState.status === 'loading'}>
              <Download size={18} />
              {exportState.status === 'loading' ? t('settings.preparingDownload') : t('settings.download')}
            </button>
          </div>

          <p className={`settings-status ${exportState.status}`} role="status" aria-live="polite">
            {exportState.message}
          </p>
        </section>

        {/* Danger zone */}
        <section className="settings-section danger-zone">
          <h2>
            <Trash2 size={20} />
            {t('settings.dangerZone')}
          </h2>
          
          <div className="setting-item">
            <div className="setting-info">
              <label>{t('settings.resetSettingsLabel')}</label>
              <p>{t('settings.resetSettingsDescription')}</p>
            </div>
            <button className="btn btn-warning" onClick={handleResetAll}>
              <RefreshCw size={18} />
              {t('settings.reset')}
            </button>
          </div>

          {isLoggedIn && (
            <div className="setting-item">
              <div className="setting-info">
                <label>{t('settings.deleteAccountLabel')}</label>
                <p>{t('settings.deleteAccountDescription')}</p>
              </div>
              <button className="btn btn-danger" onClick={handleDeleteAccount}>
                <Trash2 size={18} />
                {t('settings.deleteAccountButton')}
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default SettingsPage;

﻿import { Music, Calendar, Users } from 'lucide-react';
import AppLogo from '../components/AppLogo';
import NowPlaying from '../components/MostJatszik';
import SongList from '../components/ZeneLista';
import { useMusic } from '../contexts/ZeneKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const HomePage = () => {
  const { stats } = useMusic();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const statItems = [
    { icon: Users, label: tr('Regisztrált felhasználók', 'Registered users'), value: stats.totalUsers },
    { icon: Users, label: tr('Aktív felhasználók', 'Active users'), value: stats.activeUsers },
    { icon: Music, label: tr('Elérhető zenék', 'Available songs'), value: stats.totalSongs },
    { icon: Calendar, label: tr('Mai kérések', 'Requests today'), value: stats.todayRequests },
  ];

  return (
    <div className="page home-page">
      {/* Hero section */}
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-background">
          <div className="hero-gradient" />
          <div className="hero-pattern" />
        </div>
        <div className="hero-content">
          <div className="hero-icon">
            <AppLogo className="hero-logo-image" decorative />
          </div>
          <h1 id="hero-title" className="hero-title">
            {tr('Üdvözlünk a', 'Welcome to')} <span className="highlight">SuliRadio</span>{tr('-ban!', '!')}
          </h1>
          <p className="hero-subtitle">
            {tr('A Nemes Tihamér Technikum rádiója, ahol Te döntöd el, mi szóljon! Kérj zenét, nézd meg a műsort, és légy részese a közösségnek.', 'The radio of Nemes Tihamer Technikum, where you decide what plays next. Request songs, browse the schedule, and be part of the community.')}
          </p>
        </div>
      </section>

      {/* Now playing */}
      <section aria-label={tr('Most játszott zene', 'Now playing song')}>
        <NowPlaying />
      </section>

      {/* Stats */}
      <section className="stats-section" aria-label={tr('Statisztikák', 'Statistics')}>
        <div className="stats-grid">
          {statItems.map(({ icon: Icon, label, value }) => (
            <div key={label} className="stat-card">
              <Icon size={24} className="stat-icon" aria-hidden="true" />
              <div className="stat-info">
                <span className="stat-value">{value}</span>
                <span className="stat-label">{label}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Song list */}
      <section className="songs-section" aria-labelledby="songs-title">
        <div className="section-header">
          <h2 id="songs-title" className="section-title">
            <Music size={24} />
            {tr('Zenék böngészése', 'Browse songs')}
          </h2>
          <p className="section-subtitle">
            {tr('Válaszd ki a kedvenc zenéidet és kérd őket a rádiótól!', 'Pick your favorite songs and request them from the radio!')}
          </p>
        </div>
        <SongList />
      </section>
    </div>
  );
};

export default HomePage;
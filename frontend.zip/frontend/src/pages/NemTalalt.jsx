import { Link } from 'react-router-dom';
import { Home, AlertTriangle } from 'lucide-react';
import { useI18n } from '../contexts/NyelvKontextus';

const NotFoundPage = () => {
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  return (
    <div className="page not-found-page">
      <div className="not-found-content">
        <AlertTriangle size={80} className="not-found-icon" />
        <h1>404</h1>
        <h2>{tr('Az oldal nem található', 'Page not found')}</h2>
        <p>
          {tr('A keresett oldal nem létezik vagy áthelyezésre került. Ellenőrizd az URL-t vagy térj vissza a főoldalra.', 'The page you are looking for does not exist or has been moved. Check the URL or return to the home page.')}
        </p>
        <Link to="/" className="btn btn-primary">
          <Home size={20} />
          {tr('Vissza a főoldalra', 'Back to home')}
        </Link>
      </div>
    </div>
  );
};

export default NotFoundPage;

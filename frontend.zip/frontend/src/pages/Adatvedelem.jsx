import { 
  Shield, 
  Database, 
  Lock, 
  Eye, 
  Mail,
  FileText,
  Clock
} from 'lucide-react';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL, SCHOOL_NAME } from '../constants/appInfo';

const PrivacyPage = () => {
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);
  const lastUpdated = language === 'en' ? '15 January 2026' : '2026. január 15.';

  return (
    <div className="page privacy-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Shield size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Adatvédelem', 'Privacy')}</h1>
            <p className="page-subtitle">
              {tr('Hogyan kezeljük az adataidat', 'How we handle your data')}
            </p>
          </div>
        </div>
      </section>

      <div className="privacy-content">
        <div className="privacy-meta">
          <Clock size={16} />
          <span>{tr('Frissítve', 'Updated')}: {lastUpdated}</span>
        </div>

        <section className="privacy-section">
          <h2>
            <FileText size={20} />
            {tr('Röviden', 'In short')}
          </h2>
          <p>
            {tr(
              `A SuliRadio a ${SCHOOL_NAME} diákrádiója. Az oldalon tárolt adataidat biztonságban kezeljük és harmadik félnek nem adjuk ki.`,
              `SuliRadio is the student radio of ${SCHOOL_NAME}. We handle the data stored on this site securely and do not share it with third parties.`
            )}
          </p>
        </section>

        <section className="privacy-section">
          <h2>
            <Database size={20} />
            {tr('Mit tárolunk?', 'What do we store?')}
          </h2>
          <ul>
            <li>{tr('Neved és email címed', 'Your name and email address')}</li>
            <li>{tr('Oktatási azonosítód és osztályod', 'Your education ID and class')}</li>
            <li>{tr('Zenekéréseid és kedvenceid', 'Your music requests and favorites')}</li>
            <li>{tr('Beállításaid (pl. téma, értesítések)', 'Your preferences, such as theme and notifications')}</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>
            <Eye size={20} />
            {tr('Mire használjuk?', 'What do we use it for?')}
          </h2>
          <ul>
            <li>{tr('Bejelentkezéshez és azonosításhoz', 'Signing in and identifying your account')}</li>
            <li>{tr('Zenekérések feldolgozásához', 'Processing music requests')}</li>
            <li>{tr('A felhasználói élmény javításához', 'Improving the user experience')}</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>
            <Lock size={20} />
            {tr('Biztonság', 'Security')}
          </h2>
          <p>
            {tr(
              'Az adataid védelmére modern titkosítást használunk. Jelszavadat hash-elve tároljuk, még mi sem tudjuk elolvasni.',
              'We use modern encryption to protect your data. Your password is stored as a hash, so even we cannot read it.'
            )}
          </p>
        </section>

        <section className="privacy-section">
          <h2>
            <Mail size={20} />
            {tr('Kapcsolat', 'Contact')}
          </h2>
          <p>
            {tr('Ha kérdésed van az adatkezeléssel kapcsolatban, írj nekünk:', 'If you have any questions about data handling, contact us at:')}
          </p>
          <ul>
            <li>Email: <a href={`mailto:${RADIO_EMAIL}`}>{RADIO_EMAIL}</a></li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPage;
import { 
  FileText, 
  CheckCircle,
  XCircle,
  Mail
} from 'lucide-react';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL, SCHOOL_NAME } from '../constants/appInfo';

const TermsPage = () => {
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  return (
    <div className="page privacy-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <FileText size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Használati útmutató', 'Terms of use')}</h1>
            <p className="page-subtitle">
              {tr('A SuliRadio használatának egyszerű szabályai', 'Simple rules for using SuliRadio')}
            </p>
          </div>
        </div>
      </section>

      <div className="privacy-content">
        <section className="privacy-section">
          <h2>
            <FileText size={20} />
            {tr('Mi ez az oldal?', 'What is this site?')}
          </h2>
          <p>
            {tr(
              `A SuliRadio a ${SCHOOL_NAME} diákrádiója. Itt tudsz zenét kérni, ami szünetekben szólni fog az iskola hangszóróin!`,
              `SuliRadio is the student radio of ${SCHOOL_NAME}. Here you can request music that will play through the school speakers during breaks.`
            )}
          </p>
        </section>

        <section className="privacy-section">
          <h2>
            <CheckCircle size={20} />
            {tr('Ezt csinálhatod', 'What you can do')}
          </h2>
          <ul>
            <li>{tr('Böngészheted a zenéket és kedvenceket menthetsz', 'Browse songs and save favorites')}</li>
            <li>{tr('Zenéket kérhetsz a rádióba', 'Request songs for the radio')}</li>
            <li>{tr('Új zenéket javasolhatsz', 'Suggest new songs')}</li>
            <li>{tr('Megnézheted a műsorrendet', 'View the schedule')}</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>
            <XCircle size={20} />
            {tr('Ez nem oké', 'What is not allowed')}
          </h2>
          <ul>
            <li>{tr('Trágár, sértő zenék kérése', 'Requesting offensive or explicit songs')}</li>
            <li>{tr('Más diákok zaklatása', 'Harassing other students')}</li>
            <li>{tr('Spam küldése', 'Sending spam')}</li>
            <li>{tr('Hamis adatok megadása', 'Submitting false information')}</li>
          </ul>
          <p>
            {tr(
              'Ha valaki nem tartja be a szabályokat, a fiókját ideiglenesen vagy véglegesen letilthatjuk.',
              'If someone does not follow the rules, their account may be suspended temporarily or permanently.'
            )}
          </p>
        </section>

        <section className="privacy-section">
          <h2>
            <Mail size={20} />
            {tr('Kérdésed van?', 'Do you have a question?')}
          </h2>
          <p>
            {tr('Írj nekünk', 'Contact us at')}: <a href={`mailto:${RADIO_EMAIL}`}>{RADIO_EMAIL}</a>
          </p>
        </section>
      </div>
    </div>
  );
};

export default TermsPage;
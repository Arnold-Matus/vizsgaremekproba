﻿import { useEffect, useState } from 'react';
import { 
  User, 
  Mail, 
  Shield, 
  History, 
  Heart, 
  Edit2, 
  Save, 
  X,
  Music,
  Calendar,
  Clock,
  Award
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { useMusic } from '../contexts/ZeneKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const ProfilePage = () => {
  const { user, isLoggedIn, updateUser } = useUser();
  const { getSongById, formatDuration } = useMusic();
  const { language } = useI18n();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    class_group: user?.classGroup || user?.class || '',
    educationalId: user?.educationalId || user?.omazonosito || ''
  });
  const isDemoUser = user?.role === 'demo' || user?.jog === 1;
  const tr = (hu, en) => (language === 'en' ? en : hu);

  useEffect(() => {
    if (!user) return;

    setEditData({
      name: user.name || '',
      email: user.email || '',
      class_group: user.classGroup || user.class || '',
      educationalId: user.educationalId || user.omazonosito || '',
    });
  }, [user]);

  if (!isLoggedIn || !user) {
    return (
      <div className="page profile-page">
        <div className="not-logged-in">
          <User size={64} />
          <h2>{tr('Nincs bejelentkezve', 'Not signed in')}</h2>
          <p>{tr('A profil megtekintéséhez jelentkezz be.', 'Sign in to view your profile.')}</p>
          <a href="/bejelentkezes" className="btn btn-primary">{tr('Bejelentkezés', 'Sign in')}</a>
        </div>
      </div>
    );
  }

  const handleSave = async () => {
    const result = await updateUser({
      name: editData.name,
      email: editData.email,
      class_group: editData.class_group,
      educationalId: editData.educationalId,
    });

    if (result?.success) {
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditData({
      name: user.name,
      email: user.email,
      class_group: user.classGroup || user.class || '',
      educationalId: user.educationalId || user.omazonosito || '',
    });
    setIsEditing(false);
  };

  const stats = [
    { icon: Music, label: tr('Kért zenék', 'Requested songs'), value: user.requestHistory?.length || 0 },
    { icon: Heart, label: tr('Kedvencek', 'Favorites'), value: user.favorites?.length || 0 },
    { icon: Calendar, label: tr('Tag óta', 'Member since'), value: user.createdAt ? new Date(user.createdAt).toLocaleDateString(language === 'en' ? 'en-GB' : 'hu-HU') : '-' },
  ];

  const roleLabels = {
    admin: tr('Adminisztrátor', 'Administrator'),
    tanar: tr('Tanár', 'Teacher'),
    teacher: tr('Tanár', 'Teacher'),
    user: tr('Felhasználó', 'User'),
    student: tr('Diák', 'Student'),
    demo: 'Demo',
  };

  return (
    <div className="page profile-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <User size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Profil', 'Profile')}</h1>
            <p className="page-subtitle">
              {tr('Személyes adataid és statisztikáid', 'Your personal details and statistics')}
            </p>
          </div>
        </div>
      </section>

      <div className="profile-content">
        {/* Profile card */}
        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-avatar-large">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} />
              ) : (
                <span>{user.name.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="profile-actions">
              {isEditing ? (
                <>
                  <button className="btn btn-secondary" onClick={handleCancel}>
                    <X size={18} />
                    {tr('Mégse', 'Cancel')}
                  </button>
                  <button className="btn btn-primary" onClick={handleSave}>
                    <Save size={18} />
                    {tr('Mentés', 'Save')}
                  </button>
                </>
              ) : (
                <button
                  className="btn btn-secondary"
                  onClick={() => setIsEditing(true)}
                  disabled={isDemoUser}
                  title={isDemoUser ? tr('A demo felhasználó profiladatai nem szerkeszthetők.', 'Demo user profile details cannot be edited.') : tr('Profil szerkesztése', 'Edit profile')}
                  style={isDemoUser ? { opacity: 0.55, cursor: 'not-allowed', filter: 'grayscale(1)' } : undefined}
                >
                  <Edit2 size={18} />
                  {tr('Szerkesztés', 'Edit')}
                </button>
              )}
            </div>
          </div>

          {isDemoUser && !isEditing && (
            <p style={{ margin: '0 0 1rem', color: 'var(--color-text-secondary)' }}>
              {tr('A demo fiókban a profiladatok csak megtekinthetők.', 'Profile details are view-only in the demo account.')}
            </p>
          )}

          <div className="profile-info">
            {isEditing ? (
              <div className="profile-form">
                <div className="form-group">
                  <label htmlFor="name">
                    <User size={16} />
                    {tr('Név', 'Name')}
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={editData.name}
                    onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="email">
                    <Mail size={16} />
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={editData.email}
                    onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="class">
                    <Award size={16} />
                    {tr('Osztály', 'Class')}</label>
                  <input
                    type="text"
                    id="class"
                    value={editData.class_group}
                    onChange={(e) => setEditData({ ...editData, class_group: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="educationalId">
                    <Shield size={16} />
                    {tr('OM azonosító', 'Education ID')}
                  </label>
                  <input
                    type="text"
                    id="educationalId"
                    value={editData.educationalId}
                    onChange={(e) => setEditData({ ...editData, educationalId: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>
            ) : (
              <div className="profile-details">
                <div className="profile-detail">
                  <User size={18} />
                  <span className="detail-label">{tr('Név:', 'Name:')}</span>
                  <span className="detail-value">{user.name}</span>
                </div>
                <div className="profile-detail">
                  <Mail size={18} />
                  <span className="detail-label">Email:</span>
                  <span className="detail-value">{user.email}</span>
                </div>
                <div className="profile-detail">
                  <Award size={18} />
                  <span className="detail-label">{tr('Osztály:', 'Class:')}</span>
                  <span className="detail-value">{user.classGroup || user.class || '-'}</span>
                </div>
                <div className="profile-detail">
                  <Shield size={18} />
                  <span className="detail-label">{tr('OM azonosító:', 'Education ID:')}</span>
                  <span className="detail-value">{user.educationalId || user.omazonosito || '-'}</span>
                </div>
                <div className="profile-detail">
                  <Shield size={18} />
                  <span className="detail-label">{tr('Szerepkör:', 'Role:')}</span>
                  <span className="detail-value role-badge">{roleLabels[user.role] || tr('Felhasználó', 'User')}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="profile-stats">
          {stats.map(({ icon: Icon, label, value }) => (
            <div key={label} className="stat-card">
              <Icon size={24} className="stat-icon" />
              <div className="stat-info">
                <span className="stat-value">{value}</span>
                <span className="stat-label">{label}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Favorites */}
        {user.favorites?.length > 0 && (
          <div className="profile-section">
            <h2>
              <Heart size={20} />
              {tr('Kedvenc zenék', 'Favorite songs')}
            </h2>
            <div className="favorites-list">
              {user.favorites.slice(0, 5).map(songId => {
                const song = getSongById(songId);
                return song ? (
                  <div key={songId} className="favorite-item">
                    <div className="favorite-cover">
                      <Music size={20} />
                    </div>
                    <div className="favorite-info">
                      <span className="favorite-title">{song.title}</span>
                      <span className="favorite-artist">{song.artist}</span>
                    </div>
                    <span className="favorite-duration">{formatDuration(song.duration)}</span>
                  </div>
                ) : null;
              })}
            </div>
          </div>
        )}

        {/* Request history */}
        {user.requestHistory?.length > 0 && (
          <div className="profile-section">
            <h2>
              <History size={20} />
              {tr('Legutóbbi kérések', 'Recent requests')}
            </h2>
            <div className="history-list">
              {user.requestHistory.slice(0, 5).map((request, index) => (
                <div key={index} className="history-item">
                  <Clock size={16} />
                  <span>{new Date(request.requestedAt).toLocaleString(language === 'en' ? 'en-GB' : 'hu-HU')}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;

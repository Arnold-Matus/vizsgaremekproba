﻿import { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  Music, 
  Play, 
  CheckCircle, 
  Circle,
  RefreshCw,
  Filter,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useMusic } from '../contexts/ZeneKontextus';
import { useI18n } from '../contexts/NyelvKontextus';

const SchedulePage = () => {
  const { formatDuration, loadSchedule } = useMusic();
  const { language } = useI18n();
  const [schedule, setSchedule] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const refreshSchedule = useCallback(() => {
    loadSchedule(selectedDate).then(data => {
      if (data) setSchedule(data.map(item => ({
        ...item,
        song: item.song || null
      })));
    });
  }, [selectedDate, loadSchedule]);

  useEffect(() => {
    refreshSchedule();
    // Auto-refresh every 15 seconds
    const interval = setInterval(refreshSchedule, 15000);
    return () => clearInterval(interval);
  }, [refreshSchedule]);

  const toDateKey = (value) => {
    const date = value instanceof Date ? value : new Date(value);
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, '0');
    const day = `${date.getDate()}`.padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const scheduleWithStatus = useMemo(() => {
    const now = new Date();
    const selectedDateKey = toDateKey(selectedDate);
    const todayKey = toDateKey(now);

    return [...schedule]
      .map((item) => {
        const startTime = new Date(item.startTime);
        const endTime = item.endTime ? new Date(item.endTime) : new Date(item.startTime);

        let status = 'pending';
        if (selectedDateKey < todayKey) {
          status = 'completed';
        } else if (selectedDateKey === todayKey) {
          if (now >= endTime) {
            status = 'completed';
          } else if (now >= startTime && now < endTime) {
            status = 'playing';
          }
        }

        return {
          ...item,
          status,
          time: startTime.toLocaleTimeString(language === 'en' ? 'en-GB' : 'hu-HU', { hour: '2-digit', minute: '2-digit' }),
          endLabel: endTime.toLocaleTimeString(language === 'en' ? 'en-GB' : 'hu-HU', { hour: '2-digit', minute: '2-digit' }),
        };
      })
      .sort((left, right) => new Date(left.startTime) - new Date(right.startTime));
  }, [language, schedule, selectedDate]);

  const filteredSchedule = scheduleWithStatus.filter(item => {
    if (filterStatus === 'all') return true;
    return item.status === filterStatus;
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={18} className="status-icon completed" />;
      case 'playing':
        return <Play size={18} className="status-icon playing" />;
      default:
        return <Circle size={18} className="status-icon pending" />;
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'completed':
        return tr('Lejátszva', 'Played');
      case 'playing':
        return tr('Most játszik', 'Now playing');
      case 'pending':
        return tr('Időzítve', 'Scheduled');
      default:
        return tr('Várakozik', 'Pending');
    }
  };

  const formatDate = (date) => {
    return date.toLocaleDateString(language === 'en' ? 'en-GB' : 'hu-HU', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const changeDate = (days) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + days);
    setSelectedDate(newDate);
  };

  const isToday = selectedDate.toDateString() === new Date().toDateString();

  return (
    <div className="page schedule-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Calendar size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Műsorrend', 'Schedule')}</h1>
            <p className="page-subtitle">
              {tr('Nézd meg, mikor mi fog szólni az iskolai rádióban!', 'See what will play on the school radio and when!')}
            </p>
          </div>
        </div>
      </section>

      {/* Date navigation */}
      <div className="schedule-date-nav">
        <button 
          className="date-nav-btn"
          onClick={() => changeDate(-1)}
          aria-label={tr('Előző nap', 'Previous day')}
        >
          <ChevronLeft size={20} />
        </button>
        <div className="date-display">
          <span className="date-text">{formatDate(selectedDate)}</span>
          {isToday && <span className="today-badge">{tr('Ma', 'Today')}</span>}
        </div>
        <button 
          className="date-nav-btn"
          onClick={() => changeDate(1)}
          aria-label={tr('Következő nap', 'Next day')}
        >
          <ChevronRight size={20} />
        </button>
        {!isToday && (
          <button 
            className="today-btn"
            onClick={() => setSelectedDate(new Date())}
          >
            {tr('Mai nap', 'Today')}
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="schedule-filters">
        <div className="filter-group" style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Filter size={18} />
          <label htmlFor="status-filter" className="visually-hidden">{tr('Állapot szűrő', 'Status filter')}</label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="all">{tr('Összes', 'All')}</option>
            <option value="completed">{tr('Lejátszott', 'Played')}</option>
            <option value="playing">{tr('Most játszik', 'Now playing')}</option>
            <option value="pending">{tr('Időzített', 'Scheduled')}</option>
          </select>
        </div>
        <button className="refresh-btn" onClick={refreshSchedule} aria-label={tr('Frissítés', 'Refresh')}>
          <RefreshCw size={18} />
          <span>{tr('Frissítés', 'Refresh')}</span>
        </button>
      </div>

      {/* Schedule table */}
      <div className="schedule-table-wrapper">
        <table className="schedule-table" role="grid" aria-label={tr('Műsorrend táblázat', 'Schedule table')}>
          <thead>
            <tr>
              <th className="th-time">
                <Clock size={16} />
                <span>{tr('Időpont', 'Time')}</span>
              </th>
              <th className="th-status">{tr('Állapot', 'Status')}</th>
              <th className="th-song">
                <Music size={16} />
                <span>{tr('Zene', 'Song')}</span>
              </th>
              <th className="th-duration">{tr('Hossz', 'Length')}</th>
              <th className="th-requester">
                <span>{tr('Vége', 'Ends')}</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredSchedule.length === 0 ? (
              <tr>
                <td colSpan="5" className="no-results">
                  <Calendar size={48} />
                  <p>{tr('Nincs megjeleníthető műsorrend.', 'No schedule items to display.')}</p>
                </td>
              </tr>
            ) : (
              filteredSchedule.map((item) => (
                <tr 
                  key={item.id} 
                  className={`schedule-row ${item.status}`}
                  aria-current={item.status === 'playing' ? 'true' : undefined}
                >
                  <td className="td-time">
                    <span className="time-badge">{item.time}</span>
                  </td>
                  <td className="td-status">
                    <div className={`status-badge ${item.status}`}>
                      {getStatusIcon(item.status)}
                      <span>{getStatusLabel(item.status)}</span>
                    </div>
                  </td>
                  <td className="td-song">
                    {item.song ? (
                      <div className="song-cell">
                        <div className="song-cover-small">
                          {item.song.coverUrl ? (
                            <img src={item.song.coverUrl} alt="" />
                          ) : (
                            <Music size={16} />
                          )}
                        </div>
                        <div className="song-info">
                          <span className="song-title">{item.song.title}</span>
                          <span className="song-artist">{item.song.artist}</span>
                        </div>
                      </div>
                    ) : (
                      <span className="unknown">{tr('Ismeretlen zene', 'Unknown song')}</span>
                    )}
                  </td>
                  <td className="td-duration">
                    {item.song ? formatDuration(item.song.duration) : '-'}
                  </td>
                  <td className="td-requester">
                    <span>{item.endLabel}</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      <div className="schedule-legend" role="note" aria-label={tr('Jelmagyarázat', 'Legend')}>
        <h3 className="legend-title">{tr('Jelmagyarázat', 'Legend')}</h3>
        <div className="legend-items">
          <div className="legend-item">
            <CheckCircle size={16} className="completed" />
            <span>{tr('Lejátszott', 'Played')}</span>
          </div>
          <div className="legend-item">
            <Play size={16} className="playing" />
            <span>{tr('Most játszik', 'Now playing')}</span>
          </div>
          <div className="legend-item">
            <Circle size={16} className="pending" />
            <span>{tr('Időzítve', 'Scheduled')}</span>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="schedule-info">
        <p>
          {tr('Itt a kiválasztott naphoz tartozó időzített műsort látod, így külön megnézheted a tegnapi, a mai és a holnapi beállított zenéket is. Az admin által ütemezett zenék automatikusan megjelennek a megfelelő napnál.', 'Here you can see the scheduled program for the selected day, so you can check yesterday, today, and tomorrow separately. Songs scheduled by the admin appear automatically on the correct day.')}
        </p>
      </div>
    </div>
  );
};

export default SchedulePage;

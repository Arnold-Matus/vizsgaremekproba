import { useState } from 'react';
import { 
  Info, 
  Users, 
  Target, 
  Heart, 
  MapPin, 
  Mail, 
  Phone, 
  Music,
  Headphones,
  Volume2
} from 'lucide-react';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL, SCHOOL_EMAIL, SCHOOL_NAME } from '../constants/appInfo';
import AppLogo from '../components/AppLogo';

const AboutPage = () => {
  const [activeSection, setActiveSection] = useState('about');
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const teamMembers = [
    {
      name: 'Rákóczi Botond',
      role: tr('Fejlesztő', 'Developer'),
      description: tr('Adatbázis és asztali alkalmazás fejlesztés', 'Database and desktop application development'),
      class: '13.B'
    },
    {
      name: 'Matus Arnold',
      role: tr('Fejlesztő', 'Developer'),
      description: tr('Rendszertervezés és backend fejlesztés', 'System design and backend development'),
      class: '13.B'
    },
    {
      name: 'Sütő Zsolt Márk',
      role: tr('Fejlesztő', 'Developer'),
      description: tr('UI/UX tervezés és frontend fejlesztés', 'UI/UX design and frontend development'),
      class: '13.B'
    }
  ];

  return (
    <div className="page about-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Info size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Rólunk', 'About')}</h1>
            <p className="page-subtitle">
              {tr('Ismerd meg a SuliRadio csapatát és az iskolát!', 'Meet the SuliRadio team and learn more about our school.')}
            </p>
          </div>
        </div>
      </section>

      {/* Navigation tabs */}
      <div className="about-tabs" role="tablist">
        <button
          role="tab"
          aria-selected={activeSection === 'about'}
          className={`about-tab ${activeSection === 'about' ? 'active' : ''}`}
          onClick={() => setActiveSection('about')}
        >
          <AppLogo className="about-tab-logo" decorative />
          <span>{tr('A SuliRadióról', 'About SuliRadio')}</span>
        </button>
        <button
          role="tab"
          aria-selected={activeSection === 'team'}
          className={`about-tab ${activeSection === 'team' ? 'active' : ''}`}
          onClick={() => setActiveSection('team')}
        >
          <Users size={18} />
          <span>{tr('Csapatunk', 'Our team')}</span>
        </button>
        <button
          role="tab"
          aria-selected={activeSection === 'school'}
          className={`about-tab ${activeSection === 'school' ? 'active' : ''}`}
          onClick={() => setActiveSection('school')}
        >
          <Target size={18} />
          <span>{tr('Az iskoláról', 'About the school')}</span>
        </button>
      </div>

      {/* Content sections */}
      <div className="about-content">
        {activeSection === 'about' && (
          <div className="about-section" role="tabpanel">
            <div className="about-hero">
              <div className="about-hero-icon">
                <AppLogo className="about-hero-logo" decorative />
              </div>
              <h2>{tr('Mi az a SuliRadio?', 'What is SuliRadio?')}</h2>
              <p className="about-lead">
                {tr('A SuliRadio az iskolánk hivatalos belső rádiója, amelyet diákok készítenek diákoknak.', 'SuliRadio is our school’s official in-house radio, built by students for students.')}
              </p>
            </div>

            <div className="about-features">
              <div className="feature-card">
                <Music size={32} />
                <h3>{tr('Zenekérés', 'Music requests')}</h3>
                <p>
                  {tr('Te döntöd el, mi szóljon! Válassz a könyvtárból vagy küldj be saját javaslatot.', 'You decide what plays next. Pick from the library or send in your own suggestion.')}
                </p>
              </div>
              <div className="feature-card">
                <Headphones size={32} />
                <h3>{tr('Közösségi élmény', 'Shared school experience')}</h3>
                <p>
                  {tr('Hallgasd együtt az iskolával a kedvenc zenéidet szünetekben és rendezvényeken.', 'Enjoy your favorite tracks together with the whole school during breaks and events.')}
                </p>
              </div>
              <div className="feature-card">
                <Volume2 size={32} />
                <h3>{tr('Minőségi hangzás', 'Quality sound')}</h3>
                <p>
                  {tr('Modern hangrendszer az iskola minden pontján a legjobb hangélményért.', 'A modern sound system reaches every part of the school for the best listening experience.')}
                </p>
              </div>
            </div>

            <div className="about-story">
              <h3>{tr('A projekt története', 'How the project started')}</h3>
              <p>
                {tr('A SuliRadio ötlete 2025 őszén született, amikor egy csoport lelkes diák elhatározta, hogy életet lehel az iskola régi rádiójába. A projekt vizsgamunkaként indult, de hamar az egész iskola közösségének kedvence lett.', 'The idea for SuliRadio was born in the autumn of 2025, when a group of motivated students decided to bring the school’s old radio system back to life. It began as a graduation project, then quickly became a favorite across the whole school.')}
              </p>
              <p>
                {tr('Célunk, hogy egy olyan platformot hozzunk létre, ahol mindenki hallathatja a hangját - szó szerint! A zenekérés demokratikus, a műsor változatos, és az egész rendszert mi, diákok fejlesztjük és üzemeltetjük.', 'Our goal is to build a platform where everyone can have a voice, literally. Music requests stay open and fair, the programming stays varied, and the whole system is developed and operated by students.')}
              </p>
            </div>

            <div className="about-values">
              <h3>{tr('Értékeink', 'Our values')}</h3>
              <div className="values-grid">
                <div className="value-item">
                  <Heart size={24} />
                  <h4>{tr('Közösség', 'Community')}</h4>
                  <p>{tr('Összekötjük az iskola diákjait a zene erejével.', 'We connect students across the school through music.')}</p>
                </div>
                <div className="value-item">
                  <Target size={24} />
                  <h4>{tr('Minőség', 'Quality')}</h4>
                  <p>{tr('Csak a legjobb zenék és a legjobb hangzás.', 'Only the best songs and the best sound.')}</p>
                </div>
                <div className="value-item">
                  <Users size={24} />
                  <h4>{tr('Részvétel', 'Participation')}</h4>
                  <p>{tr('Mindenki beleszólhat a műsorba.', 'Everyone can help shape the playlist.')}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'team' && (
          <div className="team-section" role="tabpanel">
            <h2>{tr('Ismerd meg a csapatot!', 'Meet the team')}</h2>
            <p className="team-intro">
              {tr('Mi vagyunk a SuliRadio mögött álló lelkes diákok, akik vizsgamunkaként álmodták meg és valósították meg ezt a projektet.', 'We are the students behind SuliRadio, the team that imagined and delivered this project as part of our graduation work.')}
            </p>

            <div className="team-grid">
              {teamMembers.map((member, index) => (
                <div key={index} className="team-card">
                  <div className="team-avatar">
                    {member.name.charAt(0)}
                  </div>
                  <h3 className="team-name">{member.name}</h3>
                  <span className="team-role">{member.role}</span>
                  <span className="team-class">{member.class}</span>
                  <p className="team-description">{member.description}</p>
                </div>
              ))}
            </div>

            <div className="team-contact">
              <h3>{tr('Kapcsolat', 'Contact')}</h3>
              <p>{tr('Kérdésed van? Írj nekünk!', 'Do you have a question? Contact us.')}</p>
              <div className="contact-links">
                <a href={`mailto:${RADIO_EMAIL}`} className="contact-link">
                  <Mail size={18} />
                  <span>{RADIO_EMAIL}</span>
                </a>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'school' && (
          <div className="school-section" role="tabpanel">
            <h2>{tr('Az iskolánkról', 'About our school')}</h2>
            
            <div className="school-info">
              <div className="school-card">
                <h3>{SCHOOL_NAME}</h3>
                <p>
                  {tr('Iskolánk Békéscsaba egyik legrangosabb informatikai és műszaki képzést nyújtó oktatási intézménye. Nevét Nemes Tihamér matematikusról, a számítógép egyik magyar úttörőjéről kapta.', 'Our school is one of Békéscsaba’s leading institutions for information technology and technical education. It is named after Nemes Tihamér, one of the Hungarian pioneers of computing.')}
                </p>
              </div>

              <div className="school-details">
                <h3>{tr('Elérhetőségek', 'Contact details')}</h3>
                <ul className="school-contact">
                  <li>
                    <MapPin size={18} />
                    <span>5600 Békéscsaba, Kazinczy utca 7.</span>
                  </li>
                  <li>
                    <Phone size={18} />
                    <span>+36 66 441 459</span>
                  </li>
                  <li>
                    <Mail size={18} />
                    <a href={`mailto:${SCHOOL_EMAIL}`}>{SCHOOL_EMAIL}</a>
                  </li>
                </ul>
              </div>

              <div className="school-programs">
                <h3>{tr('Képzéseink', 'Programs')}</h3>
                <ul>
                  <li>{tr('Szoftverfejlesztő és -tesztelő technikus', 'Software development and testing technician')}</li>
                  <li>{tr('Hálózati rendszerüzemeltető technikus', 'Network systems operator technician')}</li>
                  <li>{tr('Épület- és szerkezetlakatos technikus', 'Building and metal structure technician')}</li>
                  <li>{tr('Gépi forgácsoló technikus', 'Machining technician')}</li>
                  <li>{tr('Mechatronikai technikus', 'Mechatronics technician')}</li>
                </ul>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default AboutPage;

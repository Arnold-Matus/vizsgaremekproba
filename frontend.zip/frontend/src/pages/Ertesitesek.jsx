﻿import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bell, 
  Music, 
  Info,
  Trash2,
  Check,
  AlertCircle
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { notificationsAPI } from '../services/api';
import { useI18n } from '../contexts/NyelvKontextus';

const NotificationsPage = () => {
  const { user, isLoggedIn } = useUser();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadNotifications = useCallback(async () => {
    if (!isLoggedIn) {
      setNotifications([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const data = await notificationsAPI.getAll();
    setNotifications(data.notifications || []);
    setLoading(false);
  }, [isLoggedIn]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications, user?.id, user?.notifications?.length]);

  const formatRelativeTime = (dateString) => {
    if (!dateString) return tr('Most', 'Now');

    const diffMs = Date.now() - new Date(dateString).getTime();
    const diffMinutes = Math.round(diffMs / 60000);

    if (diffMinutes < 1) return tr('Most', 'Now');
    if (diffMinutes < 60) return language === 'en' ? `${diffMinutes} min ago` : `${diffMinutes} perce`;

    const diffHours = Math.round(diffMinutes / 60);
    if (diffHours < 24) return language === 'en' ? `${diffHours} h ago` : `${diffHours} órája`;

    const diffDays = Math.round(diffHours / 24);
    if (diffDays === 1) return tr('Tegnap', 'Yesterday');
    if (diffDays < 7) return language === 'en' ? `${diffDays} days ago` : `${diffDays} napja`;

    const diffWeeks = Math.round(diffDays / 7);
    return language === 'en' ? `${diffWeeks} weeks ago` : `${diffWeeks} hete`;
  };

  const markAsRead = async (id) => {
    const data = await notificationsAPI.markAsRead(id);
    setNotifications(data.notifications || []);
  };

  const markAllAsRead = async () => {
    const data = await notificationsAPI.markAllAsRead();
    setNotifications(data.notifications || []);
  };

  const deleteNotification = async (id) => {
    const data = await notificationsAPI.delete(id);
    setNotifications(data.notifications || []);
  };

  const clearAll = async () => {
    const data = await notificationsAPI.clearAll();
    setNotifications(data.notifications || []);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type) => {
    switch (type) {
      case 'played':
        return <Music size={20} style={{ color: 'var(--color-success)' }} />;
      case 'alert':
        return <AlertCircle size={20} style={{ color: 'var(--color-error)' }} />;
      default:
        return <Info size={20} style={{ color: 'var(--color-primary)' }} />;
    }
  };

  if (!isLoggedIn || !user) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <Bell size={64} />
          <h2>{tr('Nincs bejelentkezve', 'Not signed in')}</h2>
          <p>{tr('Az értesítések megtekintéséhez jelentkezz be.', 'Sign in to view notifications.')}</p>
          <Link to="/bejelentkezes" className="btn btn-primary">{tr('Bejelentkezés', 'Log in')}</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <Bell size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Értesítések', 'Notifications')}</h1>
            <p className="page-subtitle">
              {unreadCount > 0
                ? tr(`${unreadCount} olvasatlan értesítés`, `${unreadCount} unread notifications`)
                : tr('Minden értesítést elolvastál', 'You are all caught up')}
            </p>
          </div>
        </div>
      </section>

      {/* Actions */}
      {notifications.length > 0 && (
        <div style={{ 
          display: 'flex', 
          justifyContent: 'flex-end', 
          gap: '0.5rem',
          marginBottom: '1rem'
        }}>
          {unreadCount > 0 && (
            <button className="btn btn-secondary" onClick={markAllAsRead}>
              <Check size={18} />
              {tr('Mind olvasottnak jelölése', 'Mark all as read')}
            </button>
          )}
          <button 
            className="btn btn-secondary" 
            onClick={clearAll}
            style={{ color: 'var(--color-error)' }}
          >
            <Trash2 size={18} />
            {tr('Összes törlése', 'Clear all')}
          </button>
        </div>
      )}

      {loading ? (
        <div className="not-logged-in">
          <Bell size={64} />
          <h2>{tr('Értesítések betöltése', 'Loading notifications')}</h2>
          <p>{tr('Ellenőrizzük a legutóbbi eseményeket.', 'Checking the latest activity.')}</p>
        </div>
      ) : notifications.length === 0 ? (
        <div className="not-logged-in">
          <Bell size={64} />
          <h2>{tr('Nincsenek értesítéseid', 'You do not have notifications')}</h2>
          <p>{tr('Ha történik valami fontos, itt fogsz értesülni róla.', 'If something important happens, it will appear here.')}</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gap: '0.75rem' }}>
          {notifications.map(notification => (
            <div 
              key={notification.id}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '1rem',
                padding: '1rem',
                background: notification.read ? 'var(--color-surface)' : 'var(--color-primary-bg)',
                border: `1px solid ${notification.read ? 'var(--color-border)' : 'var(--color-primary)'}`,
                borderRadius: 'var(--radius-lg)',
                cursor: 'pointer',
                transition: 'all var(--transition-fast)'
              }}
              onClick={() => markAsRead(notification.id)}
            >
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '2.5rem',
                height: '2.5rem',
                borderRadius: 'var(--radius-full)',
                background: 'var(--color-bg-secondary)',
                flexShrink: 0
              }}>
                {getIcon(notification.type)}
              </div>
              
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  gap: '0.5rem',
                  marginBottom: '0.25rem'
                }}>
                  <h3 style={{ 
                    fontSize: '1rem', 
                    fontWeight: notification.read ? 500 : 600,
                    margin: 0
                  }}>
                    {notification.title}
                  </h3>
                  <span style={{ 
                    fontSize: '0.75rem', 
                    color: 'var(--color-text-muted)',
                    whiteSpace: 'nowrap'
                  }}>
                    {formatRelativeTime(notification.createdAt)}
                  </span>
                </div>
                <p style={{ 
                  margin: 0, 
                  color: 'var(--color-text-secondary)',
                  fontSize: '0.875rem'
                }}>
                  {notification.message}
                </p>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteNotification(notification.id);
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: '0.5rem',
                  cursor: 'pointer',
                  color: 'var(--color-text-muted)',
                  borderRadius: 'var(--radius-sm)',
                  transition: 'all var(--transition-fast)'
                }}
                title={tr('Értesítés törlése', 'Delete notification')}
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationsPage;

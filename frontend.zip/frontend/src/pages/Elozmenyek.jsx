﻿import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { 
  History, 
  Music, 
  Clock, 
  Calendar,
  CheckCircle,
  XCircle,
  Loader2
} from 'lucide-react';
import { useUser } from '../contexts/FelhasznaloKontextus';
import { requestsAPI } from '../services/api';
import { useI18n } from '../contexts/NyelvKontextus';

const HistoryPage = () => {
  const { user, isLoggedIn } = useUser();
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadHistory = useCallback(() => {
    if (isLoggedIn) {
      setLoading(true);
      requestsAPI.history()
        .then(data => {
          if (data.success) {
            setHistory(data.history.filter(item => item.song != null));
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [isLoggedIn]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  if (!isLoggedIn || !user) {
    return (
      <div className="page">
        <div className="not-logged-in">
          <History size={64} />
          <h2>{tr('Nincs bejelentkezve', 'Not signed in')}</h2>
          <p>{tr('Az előzmények megtekintéséhez jelentkezz be.', 'Sign in to view your request history.')}</p>
          <Link to="/bejelentkezes" className="btn btn-primary">{tr('Bejelentkezés', 'Log in')}</Link>
        </div>
      </div>
    );
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'played':
        return <CheckCircle size={18} style={{ color: 'var(--color-success)' }} />;
      case 'rejected':
        return <XCircle size={18} style={{ color: 'var(--color-error)' }} />;
      case 'pending':
        return <Loader2 size={18} style={{ color: 'var(--color-warning)' }} className="spinning" />;
      default:
        return <Clock size={18} />;
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'played': return tr('Lejátszva', 'Played');
      case 'rejected': return tr('Elutasítva', 'Rejected');
      case 'pending': return tr('Függőben', 'Pending');
      default: return tr('Ismeretlen', 'Unknown');
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'en' ? 'en-GB' : 'hu-HU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <History size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Előzmények', 'History')}</h1>
            <p className="page-subtitle">
              {tr('Korábbi zenekéréseid', 'Your previous music requests')}
            </p>
          </div>
        </div>
      </section>

      {loading ? (
        <div className="not-logged-in">
          <Loader2 size={48} className="spinning" />
          <p>{tr('Betöltés...', 'Loading...')}</p>
        </div>
      ) : history.length === 0 ? (
        <div className="not-logged-in">
          <History size={64} />
          <h2>{tr('Még nincsenek kéréseid', 'You do not have any requests yet')}</h2>
          <p>{tr('Kérj zenéket és itt fognak megjelenni!', 'Request songs and they will appear here.')}</p>
          <Link to="/zene-keres" className="btn btn-primary">{tr('Zene kérése', 'Request music')}</Link>
        </div>
      ) : (
        <div className="song-list-container">
          <div style={{ overflowX: 'auto' }}>
            <table className="song-table">
              <thead>
                <tr>
                    <th style={{ width: '40%' }}>{tr('Zene', 'Song')}</th>
                    <th>{tr('Dátum', 'Date')}</th>
                    <th>{tr('Állapot', 'Status')}</th>
                </tr>
              </thead>
              <tbody>
                {history.map(item => (
                  <tr key={item.id}>
                    <td>
                      <div className="song-info">
                        <div className="song-cover">
                          <Music size={20} />
                        </div>
                        <div className="song-details">
                          <span className="song-title">{item.song.title}</span>
                          <span className="song-artist">{item.song.artist}</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--color-text-secondary)' }}>
                        <Calendar size={16} />
                        {formatDate(item.requestedAt)}
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        {getStatusIcon(item.status)}
                        <span>{getStatusLabel(item.status)}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryPage;

import { 
  HelpCircle, 
  Search, 
  ChevronDown, 
  ChevronUp,
  Music,
  User,
  Settings,
  Shield,
  Mail
} from 'lucide-react';
import { useState } from 'react';
import { useI18n } from '../contexts/NyelvKontextus';
import { RADIO_EMAIL, SCHOOL_EMAIL } from '../constants/appInfo';

const HelpPage = () => {
  const { language } = useI18n();
  const [openFaq, setOpenFaq] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const tr = (hu, en) => (language === 'en' ? en : hu);

  const faqs = [
    {
      category: tr('Zenekérés', 'Music requests'),
      icon: Music,
      questions: [
        {
          q: tr('Hogyan kérhetek zenét?', 'How can I request music?'),
          a: tr('A főoldalon vagy a "Zene kérése" oldalon böngészheted a könyvtárat. Jelöld ki a kívánt zenéket a checkbox-szal, majd kattints a "Kiválasztottak kérése" gombra. Link beküldésével is kérhetsz zenét, amit a moderátorok ellenőriznek.', 'Browse the library on the home page or on the Request Music page. Select the songs you want with the checkbox, then click the Request Selected button. You can also submit a link suggestion, which moderators review before it becomes available.')
        },
        {
          q: tr('Miért nem látom a zenémet a műsorrendben?', 'Why is my song not visible in the schedule yet?'),
          a: tr('A zenekérések sorba kerülnek és a beérkezés sorrendjében játsszuk le őket. Ha sok kérés van, előfordulhat, hogy a te zenéd csak később kerül sorra. A műsorrend oldalon láthatod a várható időpontot.', 'Music requests enter a queue and are played in order of arrival. If there are many requests, your song may appear later. The schedule page shows the expected time.')
        },
        {
          q: tr('Van-e korlátozás a zenekérésekre?', 'Is there a limit on music requests?'),
          a: tr('Igen, naponta maximum 3 zenét kérhetsz. Ez biztosítja, hogy mindenki hozzájuthasson a zenekéréshez. Az adminisztrátoroknak és tanároknak nincs ilyen korlátjuk.', 'Yes. You can request up to 3 songs per day. This helps keep the queue fair for everyone. Administrators and teachers are not subject to this limit.')
        },
        {
          q: tr('Milyen zenéket NEM kérhetek?', 'Which songs can I not request?'),
          a: tr('Nem engedélyezett az explicit tartalmú (káromkodás, erőszak, stb.), a szerzői jogokat sértő, vagy az iskola értékeivel össze nem egyeztethető tartalom. A moderátorok ellenőrzik a beküldött linkeket.', 'Explicit content, copyright-infringing material, or anything that conflicts with the school environment is not allowed. Moderators review submitted links.')
        }
      ]
    },
    {
      category: tr('Fiók', 'Account'),
      icon: User,
      questions: [
        {
          q: tr('Hogyan regisztrálhatok?', 'How can I register?'),
          a: tr('A regisztrációhoz iskolai email címre van szükség (@bszc.hu végződés). A regisztrációs oldalon add meg az adataidat és erősítsd meg az email címedet.', 'You need a school email address ending in @bszc.hu to register. Fill in your details on the registration page and confirm your email address when requested.')
        },
        {
          q: tr('Elfelejtettem a jelszavam. Mit tegyek?', 'I forgot my password. What should I do?'),
          a: tr('A bejelentkezési oldalon kattints az "Elfelejtett jelszó" linkre. Add meg az email címedet és küldünk egy jelszó-visszaállító linket.', 'On the login page, click Forgot password. Enter your email address and we will send you a reset link.')
        },
        {
          q: tr('Hogyan törölhetem a fiókomat?', 'How can I delete my account?'),
          a: tr('A Beállítások oldalon a "Veszélyes zóna" résznél találod a "Fiók törlése" gombot. A törlés végleges és nem visszavonható!', 'On the Settings page, open the Danger Zone section and choose Delete account. This action is permanent and cannot be undone.')
        }
      ]
    },
    {
      category: tr('Beállítások', 'Settings'),
      icon: Settings,
      questions: [
        {
          q: tr('Hogyan kapcsolhatom be a sötét módot?', 'How can I enable dark mode?'),
          a: tr('A navigációs sávban található hold/nap ikonra kattintva, vagy a Beállítások oldalon a Megjelenés résznél. A preferenciád mentésre kerül.', 'Use the theme switcher in the navigation bar or open the Appearance section on the Settings page. Your preference is saved automatically.')
        },
        {
          q: tr('Hogyan növelhetem a betűméretet?', 'How can I increase the font size?'),
          a: tr('A Beállítások vagy Akadálymentesség oldalon találod a betűméret beállítást. 12px és 24px között választhatsz.', 'You can change the font size on the Settings or Accessibility page. The available range is 12 px to 24 px.')
        },
        {
          q: tr('Hogyan módosíthatom a cookie beállításokat?', 'How can I change cookie settings?'),
          a: tr('A Beállítások oldalon az Adatvédelem résznél vagy a láblécben található "Cookie beállítások" linkre kattintva.', 'Open the Privacy section on the Settings page or use the Cookie settings link in the footer.')
        }
      ]
    },
    {
      category: tr('Adatvédelem', 'Privacy'),
      icon: Shield,
      questions: [
        {
          q: tr('Milyen adatokat gyűjtötök rólam?', 'What data do you collect about me?'),
          a: tr('Regisztrációs adatokat (név, email, osztály), használati adatokat (zenekérések, kedvencek) és technikai adatokat (munkamenet). Részletesen az Adatvédelmi tájékoztatóban olvashatod.', 'We collect registration data such as name, email, and class, usage data such as music requests and favorites, and technical data such as session details. The full explanation is available in the privacy notice.')
        },
        {
          q: tr('Hogyan kérhetem az adataim törlését?', 'How can I request deletion of my data?'),
          a: tr(`A Beállítások oldalon kérheted az összes adatod törlését, vagy írj nekünk a ${SCHOOL_EMAIL} címre.`, `You can request removal of your data from the Settings page or by contacting ${SCHOOL_EMAIL}.`)
        },
        {
          q: tr('Megosztjátok az adataimat harmadik féllel?', 'Do you share my data with third parties?'),
          a: tr('Nem, személyes adataidat nem osztjuk meg marketing vagy egyéb célokra. Csak jogszabályi kötelezettség esetén.', 'No. Your personal data is not shared for marketing or other external purposes, except where required by law.')
        }
      ]
    }
  ];

  const filteredFaqs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      item => 
        item.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.a.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  const toggleFaq = (categoryIndex, questionIndex) => {
    const key = `${categoryIndex}-${questionIndex}`;
    setOpenFaq(openFaq === key ? null : key);
  };

  return (
    <div className="page help-page">
      {/* Header */}
      <section className="page-header">
        <div className="page-header-content">
          <HelpCircle size={32} className="page-icon" />
          <div>
            <h1 className="page-title">{tr('Súgó', 'Help')}</h1>
            <p className="page-subtitle">
              {tr('Gyakran ismételt kérdések és válaszok', 'Frequently asked questions and answers')}
            </p>
          </div>
        </div>
      </section>

      <div className="help-content">
        {/* Search */}
        <div className="help-search">
          <Search size={20} className="search-icon" />
          <input
            type="search"
            placeholder={tr('Keresés a kérdések között...', 'Search the help topics...')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
            aria-label={tr('Keresés', 'Search')}
          />
        </div>

        {/* FAQs */}
        <div className="faq-sections">
          {filteredFaqs.length === 0 ? (
            <div className="no-results">
              <HelpCircle size={48} />
              <p>{tr('Nincs találat a keresési feltételeknek megfelelően.', 'No help entries match your search.')}</p>
            </div>
          ) : (
            filteredFaqs.map((category, catIndex) => (
              <section key={catIndex} className="faq-section">
                <h2>
                  <category.icon size={20} />
                  {category.category}
                </h2>
                <div className="faq-list">
                  {category.questions.map((item, qIndex) => {
                    const isOpen = openFaq === `${catIndex}-${qIndex}`;
                    return (
                      <div key={qIndex} className={`faq-item ${isOpen ? 'open' : ''}`}>
                        <button
                          className="faq-question"
                          onClick={() => toggleFaq(catIndex, qIndex)}
                          aria-expanded={isOpen}
                        >
                          <span>{item.q}</span>
                          {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                        </button>
                        {isOpen && (
                          <div className="faq-answer">
                            <p>{item.a}</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </section>
            ))
          )}
        </div>

        {/* Contact */}
        <section className="help-contact">
          <h2>{tr('Nem találtad meg a választ?', 'Didn’t find the answer?')}</h2>
          <p>{tr('Írj nekünk és segítünk!', 'Write to us and we will help.')}</p>
          <a href={`mailto:${RADIO_EMAIL}`} className="contact-btn">
            <Mail size={20} />
            {RADIO_EMAIL}
          </a>
        </section>
      </div>
    </div>
  );
};

export default HelpPage;

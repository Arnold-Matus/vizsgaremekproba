﻿import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useI18n } from '../contexts/NyelvKontextus';
import AppLogo from '../components/AppLogo';
import LanguageToggle from '../components/NyelvValtoGomb';

const ForgotPasswordPage = () => {
  const { language } = useI18n();
  const tr = (hu, en) => (language === 'en' ? en : hu);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email.trim()) {
      setError(tr('Add meg az email címed!', 'Enter your email address.'));
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError(tr('Érvénytelen email cím!', 'Invalid email address.'));
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSuccess(true);
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <div className="auth-language-toggle-row">
          <LanguageToggle />
        </div>
        <div className="auth-logo">
          <div className="auth-logo-icon" aria-hidden="true">
            <AppLogo className="app-logo-image" decorative />
          </div>
          <h1>SuliRadio</h1>
        </div>

        <h2 className="auth-title">{tr('Elfelejtett jelszó', 'Forgot password')}</h2>
        <p className="auth-subtitle">{tr('Add meg az email címed és küldünk egy visszaállítási linket.', 'Enter your email address and we will send you a reset link.')}</p>

        {error && (
          <div className="auth-message error">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{error}</span>
          </div>
        )}

        {success ? (
          <div className="auth-success-box">
            <div className="success-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                <polyline points="22,4 12,14.01 9,11.01"/>
              </svg>
            </div>
            <h3>{tr('Email elküldve!', 'Email sent')}</h3>
            <p>{tr('Ha a megadott email cím szerepel a rendszerünkben, hamarosan kapsz egy linket a jelszó visszaállításához.', 'If the supplied email address exists in our system, you will receive a password reset link shortly.')}</p>
            <Link to="/bejelentkezes" className="auth-submit" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>
              {tr('Vissza a bejelentkezéshez', 'Back to login')}
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label htmlFor="email">{tr('Email cím', 'Email address')}</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError('');
                }}
                placeholder={tr('pelda@bszc.hu', 'example@bszc.hu')}
                disabled={isSubmitting}
                autoComplete="email"
                autoFocus
              />
            </div>

            <button type="submit" className="auth-submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <span className="spinner"></span>
                  {tr('Küldés...', 'Sending...')}
                </>
              ) : (
                tr('Visszaállítási link küldése', 'Send reset link')
              )}
            </button>
          </form>
        )}

        <p className="auth-footer">
          <Link to="/bejelentkezes">{tr('← Vissza a bejelentkezéshez', '← Back to login')}</Link>
        </p>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;

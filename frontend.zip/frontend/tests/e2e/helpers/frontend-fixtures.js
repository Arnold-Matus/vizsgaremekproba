export const COOKIE_CONSENT_KEY = 'suliradio-cookie-consent';

const sampleSongs = [
  {
    id: 1,
    cim: 'Tavaszi Szel',
    eloado: 'Nemes Band',
    tema: 'Pop',
    hossz: 215,
    keresszam: 4,
    lejatszhatoe: 1,
    keresurl: 'https://example.com/tavaszi-szel',
    zeneurl: 'https://cdn.example.com/tavaszi-szel.mp3',
    created_at: '2026-05-01T08:00:00.000Z',
  },
  {
    id: 2,
    cim: 'Napfeny Utca',
    eloado: 'Diak FM',
    tema: 'Rock',
    hossz: 189,
    keresszam: 2,
    lejatszhatoe: 1,
    keresurl: 'https://example.com/napfeny-utca',
    zeneurl: 'https://cdn.example.com/napfeny-utca.mp3',
    created_at: '2026-05-02T08:00:00.000Z',
  },
];

const sampleUsers = [
  {
    id: 10,
    email: 'teszt1@bszc.hu',
    keresztnev: 'Anna',
    vezeteknev: 'Kiss',
    jog: 2,
    omazonosito: '12345678901',
    emailverifikalva: 1,
  },
  {
    id: 11,
    email: 'teszt2@bszc.hu',
    keresztnev: 'Bela',
    vezeteknev: 'Nagy',
    jog: 2,
    omazonosito: '12345678902',
    emailverifikalva: 1,
  },
];

const consentPayload = {
  necessary: true,
  preferences: false,
  statistics: false,
  marketing: false,
  timestamp: '2026-05-08T08:00:00.000Z',
};

function fulfillJson(route, payload, status = 200) {
  return route.fulfill({
    status,
    contentType: 'application/json',
    body: JSON.stringify(payload),
  });
}

export async function mockPublicApi(page, options = {}) {
  const { registerStatus = 201 } = options;

  await page.route('http://127.0.0.1:8000/api/**', async (route) => {
    const { pathname } = new URL(route.request().url());

    switch (pathname) {
      case '/api/osszeszene':
        return fulfillJson(route, sampleSongs);
      case '/api/osszesfelhasznalokilistazasa':
        return fulfillJson(route, sampleUsers);
      case '/api/jelenlegbejelentkezettfelhasznalok':
        return fulfillJson(route, []);
      case '/api/mainapiorarend':
        return fulfillJson(route, []);
      case '/api/kovetkezolejatszas':
        return route.fulfill({ status: 204, body: '' });
      case '/api/lejatszandozene':
        return route.fulfill({ status: 200, contentType: 'text/plain', body: '' });
      case '/api/felhasznalotokenbol/x':
        return route.fulfill({ status: 401, contentType: 'application/json', body: '{}' });
      case '/api/bejelentkezes':
        return route.fulfill({ status: 401, contentType: 'text/plain', body: 'Unauthorized' });
      case '/api/regisztracio':
        return route.fulfill({
          status: registerStatus,
          contentType: 'text/plain',
          body: registerStatus === 201 ? 'regisztralva' : 'Hiba tortent',
        });
      default:
        return fulfillJson(route, []);
    }
  });
}

export async function seedCookieConsent(page) {
  await page.addInitScript((payload) => {
    window.localStorage.setItem('suliradio-cookie-consent', JSON.stringify(payload));
  }, consentPayload);
}

export async function clearCookieConsent(page) {
  await page.addInitScript(() => {
    window.localStorage.removeItem('suliradio-cookie-consent');
  });
}
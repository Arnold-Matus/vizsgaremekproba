import { expect, test } from '@playwright/test';
import { clearCookieConsent, mockPublicApi, seedCookieConsent } from './helpers/frontend-fixtures.js';

async function acceptRegistrationConsents(page) {
  await page.locator('.form-checkboxes .checkbox-label').nth(0).click({ position: { x: 12, y: 12 } });
  await expect(page.locator('input[name="acceptTerms"]')).toBeChecked();

  await page.locator('.form-checkboxes .checkbox-label').nth(1).click({ position: { x: 12, y: 12 } });
  await expect(page.locator('input[name="acceptPrivacy"]')).toBeChecked();
}

test.beforeEach(async ({ page }) => {
  await mockPublicApi(page);
});

test('home page renders public content and cookie banner can be dismissed', async ({ page }) => {
  await clearCookieConsent(page);
  await page.goto('/');

  await expect(page.getByRole('heading', { name: 'Cookie beállítások' })).toBeVisible();
  await page.getByRole('button', { name: 'Csak szükséges' }).click();
  await expect(page.getByRole('heading', { level: 1, name: /SuliRadio/ })).toBeVisible();
  await expect(page.getByRole('heading', { level: 2, name: 'Zenék böngészése' })).toBeVisible();
  await expect(page.getByText('Tavaszi Szel')).toBeVisible();
  await expect(page.getByText('Napfeny Utca')).toBeVisible();
});

test('login page shows client-side validation for empty submit', async ({ page }) => {
  await seedCookieConsent(page);
  await page.goto('/bejelentkezes');

  await page.getByRole('button', { name: 'Bejelentkezés' }).click();

  await expect(page.getByText('Kérlek töltsd ki az összes mezőt!')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Demo fiók kipróbálása' })).toBeVisible();
});

test('registration page rejects numeric characters in the surname field', async ({ page }) => {
  await seedCookieConsent(page);
  await page.goto('/regisztracio');

  await page.getByLabel('Vezetéknév').fill('Kov4cs');
  await page.getByLabel('Keresztnév').fill('Ádám');
  await page.getByLabel('Email cím').fill('teszt@bszc.hu');
  await page.getByLabel('Oktatási azonosító').fill('12345678901');
  await page.getByLabel('Jelszó', { exact: true }).fill('Er0sJelszo');
  await page.getByLabel('Jelszó megerősítése').fill('Er0sJelszo');
  await acceptRegistrationConsents(page);
  await page.getByRole('button', { name: 'Regisztráció' }).click();

  await expect(page.getByText('A vezetéknév csak betűket, szóközt, kötőjelet és aposztrófot tartalmazhat.')).toBeVisible();
  await expect(page).toHaveURL(/\/regisztracio$/);
});

test('registration accepts accented names and redirects to login after success', async ({ page }) => {
  await seedCookieConsent(page);
  await page.goto('/regisztracio');

  await page.getByLabel('Vezetéknév').fill('Árvízi');
  await page.getByLabel('Keresztnév').fill('Őrs');
  await page.getByLabel('Email cím').fill('ors@bszc.hu');
  await page.getByLabel('Oktatási azonosító').fill('12345678901');
  await page.getByLabel('Jelszó', { exact: true }).fill('Er0sJelszo');
  await page.getByLabel('Jelszó megerősítése').fill('Er0sJelszo');
  await acceptRegistrationConsents(page);
  await page.getByRole('button', { name: 'Regisztráció' }).click();

  await page.waitForURL('**/bejelentkezes', { timeout: 10000 });
  await expect(page.getByText('Sikeres regisztráció! Most már bejelentkezhetsz.')).toBeVisible();
});